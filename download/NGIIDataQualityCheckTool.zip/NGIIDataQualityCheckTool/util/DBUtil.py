# -*- coding: utf-8 -*-
import subprocess
import os
import glob
import io
import platform
from collections import OrderedDict
from psycopg2.extensions import connection, ISOLATION_LEVEL_AUTOCOMMIT
import ConfigParser

import psycopg2
from psycopg2.sql import SQL, Identifier

import threading
import time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

import logging
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking
class CmdThread(threading.Thread):
    def __init__(self, commandList):
        self.commandList = commandList
        threading.Thread.__init__(self)

    def run(self):
        if platform.system() == 'Windows':
            subprocess.check_call(self.commandList, creationflags=0x08000000)
        else:
            subprocess.check_call(self.commandList, stderr=subprocess.STDOUT)
        return


def threadExecuteCmd(commandList):
    trd = CmdThread(commandList)
    trd.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class DBUtil:
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "properties", "connection.ini")
    SQL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sql", "sql.ini")

    INS_SCHEMA = 'ngii_inspect'

    CHANGE_SE_DICT = {
        "n": "추가", 
        "r": "삭제", 
        "pe": "속성수정", 
        "ge": "형상수정", 
        "pge": "형상/속성수정"
    }

    __dbHost = 'localhost'
    __dbPort = '5432'
    __dbNm = 'postgres'
    __dbUser = 'postgres'
    __dbPassword = 'postgres'

    sqlStatement = None

    conn = None  # type: connection

    def __init__(self):
        self.logger = logger
        self.__loadProperties()
        self.__loadSql()

        self.connectPg()

    def __loadProperties(self):
        self.properties = ConfigParser.RawConfigParser()
        self.properties.read(self.PROPERTIES_FILE)

        # Database
        self.__dbHost = self.properties.get("database", "host")
        self.__dbPort = self.properties.get("database", "port")
        self.__dbNm = self.properties.get("database", "dbname")
        self.__dbUser = self.properties.get("database", "user")
        self.__dbPassword = self.properties.get("database", "password")

    def __loadSql(self):
        self.sqlStatement = ConfigParser.RawConfigParser()
        self.sqlStatement.read(self.SQL_FILE)

    def dropStdTables(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            dropSql = self.sqlStatement.get("SQL", "dropStdTables")
            self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema))))
            cur.execute(SQL(dropSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"표준 테이블을 삭제하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def createStdTable(self):
        self.logger.debug("Create Standard Table.")
        result = False

        conn = psycopg2.connect(host=self.__dbHost, port=int(self.__dbPort), database=self.__dbNm,
                                user=self.__dbUser, password=self.__dbPassword)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)

        cur = conn.cursor()
        if not cur:
            raise psycopg2.DatabaseError

        sql_init_file = os.path.join(os.path.dirname(__file__), '../sql/standard_insert.sql')

        # Read SQL files
        try:
            with io.open(sql_init_file, 'r', encoding='utf8') as f:
                sql_init = f.read()

            cur.execute(sql_init)

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)

            self.conn.rollback()

        if cur:
            cur.close()

        if conn:
            conn.close()

        return result

    def checkInspectData(self, inspectData, inspectProgress):

        if self.INS_SCHEMA in self.selectSchemaList():
            self.dropSchema(self.INS_SCHEMA)

        if os.path.exists(inspectData):
            if os.path.isfile(inspectData):
                if not inspectData.endswith('gpkg'):
                    return False, u"검사대상은 GeoPackage 파일을 선택해야합니다."
                dataKind = 'gpkg'
            elif os.path.isdir(inspectData):
                if len(glob.glob(os.path.join(inspectData, "*.shp"))) == 0:
                    return False, u"폴더 안에 SHP이 존재하지 않습니다.\n다른 폴더를 선택해주세요."
                dataKind = 'shp'
            else:
                return False, u"검사대상에 문제가 있습니다."

        else:
            return False, u"검사대상에 문제가 있습니다."

        if dataKind == 'gpkg':
            inspectProgress.setInfo(u"검사를 위해 GeoPackage를 가져오는 중 ... ")
            inspectResult, msg = self.__insertGpkg(inspectData)
            if not inspectResult:
                return False, msg
        else:
            inspectProgress.setInfo(u"검사를 위해 Shapefile을 가져오는 중 ... ")
            inspectResult, msg = self.__insertShp(inspectData, 'UTF-8')
            if not inspectResult:
                self.__insertShp(inspectData, 'CP949')
            # if not inspectResult:
            #     return False, msg

        self.createErrReason(self.INS_SCHEMA)

        # add column obchg_se
        self.__createObjectChangeCol(self.INS_SCHEMA)

        # 전수검사/수시수정 분기
        # 변경 레이어가 있을 경우 수시수정으로 판단 / 없는 경우 전수검사로 판단
        res = self.__checkDataModifyType(self.INS_SCHEMA)

        # integrated table
        if res:
            self.__updateCreateFlag(self.INS_SCHEMA)
        else:
            self.__createStandardTable(self.INS_SCHEMA, dataKind)
            self.__insertChangeData(self.INS_SCHEMA)

        self.createCid(self.INS_SCHEMA, dataKind)

        vacuumResult, msg = self.vacuumSchema(self.INS_SCHEMA)
        if not vacuumResult:
            return vacuumResult, msg

        return True, msg

    def __insertShp(self, inspectData, shp_encode):
        print shp_encode
        print inspectData
        self.logger.info("Start to insert SHP in database.")
        result = False

        createResult, errMsg = self.createSchema(self.INS_SCHEMA)
        if not createResult:
            return result, errMsg

        pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password}' \
            .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                    user=self.__dbUser, password=self.__dbPassword)

        for shp in glob.glob(os.path.join(inspectData, "*.shp")):
            self.logger.debug(shp)
            commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '--config', 'SHAPE_ENCODING', shp_encode,
                           '--config', 'GDAL_FILENAME_IS_UTF8', 'NO', '-f', 'PostgreSQL',
                           pgConnectInfo, shp, '-nlt', 'PROMOTE_TO_MULTI', '-lco', 'PRECISION=NO',
                           '-lco', 'SCHEMA={schema}'.format(schema=self.INS_SCHEMA)]

            try:
                self.logger.debug("Command : " + ' '.join(commandList))
                threadExecuteCmd(commandList)

                self.logger.info("Insert completely.")

                tableList = self.selectTableList(self.INS_SCHEMA)
                tableListStr = ','.join(tableList)
                layerNm = os.path.splitext(os.path.basename(shp))[0]
                if layerNm.lower() not in tableListStr:
                    return False, None

            except Exception as e:
                self.logger.warning(e, exc_info=True)
                return result, u'SHP를 DB에 넣는 도중 문제가 발생하였습니다.'

        self.logger.info("End to insert SHP in database.")

        result = True

        return result, None

    def __insertGpkg(self, inspectData):
        self.logger.info("Start to insert GeoPackage in database.")
        result = False

        createResult, errMsg = self.createSchema(self.INS_SCHEMA)
        if not createResult:
            return result, errMsg

        pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password}'\
            .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                    user=self.__dbUser, password=self.__dbPassword)

        commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '--config', 'SHAPE_ENCODING', 'UTF-8', '-f', 'PostgreSQL',
                       pgConnectInfo, inspectData, '-nlt', 'PROMOTE_TO_MULTI',
                       '-lco', 'SCHEMA={schema}'.format(schema=self.INS_SCHEMA)]

        try:
            self.logger.debug("Command : " + ' '.join(commandList))
            threadExecuteCmd(commandList)

            self.logger.info("Insert completely.")

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return result, u'GPKG를 DB에 넣는 도중 문제가 발생하였습니다.'

        self.logger.info("End to insert GeoPackage in database.")

        result = True

        return result, None

    def __createObjectChangeCol(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                colList = self.selectColList(schema, table)
                if 'obchg_se' in colList:
                    continue

                createSql = self.sqlStatement.get("SQL", "createObjectChangeCol")
                self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(createSql).format(schema=Identifier(schema), table=Identifier(table)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"칼럼을 추가하는 데 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg
    
    def __checkDataModifyType(self, schema):
        result = True

        tableList = self.selectTableList(schema)
        for table in tableList:
            tableStrList = table.split('_')
            chageType = tableStrList[-1]

            if chageType in ['n', 'r', 'pe', 'ge', 'pge']:
                result = False
                break

        return result

    def __updateCreateFlag(self, schema):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            updateSql = self.sqlStatement.get("SQL", "updateCreateFlag")

            tableList = self.selectTableList(schema)
            for table in tableList:
                self.logger.debug(cur.mogrify(SQL(updateSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(updateSql).format(schema=Identifier(schema), 
                                                  table=Identifier(table)))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def __createStandardTable(self, schema, dataKind):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        if dataKind == 'shp':
            fid = 'ogc_fid'
        else:
            fid = 'fid'

        try:
            for table in tableList:
                tableStrList = table.split('_')
                chageType = tableStrList[-1]

                if chageType in ['n', 'r', 'pe', 'ge', 'pge']:
                    tableNm = "_".join(tableStrList[:-1])

                    if tableNm in tableList:
                        continue

                    seqNm = '{}_fid_seq'.format(tableNm)
                    gistNm = '{}_gist'.format(tableNm)

                    createSql = self.sqlStatement.get("SQL", "createStandardTable")
                    self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                        std_table=Identifier(tableNm),
                                                                        table=Identifier(table),
                                                                        seq_nm=Identifier(seqNm),
                                                                        fid=Identifier(fid),
                                                                        gist=Identifier(gistNm)),
                                                  {"seq_nm": '{schema}.{seqNm}'.format(schema=schema,seqNm=seqNm)}))
                    cur.execute(SQL(createSql).format(schema=Identifier(schema),
                                                      std_table=Identifier(tableNm),
                                                      table=Identifier(table),
                                                      seq_nm=Identifier(seqNm),
                                                      fid=Identifier(fid),
                                                      gist=Identifier(gistNm)),
                                {"seq_nm": '{schema}.{seqNm}'.format(schema=schema, seqNm=seqNm)})

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"표준 테이블을 만드는 중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def __insertChangeData(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                tableStrList = table.split('_')
                changeType = tableStrList[-1]

                if changeType in ['n', 'r', 'pe', 'ge', 'pge']:
                    changeSeNm = self.CHANGE_SE_DICT[changeType]

                    tableNm = "_".join(tableStrList[:-1])
                    colList = self.selectColList(schema, tableNm)

                    if 'fid' in colList:
                        colList.remove("fid")
                    if 'ogc_fid' in colList:
                        colList.remove("ogc_fid")
                    if 'objectid' in colList:
                        colList.remove("objectid")
                    colList.remove("obchg_se")

                    colListSql = [SQL(col) for col in colList]
                    insertSql = self.sqlStatement.get("SQL", "insertChangeData")
                    self.logger.debug(cur.mogrify(SQL(insertSql).format(schema=Identifier(schema),
                                                                        std_table=Identifier(tableNm),
                                                                        table=Identifier(table),
                                                                        col_list=SQL(',').join(colListSql)),
                                      {"changeSeNm": changeSeNm}))
                    cur.execute(SQL(insertSql).format(schema=Identifier(schema),
                                                      std_table=Identifier(tableNm),
                                                      table=Identifier(table),
                                                      col_list=SQL(',').join(colListSql)),
                                {"changeSeNm": changeSeNm})

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"데이터를 통합하는 과정에서 오류가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def getDbInfo(self):
        return {
            "host": self.__dbHost,
            "port": self.__dbPort,
            "dbname": self.__dbNm,
            "user": self.__dbUser,
            "password": self.__dbPassword,
        }

    def getCursor(self):
        try:
            cur = self.conn.cursor()
        except psycopg2.InterfaceError:
            if not self.connectPg:
                return None
            cur = self.conn.cursor()

        return cur

    def connectPg(self):
        try:
            if self.conn:
                self.conn.close()

            self.conn = psycopg2.connect(host=self.__dbHost, port=int(self.__dbPort), database=self.__dbNm,
                                         user=self.__dbUser, password=self.__dbPassword)

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return False

        return True

    def reloadProperties(self):
        self.__loadProperties()

    def selectInspectStandard(self, bCode):
        inspectList = OrderedDict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectInspectStandard")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"b_code": bCode}))
            cur.execute(SQL(selectSql), {"b_code": bCode})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tmpData = {
                    "t_code_nm": sqlResult[2].encode("UTF-8"),
                    "ins_target_code": sqlResult[3],
                    "std_val": sqlResult[4]
                }

                if sqlResult[0] in inspectList.keys():
                    inspectList[sqlResult[0]][sqlResult[1]] = tmpData
                else:
                    inspectList[sqlResult[0]] = OrderedDict()
                    inspectList[sqlResult[0]][sqlResult[1]] = tmpData

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return inspectList

    def selectStandardLayerStructure(self):
        layerInfo = OrderedDict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectStandardLayerStructure")
            self.logger.debug(cur.mogrify(SQL(selectSql)))
            cur.execute(SQL(selectSql))

            sqlResults = cur.fetchall()
            layerGroup = set()
            for sqlResult in sqlResults:
                layerGroup.add(sqlResult[1].encode("UTF-8"))
                layerInfo[sqlResult[0].lower()] = {
                    "layer_package": sqlResult[1].encode("UTF-8"),
                    "layer_nm": sqlResult[2].encode("UTF-8"),
                    "col_list": sqlResult[3]
                }

            layerInfo["layerGroup"] = list(layerGroup)

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return layerInfo

    def selectSchemaList(self):
        schemaList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectSchemaList")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"user": self.__dbUser}))
            cur.execute(SQL(selectSql), {"user": self.__dbUser})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                schemaList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return schemaList

    def selectCids(self, schema, table):
        cidList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectCids")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))

            sqlResults = cur.fetchall()

            cidList = [sqlResult[0] for sqlResult in sqlResults]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return cidList

    def selectColList(self, schema, table):
        colList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectColList")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema_nm": schema, "table_nm": table}))
            cur.execute(SQL(selectSql), {"schema_nm": schema, "table_nm": table})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                colList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return colList

    def selectColType(self, schema, table, colNm):
        colType = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectColType")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema_nm": schema, "table_nm": table, "col_nm": colNm}))
            cur.execute(SQL(selectSql), {"schema_nm": schema, "table_nm": table, "col_nm": colNm})

            sqlResult = cur.fetchone()

            colType = sqlResult[0]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return colType

    def createSchema(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            createSql = self.sqlStatement.get("SQL", "createSchema")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema))))
            cur.execute(SQL(createSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"스키마를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def dropSchema(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            dropSql = self.sqlStatement.get("SQL", "dropSchema")
            self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema))))
            cur.execute(SQL(dropSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"스키마를 삭제하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def createErrIndexTable(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            createSql = self.sqlStatement.get("SQL", "createErrIndexTable")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema))))
            cur.execute(SQL(createSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"오류 인덱스 테이블을 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def insertErrIndex(self, schema, table, cid, err_cd, img_nm, extent):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        errInfo = {
            "layerNm": table,
            "cid": cid,
            "errCd": err_cd,
            "imgNm": img_nm,
            "geom": "POLYGON(({0} {1}, {0} {3}, {2} {3}, {2} {1}, {0} {1}))".format(
                str(extent.xMinimum()),
                str(extent.yMinimum()),
                str(extent.xMaximum()),
                str(extent.yMaximum())
            )
        }

        try:
            insertSql = self.sqlStatement.get("SQL", "insertErrIndex")
            self.logger.debug(cur.mogrify(SQL(insertSql).format(schema=Identifier(schema)), errInfo))
            cur.execute(SQL(insertSql).format(schema=Identifier(schema)), errInfo)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def updateErrReason(self, schema, errInfo):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            updateSql = self.sqlStatement.get("SQL", "updateErrReason")

            cidList = errInfo.keys()

            for cid in cidList:
                errCode = errInfo[cid]['err_code']
                errReason = errInfo[cid]['err_reason']

                if not errCode or not errReason:
                    continue

                errCodeList = errCode.split(',')
                errReasonList = errReason.split('|')

                if len(errCodeList) == len(errReasonList):
                    for i in range(0, len(errCodeList)):
                        self.logger.debug(cur.mogrify(SQL(updateSql).format(schema=Identifier(schema)),
                                                      {"cid": cid,
                                                       "errCode": errCodeList[i],
                                                       "errReason": errReasonList[i]}))
                        cur.execute(SQL(updateSql).format(schema=Identifier(schema)),
                                    {"cid": cid,
                                     "errCode": errCodeList[i],
                                     "errReason": errReasonList[i]})

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def updateErrCode(self, schema, table):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            updateSql = self.sqlStatement.get("SQL", "updateErrCode")
            self.logger.debug(cur.mogrify(SQL(updateSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(updateSql).format(schema=Identifier(schema),
                                              table=Identifier(table)))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def selectErrInfo(self, schema, table):
        errInfo = dict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectErrInfo")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema),
                                              table=Identifier(table)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:

                errInfo[sqlResult[0]] = {\
                    "err_reason": sqlResult[1]
                }

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        return errInfo

    def exportErrIndex(self, schema, shp):
        self.logger.info("Start to Export err index SHP in database.")
        result = False

        pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password} ' \
                        'active_schema={schema} tables=err_index'\
            .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                    user=self.__dbUser, password=self.__dbPassword, schema=schema)

        commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '--config', 'SHAPE_ENCODING', 'UTF-8',
                       '--config', 'GDAL_FILENAME_IS_UTF8', 'NO', '-f', 'Esri Shapefile',
                       shp, pgConnectInfo]

        try:
            self.logger.debug("Command : " + ' '.join(commandList))
            threadExecuteCmd(commandList)

            with open("{}.cpg".format(os.path.splitext(shp)[0]), "wb") as cpgFile:
                cpgFile.write("UTF-8")

            self.logger.info("Export completely.")

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return result, u'오류 인덱스 파일을 만들던 중 문제가 발생하였습니다.'

        self.logger.info("End to Export err index SHP in database.")

        result = True

        return result, None

    def exportResGpkg(self, schema, gpkg):
        self.logger.info("Start to Export gpkg in database.")
        result = False

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                if table == 'err_index':
                    continue

                colList = self.selectColList(schema, table)
                # if 'cid' in colList:
                #     colList.remove('cid')

                if 'fid' in colList:
                    colList.remove('fid')

                if 'ogc_fid' in colList:
                    colList.remove('ogc_fid')

                pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password} ' \
                                'active_schema={schema} tables={table}' \
                    .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                            user=self.__dbUser, password=self.__dbPassword, schema=schema, table=table)

                commandList = ['ogr2ogr', '-append', '-update', '-select', ','.join(colList), '-where', 'obchg_se != \'\' AND obchg_se IS NOT NULL',
                              '-f', 'GPKG', gpkg, pgConnectInfo, '-nln', table]

                self.logger.debug("Command : " + ' '.join(commandList))
                threadExecuteCmd(commandList)

                self.logger.info("{table} Export completely.".format(table=table))

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return result, u'GPKG를 만들던 중 문제가 발생하였습니다.'

        self.logger.info("End to Export gpkg in database.")

        result = True

        return result, None

    def selectTableList(self, schema):
        tableList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectTableList")
            self.logger.debug(cur.mogrify(selectSql, {"schema": schema}))
            cur.execute(selectSql, {"schema": schema})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tableList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return tableList

    def selectPointTableList(self, schema):
        tableList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectPointTableList")
            self.logger.debug(cur.mogrify(selectSql, {"schema": schema}))
            cur.execute(selectSql, {"schema": schema})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tableList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return tableList

    def selectFeatureCount(self, schema, table):
        count = -1

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectFeatureCount")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))
            sqlResult = cur.fetchone()

            count = int(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return count

    def vacuumSchema(self, schema, tables=None):
        result = False

        if not tables:
            tableList = self.selectTableList(schema)

            if len(tableList) <= 0:
                return result, '{schema} is empty'.format(schema=schema)
        else:
            tableList = tables

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            isolationLevel = self.conn.isolation_level
            self.conn.set_isolation_level(0)

            for table in tableList:
                vacuumSql = self.sqlStatement.get("SQL", "vacuumSchema")
                self.logger.debug(cur.mogrify(SQL(vacuumSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(vacuumSql).format(schema=Identifier(schema), table=Identifier(table)))
            self.conn.set_isolation_level(isolationLevel)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            self.conn.rollback()

            return result, u'VACUUM을 실행하는 도중 문제가 발생하였습니다.'

        else:
            self.conn.commit()

        if cur:
            cur.close()

        return result, None

    def createCid(self, schema, dataKind):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        if dataKind == 'shp':
            fid = 'ogc_fid'
        else:
            fid = 'fid'

        try:
            for table in tableList:
                createSql = self.sqlStatement.get("SQL", "createCid")
                self.logger.debug(cur.mogrify(SQL(createSql).format(schema=SQL(schema),
                                                                    table=SQL(table),
                                                                    fid=SQL(fid))))
                cur.execute(SQL(createSql).format(schema=SQL(schema),
                                                    table=SQL(table),
                                                    fid=SQL(fid)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"CID를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def createErrReason(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                createSql = self.sqlStatement.get("SQL", "createErrReason")
                self.logger.debug(cur.mogrify(SQL(createSql).format(schema=SQL(schema),
                                                                    table=SQL(table))))
                cur.execute(SQL(createSql).format(schema=SQL(schema),
                                                  table=SQL(table)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"ER_REASON를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def selectStandardCreateDate(self):
        standardCreateDate = dict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectStandardCreateDate")
            self.logger.debug(cur.mogrify(SQL(selectSql)))
            cur.execute(SQL(selectSql))

            sqlResult = cur.fetchone()

            standardCreateDate = {
                "com_code": sqlResult[0],
                "ins_standard": sqlResult[1],
                "std_layer": sqlResult[2],
                "std_struct": sqlResult[3],
                "std_codezip": sqlResult[4]
            }

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return standardCreateDate

    def deleteComCode(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteComCode")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertComCode(self, comCodeDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertComCode")
            for comCode in comCodeDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), comCode))
                cur.execute(SQL(insertSql), comCode)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteStandard(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteStandard")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertStandard(self, standardDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertStandard")
            for standard in standardDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), standard))
                cur.execute(SQL(insertSql), standard)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteLayer(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteLayer")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertLayer(self, LayerDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertLayer")
            for Layer in LayerDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), Layer))
                cur.execute(SQL(insertSql), Layer)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteLayerStruct(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteLayerStruct")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertLayerStruct(self, layerStructDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertLayerStruct")
            for layerStruct in layerStructDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), layerStruct))
                cur.execute(SQL(insertSql), layerStruct)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteCodezip(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteCodezip")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertCodezip(self, codezipList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertCodezip")
            for codezip in codezipList:
                self.logger.debug(cur.mogrify(SQL(insertSql), codezip))
                cur.execute(SQL(insertSql), codezip)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertCid(self, schema, layerId):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertCid")
            self.logger.debug(cur.mogrify(SQL(insertSql).format(schema=Identifier(schema), layerId=Identifier(layerId)),
                                          {"layerId": layerId}))
            cur.execute(SQL(insertSql).format(schema=Identifier(schema), layerId=Identifier(layerId)),
                        {"layerId": layerId})

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def selectReportCid(self):
        cur = self.getCursor()
        selectResult = list()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            reportSql = self.sqlStatement.get("SQL", "selectReportCid")
            self.logger.debug(cur.mogrify(SQL(reportSql)))
            cur.execute(SQL(reportSql))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return selectResult

# -*- coding: utf-8 -*-
import os
import datetime
import subprocess

from PyQt4.QtCore import *
from qgis.core import *
from PIL import Image

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ImgUtil:

    refresh_flag = False

    IMG_SAVE_PATH = os.path.join(QgsApplication.qgisSettingsDirPath(), "qi_result", datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
    SLD_PATH = os.path.join(os.path.dirname(__file__), "..", "style_files")

    def __init__(self, iface, dock):
        self.iface = iface
        self.logger = logger
        self.dock = dock

        if not os.path.exists(self.IMG_SAVE_PATH):
            os.mkdir(self.IMG_SAVE_PATH)

        self.iface.mapCanvas().mapCanvasRefreshed.connect(self.__refresh_map)

    def __refresh_map(self):
        self.refresh_flag = True

    def forceRefresh(self):
        while not self.refresh_flag:
            QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
            pass
        self.refresh_flag = False

    def setDefaultSymbol(self, layer):
        try:
            styleFile = os.path.join(self.SLD_PATH, "{}.sld".format(layer.name()))
            if os.path.exists(styleFile):
                layer.loadSldStyle(styleFile)
            else:
                styleFile = os.path.join(self.SLD_PATH, "{}.qml".format(layer.name()))
                layer.loadNamedStyle(styleFile)
            layer.triggerRepaint()
        except Exception as e:
            self.logger.debug(e, exc_info=True)

    def setErrorSymbol(self, layer, expr):
        geomType = layer.wkbType()
        err_color = "red"

        if layer.name() == 'temporary_point':
            symbol = QgsMarkerSymbolV2().createSimple({"name": "cross2", "outline_style": "no"})
            err_symbol = QgsMarkerSymbolV2().createSimple({"name": "cross2", "size": "0.05", 'size_unit': 'MapUnit',
                                                           'outline_color': err_color,
                                                           "outline_style": "solid", 'outline_width': '1'})
            renderer = QgsRuleBasedRendererV2(symbol)

        elif layer.name() == 'temporary_linestring':
            symbol = QgsLineSymbolV2().createSimple({"outline_style": "no"})
            err_symbol = QgsLineSymbolV2().createSimple({"color": err_color, "width": "1", "style": "solid",
                                                         "unit": "pixels"})
            renderer = QgsRuleBasedRendererV2(symbol)

        elif layer.name() == 'temporary_polygon':
            symbol = QgsFillSymbolV2().createSimple({"style": "no", "style_border": "no"})
            err_symbol = QgsFillSymbolV2().createSimple({"color_border": err_color, "width_border": "1",
                                                         "style": "no", "style_border": "solid",
                                                         "unit": "pixels"})
            renderer = QgsRuleBasedRendererV2(symbol)

        else:
            self.setDefaultSymbol(layer)

            if geomType == QGis.WKBMultiPolygon or geomType == QGis.WKBPolygon:
                err_symbol = QgsFillSymbolV2().createSimple({"color_border": err_color, "width_border": "2",
                                                             "style": "no", "style_border": "solid",
                                                             "unit": "pixels"})

            elif geomType == QGis.WKBMultiLineString or geomType == QGis.WKBLineString:
                err_symbol = QgsLineSymbolV2().createSimple({"color": err_color, "width": "2", "style": "solid",
                                                             "unit": "pixels"})

            # elif geomType == QGis.WKBMultiPoint or geomType == QGis.WKBPoint:
            else:
                err_symbol = QgsMarkerSymbolV2().createSimple({"name": "circle", "color": err_color,
                                                               "size": "2.5", "outline_style": "no", "unit": "pixels"})

            renderer = layer.rendererV2()

        if isinstance(renderer, QgsSingleSymbolRendererV2):
            symbol = renderer.symbol().clone()

            renderer = QgsRuleBasedRendererV2(symbol)
            root_rule = renderer.rootRule()

        else:
            root_rule = renderer.rootRule()

        err_rule = QgsRuleBasedRendererV2.Rule(err_symbol, filterExp=expr, label=u'오류')

        root_rule.appendChild(err_rule)

        layer.setRendererV2(renderer)
        layer.triggerRepaint()

    def createThumbnail(self, img, tnImg):
        self.logger.info("Create {} thumbnail.".format(os.path.basename(img)))
        result = False

        size = (256, 256)
        try:
            self.logger.info(u"Make a thumbnail from {} to {}".format(img, tnImg))
            im = Image.open(img)
            im.thumbnail(size, Image.ANTIALIAS)
            im.save(tnImg)

            result = True
        except IOError:
            self.logger.error(u"Cannot create thumbnail for {}".format(tnImg))

        return result

    def makePath(self, path):
        try:
            if os.path.exists(path):
                return
            else:
                sub_dir = os.path.dirname(path)
                if not os.path.exists(sub_dir):
                    self.makePath(sub_dir)

                os.mkdir(path)
        except Exception as e:
            self.logger.warning(e)

# -*- coding: utf-8 -*-
"""
논리일관성 검사 내용

1. 개념일관성
    a. 스키마 규칙 준수
    - 미 정의 레이어
    - 레이어의 컬럼 표준 미준수
    - 필수 컬럼의 속성 없음
    - 도형타입 불일치
    - 컬럼타입 불일치
2. 도메인일관성
    a. 코드집 불일치
    - 코드집 미준수
    b. 숫자 오류
    - 숫자 해석 불가 (외부 CAD)
    c. 범위 불일치
    - 소로폭 1.5 아님
    - 차로수 오류
    - 건물 층수 오류
    - 일반주택의 주기
    - 높이값 범위 초과
3. 포맷일관성 - 관리시스템
    a. 납품 포맷
    - 포맷 불일치
    b. 메타데이터
    - 메타데이터 누락
4. 위상일관성
    a. 도형 형상
    - 꼬임선형 객체  LCTCSG01
    - 정점중복선형 객체  LCTCSG02
    - 1 포인트 객체  LCTCSG03
    - 미세면적 객체  LCTCSG04
    - 짧은선형 객체  LCTCSG05
    - 결함있는 연결 (외부 CAD)
    - 언더슛 (외부 CAD)
    - 오버슛 (외부 CAD)
    - 댕글링 (외부 CAD)
    - 슬리버 객체  LCTCSG06
    b.객체 중복
    - 중복객체  LCTCDO01
    - 하천경계/실폭하천  LCTCDO02
    c.등고선 오류
    - 등고선 교차  LCTCEC01
    - 등고선 미연결  LCTCEC02
    - 등고선 단락  LCTCEC03
    - 등고선 꺽임 (외부 CAD)
    d.중심선 누락
    - 차도중심선 누락  LCTCMC01
    - 보도중심선 누락  LCTCMC02
    - 자전거도로중심선/보도경계면   LCTCMC03
    - 철도중심선 누락  LCTCMC05
    - 하천중심선 누락  LCTCMC06
    e.중심선 속성 불일치
    - 차도중신선  LCTCMM01
    - 하천중심선  LCTCMM02
    - 철도중심선  LCTCMM03
    f.경계 불일치
    - 교량경계 불일치  LCTCBM01
    - 터널경계 불일치  LCTCBM02
    - 입체교차부 불일치  LCTCBM03
    g.경계 침범
    - 건물/건물 침범  LCTCBV01
    - 건물/면형구조시설 침범  LCTCBV02
    - 건물/선형구조시설 침범  LCTCBV02
    - 건물/점형구조시설 침범  LCTCBV02
    - 건물/건물부속시설 침범  LCTCBV03
    - 건물/차도 침범  LCTCBV04
    - 건물/보도 침범  LCTCBV05
    - 건물/자전거도로 침범  LCTCBV06
    - 건물/경지 침범  LCTCBV07
    - 건물/산지 침범  LCTCBV08
    - 건물/등고선 침범  LCTCBV09
    - 건물/표고점 침범  LCTCBV10
    - 건물/제방 침범  LCTCBV11
    - 실폭하천/제방 침범  LCTCBV12
    - 하천경계/제방 침범  LCTCBV13
    - 홀과 동일한 객체 존재  LCTCHL01
    - 객체 내부에 객체 존재  LCTCHL02
    h.NFID 무결성
    - 수정/삭제객체 NFID 오류  LCTCNI01
    - 경계면 참조NFID 불일치  LCTCNI02
    - 중심선 NFID 중복  LCTCNI03
"""
import re

from LogicalDBUtil import LogicalDBUtil
from LogicalImgUtil import LogicalImgUtil
from LogicalRestapiUtil import LogicalRestapiUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class LogicalInspector:

    B_CODE = "DLC"  # 논리일관성

    M_CODE = {
        "conceptual": "JCC",  # 개념일관성
        "domain": "JDC",  # 도메인일관성
        "format": "JFC",  # 포맷일관성
        "topological": "JTC"  # 위상일관성
    }

    txtStatus = None
    schemaNm = None
    standardLayerStructure = None

    errInfo = dict()

    def __init__(self, dock):
        self.logger = logger
        
        self.dbUtil = LogicalDBUtil()
        self.imgUtil = LogicalImgUtil(dock, self.dbUtil)
        self.restapiUtil = LogicalRestapiUtil()

    def closeDB(self):
        self.dbUtil.closeDB()

    def getSchema(self):
        return self.dbUtil.INS_SCHEMA

    def dropStdTables(self, schema):
        return self.dbUtil.dropStdTables(schema)

    def createStdTable(self):
        return self.dbUtil.createStdTable()

    def getImgSavePath(self):
        return self.imgUtil.IMG_SAVE_PATH

    def getDbInfo(self):
        return self.dbUtil.getDbInfo()

    def selectTableList(self, shcema):
        return self.dbUtil.selectTableList(shcema)

    def selectStandardLayerStructure(self):
        return self.dbUtil.selectStandardLayerStructure()

    def selectInspectStandard(self, bCode):
        return self.dbUtil.selectInspectStandard(bCode)

    def createErrIndexTable(self, schema):
        return self.dbUtil.createErrIndexTable(schema)

    def exportErrIndex(self, schema, shp):
        return self.dbUtil.exportErrIndex(schema, shp)

    def exportResGpkg(self, schema, gpkg):
        return self.dbUtil.exportResGpkg(schema, gpkg)

    def completeInspect(self, insGroupId):
        return self.restapiUtil.completeInspect(self.B_CODE, insGroupId)

    def inspectConceptual(self, schema, txtStatus, layerList, standardLayerStructure, inspectStd):
        conceptualResult = list()

        self.schemaNm = schema
        self.txtStatus = txtStatus

        for layer in layerList:
            if not standardLayerStructure.has_key(layer):
                continue

            self.txtStatus.setText(u"{} 개념일관성 검사 시작".format(layer))

            # 개념일관성 검사
            insResult = self.__inspectConceptual(layer, inspectStd[self.M_CODE['conceptual']])

            if len(insResult) > 0:
                conceptualResult.extend(insResult)

        return conceptualResult

    def inspectData(self, txtStatus, schema, layerList, standardLayerStructure, inspectStd):
        self.schemaNm = schema
        self.standardLayerStructure = standardLayerStructure  # type: dict

        self.txtStatus = txtStatus

        allLayerList = self.selectTableList(schema)

        try:
            for layer in layerList:
                if not self.standardLayerStructure.has_key(layer):
                    continue

                self.txtStatus.setText(u"{} 검사 시작".format(layer))

                # 기존 오류 정보 가져오기
                self.errInfo = self.dbUtil.selectErrInfo(schema, layer)

                # 도메인일관성 검사
                self.__inspectDomain(layer, inspectStd[self.M_CODE['domain']])

                # 위상일관성 검사
                self.__inspectTopological(layer, allLayerList, inspectStd[self.M_CODE['topological']])

                # 예외 사유 연결
                if len(self.errInfo) > 0:
                    self.dbUtil.updateErrReason(schema, self.errInfo)

                # 오류 리스트 업데이트
                self.dbUtil.updateErrCode(schema, layer)

        except Exception as e:
            self.logger.warning(e, exc_info=True)

    def __inspectConceptual(self, layer, inspectStd):
        failResult = list()
        inspectCodeList = inspectStd.keys()

        for inspectCode in inspectCodeList:
            inspectInfo = inspectStd[inspectCode]
            codeNm = inspectInfo["t_code_nm"]

            self.txtStatus.setText(u"[{}]개념일관성/{}검사".format(layer, codeNm.decode("UTF-8")))
            # 미정의 레이어
            # if inspectCode =='LCCCSR01':
            #     pass

            # 레이어의 컬럼 표준 미준수
            if inspectCode == 'LCCCSR02':
                StdColExist = self.dbUtil.selectStdColExist(self.schemaNm, layer, inspectCode)
                if StdColExist:
                    failResult.append(StdColExist)

            # 필수 컬럼의 속성 없음
            if inspectCode == 'LCCCSR03':
                reqValueExist = self.dbUtil.selectReqValueExist(self.schemaNm, layer, inspectCode)
                if reqValueExist:
                    failResult.append(reqValueExist)

            # 도형타입 불일치
            if inspectCode == 'LCCCSR04':
                geomTypeMatch = self.dbUtil.selectGeomTypeMatch(self.schemaNm, layer, inspectCode)
                if geomTypeMatch:
                    failResult.append(geomTypeMatch)

            # 컬럼타입 불일치
            if inspectCode == 'LCCCSR05':
                ColTypeMatch = self.dbUtil.selectColTypeMatch(self.schemaNm, layer, inspectCode)
                if ColTypeMatch:
                    failResult.append(ColTypeMatch)

        return failResult

    def __inspectDomain(self, layer, inspectStd):
        self.logger.debug(layer)
        emptyList = list()
        self.saveResult(None, layer, 'LCCCSR01', emptyList)
        self.saveResult(None, layer, 'LCCCSR02', emptyList)
        self.saveResult(None, layer, 'LCCCSR03', emptyList)
        self.saveResult(None, layer, 'LCCCSR04', emptyList)
        self.saveResult(None, layer, 'LCCCSR05', emptyList)
        inspectCodeList = inspectStd.keys()
        for inspectCode in inspectCodeList:
            inspectInfo = inspectStd[inspectCode]
            codeNm = inspectInfo["t_code_nm"]
            layerNmKo = self.standardLayerStructure[layer]["layer_nm"]

            self.txtStatus.setText(u"[{}]도메인일관성/{}검사".format(layer, codeNm.decode("UTF-8")))

            # 코드집 미준수
            if inspectCode == 'LCDCCV01':
                codezipMatch = self.dbUtil.selectCodezipMatch(self.schemaNm, layer)
                if len(codezipMatch) > 0:
                    codezipMatch = self.saveImg(layer, inspectCode, codezipMatch)

                self.saveResult(None, layer, inspectCode, codezipMatch)

            # 소로폭 1.5 아님
            if inspectCode == 'LCDCRV01' and layerNmKo == u"차도중심선".encode("UTF-8"):
                roadSoro = self.dbUtil.selectRoadSoro(self.schemaNm, layer,
                                                      self.getAttr(inspectStd[inspectCode]['ins_target_code']),
                                                      inspectStd[inspectCode]['std_val'])
                if len(roadSoro) > 0:
                    roadSoro = self.saveImg(layer, inspectCode, roadSoro)

                self.saveResult(None, layer, inspectCode, roadSoro)

            # 면리간도로 1.6m 이상 ~ 3.0m미만 이외 값 입력
            if inspectCode == 'LCDCRV02' and layerNmKo == u"차도중심선".encode("UTF-8"):
                roadEmd = self.dbUtil.selectRoadEmd(self.schemaNm, layer,
                                                    self.getAttr(inspectStd[inspectCode]['ins_target_code']),
                                                    inspectStd[inspectCode]['std_val'])
                if len(roadEmd) > 0:
                    roadEmd = self.saveImg(layer, inspectCode, roadEmd)

                self.saveResult(None, layer, inspectCode, roadEmd)

            # 실폭차도 3.0m 이상 이외 값 입력
            if inspectCode == 'LCDCRV03' and layerNmKo == u"차도중심선".encode("UTF-8"):
                roadEtc = self.dbUtil.selectRoadEtc(self.schemaNm, layer,
                                                    self.getAttr(inspectStd[inspectCode]['ins_target_code']),
                                                    inspectStd[inspectCode]['std_val'])
                if len(roadEtc) > 0:
                    roadEtc = self.saveImg(layer, inspectCode, roadEtc)

                self.saveResult(None, layer, inspectCode, roadEtc)

            # 차로수 오류
            if inspectCode == 'LCDCRV04' and layerNmKo == u"차도중심선".encode("UTF-8"):
                roadLine = self.dbUtil.selectRoadLine(self.schemaNm, layer,
                                                      self.getAttr(inspectStd[inspectCode]['ins_target_code']),
                                                      inspectStd[inspectCode]['std_val'])
                if len(roadLine) > 0:
                    roadLine = self.saveImg(layer, inspectCode, roadLine)

                self.saveResult(None, layer, inspectCode, roadLine)

            # 건물 층수 오류
            if inspectCode == 'LCDCRV05' and layerNmKo == u"건물".encode("UTF-8"):
                buldFloor = self.dbUtil.selectBuldFloor(self.schemaNm, layer,
                                                        self.getAttr(inspectStd[inspectCode]['ins_target_code']),
                                                        inspectStd[inspectCode]['std_val'])
                if len(buldFloor) > 0:
                    buldFloor = self.saveImg(layer, inspectCode, buldFloor)

                self.saveResult(None, layer, inspectCode, buldFloor)

            # 일반주택의 주기
            if inspectCode == 'LCDCRV06' and layerNmKo == u"건물".encode("UTF-8"):
                buldGeneralHouse = self.dbUtil.selectBuldGeneralHouse(
                    self.schemaNm, layer, self.getAttr(inspectStd[inspectCode]['ins_target_code']))
                if len(buldGeneralHouse) > 0:
                    buldGeneralHouse = self.saveImg(layer, inspectCode, buldGeneralHouse)

                self.saveResult(None, layer, inspectCode, buldGeneralHouse)

            # 높이값 범위 초과
            if inspectCode == 'LCDCRV07' and \
                    (layerNmKo == u"등고선".encode("UTF-8") or layerNmKo == u"표고점".encode("UTF-8")):
                insLayerList = (inspectStd[inspectCode]['ins_target_code']).split(",")

                layerColumn = str()
                for insLayer in insLayerList:
                    if insLayer.startswith(layer.upper()):
                        layerColumn = self.getAttr(insLayer)
                        break

                heighChk = self.dbUtil.selectHeightChk(self.schemaNm, layer, layerColumn,
                                                       inspectStd[inspectCode]['std_val'])
                if len(heighChk) > 0:
                    heighChk = self.saveImg(layer, inspectCode, heighChk)

                self.saveResult(None, layer, inspectCode, heighChk)

    def __inspectTopological(self, layer, layerList, inspectStd):

        geomType = self.dbUtil.selectGeometryType(self.schemaNm, layer)

        if geomType.startswith("MULTI"):
            geomType = geomType[5:]

        colList = self.dbUtil.selectColList(self.schemaNm, layer)
        if 'wkb_geometry' in colList:
            colList.remove('wkb_geometry')

        layerNmKo = self.standardLayerStructure[layer]["layer_nm"]

        viewResult = False
        try:
            if geomType in ["POLYGON", "LINESTRING"]:
                if '{}_points'.format(layer) in self.dbUtil.selectPointTableList(self.schemaNm):
                    viewResult = True
                else:
                    if layerNmKo == u"등고선".encode("UTF-8"):
                        viewResult = self.dbUtil.createPointsViewForCtrln(self.schemaNm, layer, colList)
                    else:
                        viewResult = self.dbUtil.createPointsView(self.schemaNm, layer, geomType, colList)

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            raise Exception(u"{}의 POINT layer를 만드는데 문제가 발생하였습니다.".format(layerNmKo.decode("UTF-8")))

        inspectCodeList = inspectStd.keys()

        try:
            for inspectCode in inspectCodeList:
                inspectInfo = inspectStd[inspectCode]

                codeNm = inspectInfo["t_code_nm"]
                insTargetCode = inspectInfo["ins_target_code"].split(",")

                self.txtStatus.setText(u"[{}]위상일관성/{}검사".format(layer, codeNm.decode("UTF-8")))

                if "ALL" in insTargetCode:
                    if inspectCode == 'LCTCDO01':
                        # 객체 중복
                        resDuplicated = self.dbUtil.selectDuplicatedFeatures(self.schemaNm, layer)

                        if len(resDuplicated) > 0:
                            resDuplicated = self.saveImg(layer, inspectCode, resDuplicated)

                        self.saveResult(None, layer, inspectCode, resDuplicated)

                    if inspectCode == 'LCTCNI01':
                        # 수정/삭제 객체 NFID 검사 / 전체 레이어
                        resNfIdValid = self.dbUtil.selectNfIdValid(self.schemaNm, layer)

                        if len(resNfIdValid) > 0:
                            resNfIdValid = self.saveImg(layer, inspectCode, resNfIdValid)

                        self.saveResult(None, layer, inspectCode, resNfIdValid)

                if geomType in insTargetCode:
                    # 꼬임선형 객체
                    # Polygon, LineString 객체
                    if inspectCode == 'LCTCSG01':
                        resSelfIntersects = self.dbUtil.selectSelfIntersects(self.schemaNm, layer, geomType)

                        if len(resSelfIntersects) > 0:
                            resSelfIntersects = self.saveImg(layer, inspectCode, resSelfIntersects)

                        self.saveResult(None, layer, inspectCode, resSelfIntersects)

                    if layerNmKo != u"등고선".encode("UTF-8"):
                        # 정점중복선형 객체
                        # Polygon, LineString 객체
                        if inspectCode == 'LCTCSG02':
                            if viewResult:
                                resNearVertex = self.dbUtil.selectNearVertex(self.schemaNm, layer)

                                if len(resNearVertex) > 0:
                                    resNearVertex = self.saveImg(layer, inspectCode, resNearVertex)

                                self.saveResult(None, layer, inspectCode, resNearVertex)

                        # 1 포인트 객체
                        if inspectCode == 'LCTCSG03':

                            resSinglePoint = self.dbUtil.selectSinglePoint(self.schemaNm, layer, geomType)
                            if len(resSinglePoint) > 0:
                                resSinglePoint= self.saveImg(layer, inspectCode, resSinglePoint)

                            self.saveResult(None, layer, inspectCode, resSinglePoint)

                        if geomType == 'POLYGON':
                            # 미세면적 객체
                            if inspectCode == 'LCTCSG04':
                                resMicroFeature = self.dbUtil.selectMicroPolygon(self.schemaNm, layer,
                                                                                 inspectInfo["std_val"])
                                if len(resMicroFeature) > 0:
                                    resMicroFeature = self.saveImg(layer, inspectCode, resMicroFeature)

                                self.saveResult(None, layer, inspectCode, resMicroFeature)

                            # 슬리버 객체
                            if inspectCode == 'LCTCSG10':
                                resSliver = self.dbUtil.selectSliver(self.schemaNm, layer, inspectInfo["std_val"])
                                if len(resSliver) > 0:
                                    resSliver = self.saveImg(layer, inspectCode, resSliver)

                                self.saveResult(None, layer, inspectCode, resSliver)

                        elif geomType == 'LINESTRING':
                            # 짧은선형 객체
                            if inspectCode == 'LCTCSG05':
                                resMicroFeature = self.dbUtil.selectMicroLinestring(self.schemaNm, layer,
                                                                                    inspectInfo["std_val"])
                                if len(resMicroFeature) > 0:
                                    resMicroFeature = self.saveImg(layer, inspectCode, resMicroFeature)

                                self.saveResult(None, layer, inspectCode, resMicroFeature)

                if layer.upper() in insTargetCode or layer.upper() in inspectInfo["ins_target_code"]:
                    if layerNmKo == u"등고선".encode("UTF-8"):
                        if viewResult:
                            # 등고선 미연결
                            if inspectCode == 'LCTCEC02':
                                attrList = self.getAttr(insTargetCode[0])

                                resContinuousAttr = self.dbUtil.selectContinuousAttrForCtrln(self.schemaNm, layer,
                                                                                             attrList)
                                if len(resContinuousAttr) > 0:
                                    resContinuousAttr = self.saveImg(layer, inspectCode, resContinuousAttr)

                                self.saveResult(None, layer, inspectCode, resContinuousAttr)

                            # 등고선 단락 검사
                            if inspectCode == 'LCTCEC03':
                                subLayers = [subLayer.lower()
                                              for subLayer in inspectInfo['ins_target_code'].split(',')[1:]]

                                existSubLayers = list()
                                for subLayer in subLayers:
                                    if subLayer in layerList:
                                        existSubLayers.append(subLayer)

                                resCtrlnContinuous = self.dbUtil.selectCtrlnContinuous(self.schemaNm, layer,
                                                                                       existSubLayers)
                                if len(resCtrlnContinuous) > 0:
                                    resCtrlnContinuous = self.saveImg(layer, inspectCode, resCtrlnContinuous)

                                self.saveResult(None, layer, inspectCode, resCtrlnContinuous)

                    if layerNmKo == u"면형도로시설".encode("UTF-8") and inspectCode in ["LCTCBM01", "LCTCBM02", "LCTCBM03"]:
                        # 경계 불일치
                        targetLayerList = inspectInfo['ins_target_code'].split(',')
                        subLayerList = [subLayer.lower() for subLayer in targetLayerList[1:]]
                        # subLayersSet = set(subLayers)
                        # layerListSet = set(layerList)
                        #
                        # subLayers = list(subLayersSet & layerListSet)
                        #
                        # if len(subLayers) == 0:
                        #     continue

                        subLayers = list()
                        for subLayer in subLayerList:
                            if subLayer in layerList:
                                subLayers.append(subLayer)

                        if len(subLayers) == 0:
                            continue

                        attrList = self.getAttr(targetLayerList[0])
                        resContinuousEdge = self.dbUtil.selectContinuousEdgeForArrfc(self.schemaNm, layer, subLayers,
                                                                                     attrList)
                        if len(resContinuousEdge) > 0:
                            resContinuousEdge = self.saveImg(layer, inspectCode, resContinuousEdge)

                        self.saveResult(None, layer, inspectCode, resContinuousEdge)

                    if layerNmKo == u"차도중심선".encode("UTF-8") and inspectCode == "LCTCBM04":
                        # 차도경계면 불일치
                        targetLayerList = inspectInfo['ins_target_code'].split(',')
                        subLayer = targetLayerList[0].lower()

                        if not subLayer in layerList:
                            self.logger.info("{subLayer} is not exist.".format(subLayer=subLayer))
                        else:
                            resContinuousEdgeForRoad = self.dbUtil.selectContinuousEdgeForRoad(self.schemaNm,
                                                                                               layer, subLayer,
                                                                                               inspectInfo["std_val"])
                            if len(resContinuousEdgeForRoad) > 0:
                                resContinuousEdgeForRoad = self.saveImg(layer, inspectCode, resContinuousEdgeForRoad)

                            self.saveResult(None, layer, inspectCode, resContinuousEdgeForRoad)

                    if inspectCode.startswith("LCTCBV") and layerNmKo != u"등고선".encode("UTF-8") :
                        # 경계 침범
                        targetLayerList = inspectInfo['ins_target_code'].split(',')

                        if targetLayerList[0].startswith(layer.upper()):
                            subLayer = ''

                            mainLayerFilter = list()
                            subLayerFilter = list()

                            if inspectCode in ['LCTCBV03', 'LCTCBV09', 'LCTCBV11', 'LCTCBV12', 'LCTCBV13', 'LCTCBV15',
                                               'LCTCBV18']:
                                for targetLayer in targetLayerList:
                                    tmpLayer = targetLayer.split("(")[0].lower()
                                    if tmpLayer == layer:
                                        mainLayerFilter = self.getAttr(targetLayer)
                                    else:
                                        subLayer = tmpLayer
                                        subLayerFilter = self.getAttr(targetLayer)

                                if subLayer not in layerList:
                                    self.logger.info("{subLayer} is not exist.".format(subLayer=subLayer))
                                else:
                                    resIntersectsPolygonToLinestringResult \
                                        = self.dbUtil.selectIntersectsPolygonToLinestring(self.schemaNm,
                                                                                          layer, mainLayerFilter,
                                                                                          subLayer, subLayerFilter,
                                                                                          geomType,
                                                                                          inspectInfo["std_val"],
                                                                                          inspectCode)
                                    if len(resIntersectsPolygonToLinestringResult) > 0:
                                        resIntersectsPolygonToLinestringResult = \
                                            self.saveImg(layer, inspectCode, resIntersectsPolygonToLinestringResult)

                                    self.saveResult(None, layer, inspectCode, resIntersectsPolygonToLinestringResult)

                            elif inspectCode in ['LCTCBV01', 'LCTCBV04', 'LCTCBV05', 'LCTCBV07', 'LCTCBV08',
                                                 'LCTCBV14', 'LCTCBV17', 'LCTCBV19']:
                                if len(targetLayerList) == 1:
                                    subLayer = layer
                                else:
                                    for targetLayer in targetLayerList:
                                        tmpLayer = targetLayer.split("(")[0].lower()
                                        if tmpLayer == layer:
                                            mainLayerFilter = self.getAttr(targetLayer)
                                        else:
                                            subLayer = tmpLayer
                                            subLayerFilter = self.getAttr(targetLayer)

                                if subLayer not in layerList:
                                    self.logger.info("{subLayer} is not exist.".format(subLayer=subLayer))
                                else:
                                    resIntersectsPolygonToPolygonResult \
                                        = self.dbUtil.selectIntersectsPolygonToPolygon(self.schemaNm,
                                                                                       layer, mainLayerFilter,
                                                                                       subLayer, subLayerFilter,
                                                                                       inspectInfo["std_val"],
                                                                                       inspectCode)
                                    if len(resIntersectsPolygonToPolygonResult) > 0:
                                        resIntersectsPolygonToPolygonResult = \
                                            self.saveImg(layer, inspectCode, resIntersectsPolygonToPolygonResult)

                                    self.saveResult(None, layer, inspectCode, resIntersectsPolygonToPolygonResult)

                            else:
                                if len(targetLayerList) == 1:
                                    subLayer = layer
                                else:
                                    for targetLayer in targetLayerList:
                                        tmpLayer = targetLayer.split("(")[0].lower()
                                        if tmpLayer == layer:
                                            mainLayerFilter = self.getAttr(targetLayer)
                                        else:
                                            subLayer = tmpLayer
                                            subLayerFilter = self.getAttr(targetLayer)

                                if subLayer not in layerList:
                                    self.logger.info("{subLayer} is not exist.".format(subLayer=subLayer))
                                else:
                                    resIntersectsResult = self.dbUtil.selectIntersects(self.schemaNm,
                                                                                       layer, mainLayerFilter,
                                                                                       subLayer, subLayerFilter,
                                                                                       geomType)
                                    if len(resIntersectsResult) > 0:
                                        resIntersectsResult = self.saveImg(layer, inspectCode, resIntersectsResult)

                                    self.saveResult(None, layer, inspectCode, resIntersectsResult)

                    if inspectCode.startswith("LCTCMM"):
                        # 중심선 속성 불일치
                        # 차도중신선, 하천중심선, 철도중심선
                        targetLayer = inspectInfo['ins_target_code']  # type: str

                        if targetLayer.startswith(layer.upper()):
                            attrList = self.getAttr(targetLayer)

                            if viewResult:
                                resContinuousAttr = self.dbUtil.selectContinuousAttr(self.schemaNm, layer, attrList)
                                if len(resContinuousAttr) > 0:
                                    resContinuousAttr = self.saveImg(layer, inspectCode, resContinuousAttr)

                                self.saveResult(None, layer, inspectCode, resContinuousAttr)

                    if inspectCode.startswith("LCTCMC"):
                        # 중심선 누락
                        # 차도중심선 누락, 보도중심선 누락, 철도중심선 누락, 하천중심선 누락
                        targetLayerList = inspectInfo['ins_target_code'].split(',')

                        mainLayer = targetLayerList
                        if targetLayerList[0] == layer.upper():
                            subLayer = targetLayerList[1].lower()

                            if not subLayer in layerList:
                                self.logger.info("{subLayer} is not exist.".format(subLayer=subLayer))
                            else:
                                if layerNmKo == u"차도경계면".encode("UTF-8"):
                                    joinFilter = "WHERE COALESCE(a.refnf_id, '') != '' AND a.refnf_id = COALESCE(b.nf_id, '') "
                                else:
                                    joinFilter = "WHERE ST_Intersects(a.wkb_geometry, b.wkb_geometry) " \
                                                 "AND ST_Length(ST_Intersection(a.wkb_geometry, b.wkb_geometry))/" \
                                                 "ST_Length(b.wkb_geometry) > 0.95"

                                resCheckCenterline = self.dbUtil.selectCheckCenterLine(self.schemaNm, layer, subLayer,
                                                                                       joinFilter)
                                if len(resCheckCenterline) > 0:
                                    resCheckCenterline = self.saveImg(layer, inspectCode, resCheckCenterline)

                                self.saveResult(None, layer, inspectCode, resCheckCenterline)

                    if inspectCode == 'LCTCHL01':
                        # hole 동일 객체 검사
                        # 건물, 경지경계, 실폭하천, 호소
                        resHoleFeature = self.dbUtil.selectHoleFeature(self.schemaNm, layer)

                        if len(resHoleFeature) > 0:
                            resHoleFeature = self.saveImg(layer, inspectCode, resHoleFeature)

                        self.saveResult(None, layer, inspectCode, resHoleFeature)

                if inspectCode.startswith('LCTCNI'):
                    if inspectCode == 'LCTCNI02' and layerNmKo == u"차도경계면".encode("UTF-8"):
                        # 참조 NFID 검사 / 신규 객체 경계면
                        targetLayerList = inspectInfo['ins_target_code'].split(',')

                        subLayer = targetLayerList[1].lower()

                        if not subLayer in layerList:
                            self.logger.info("{subLayer} is not exist.".format(subLayer=subLayer))
                        else:
                            resRefNfIdValid = self.dbUtil.selectRefNfIdValid(self.schemaNm, layer, subLayer)
                            if len(resRefNfIdValid) > 0:
                                resRefNfIdValid = self.saveImg(layer, inspectCode, resRefNfIdValid)

                            self.saveResult(None, layer, inspectCode, resRefNfIdValid)

                    elif inspectCode == 'LCTCNI03'and layerNmKo == u"차도중심선".encode("UTF-8"):
                        # 중심선 NFID 중복 검사 / 외부 신규 객체
                        resDuplicateNfId = self.dbUtil.selectDuplicateNfId(self.schemaNm, layer)
                        if len(resDuplicateNfId) > 0:
                            resDuplicateNfId = self.saveImg(layer, inspectCode, resDuplicateNfId)

                        self.saveResult(None, layer, inspectCode, resDuplicateNfId)

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            raise Exception(u"{} 검사를 진행하는 도중 문제가 발생하였습니다.".format(codeNm.decode("UTF-8")))

    def saveImg(self, layer, inspectCode, result):
        imgRes = self.imgUtil.saveImg(self.schemaNm, layer, inspectCode, result, self.errInfo)

        return imgRes

    def saveResult(self, insGroupId, table, inspectCode, res):
        insResult = {
            "result": [{
                "bCode": "DLC",
                "insGroupId": insGroupId,
                "layerId": table.upper(),
                "insTCode": inspectCode,
                "errFeatureList": res
            }]
        }

        self.restapiUtil.saveResult(insResult)

    def updateException(self, schema):
        exceptionInfo = self.dbUtil.selectExceptionInfo(schema)
        self.updateResCode(exceptionInfo)

    def updateResCode(self, data):
        self.restapiUtil.updateResCode(data)

    def getAttr(self, layer):
        attrList = list()

        # TODO 정규식 확인 필요 "/"가 있을때
        p = re.compile("^[A-Z_]+\((.*)\)$")
        m = p.match(layer)

        if m:
            attrStr = m.group(1)
            attrList = attrStr.split("/")

        return attrList

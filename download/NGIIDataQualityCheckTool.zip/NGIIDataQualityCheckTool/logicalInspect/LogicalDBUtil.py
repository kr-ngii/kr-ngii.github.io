# -*- coding: utf-8 -*-
import psycopg2
from psycopg2.sql import SQL, Identifier
import threading, time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

from ..util.DBUtil import DBUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking query
class DBThread(threading.Thread):
    def __init__(self, cursor, query, param):
        self.cursor = cursor
        self.query = query
        self.param = param
        threading.Thread.__init__(self)

    def run(self):
        if self.param is None:
            self.cursor.execute(self.query)
        else:
            self.cursor.execute(self.query, self.param)

        return


def threadExecuteSql(cursor, sql, param=None):
    dbt = DBThread(cursor, sql, param)
    dbt.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class LogicalDBUtil(DBUtil):

    def __init__(self):
        DBUtil.__init__(self)
        self.logger = logger

    def closeDB(self):
        self.conn.close()

    def createPointsView(self, schema, table, geomType, col_list):
        result = False

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        view_nm = "{table}_points".format(table=table)
        index_1 = "{table}_points_pk_idx".format(table=table)
        index_2 = "{table}_points_gist".format(table=table)

        if geomType.endswith("POLYGON"):
            path_num = SQL("2")
            point_index = SQL("3")
        else:
            path_num = SQL("1")
            point_index = SQL("2")

        identifier_col_list = list()
        for col_nm in col_list:
            # if col_nm == 'NF_ID':
            #     col_nm = 'cid'

            identifier_col_list.append(Identifier(col_nm.lower()))

        try:
            createSql = self.sqlStatement.get("SQL", "createPointsView")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                col_list=SQL(', ').join(identifier_col_list),
                                                                view=Identifier(view_nm),
                                                                path_num=path_num,
                                                                point_index=point_index,
                                                                index_1=Identifier(index_1),
                                                                index_2=Identifier(index_2))))
            threadExecuteSql(cur, SQL(createSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        col_list=SQL(', ').join(identifier_col_list),
                                                        view=Identifier(view_nm),
                                                        path_num=path_num,
                                                        point_index=point_index,
                                                        index_1=Identifier(index_1),
                                                        index_2=Identifier(index_2)))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            self.conn.rollback()

        else:
            self.conn.commit()

        if cur:
            cur.close()

        self.vacuumSchema(schema, [view_nm])

        return result

    def createPointsViewForCtrln(self, schema, table, col_list):
        result = False

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        view_nm = "{table}_points".format(table=table)
        index = "{table}_points_gist".format(table=table)

        identifier_col_list = list()
        for col_nm in col_list:
            if col_nm == 'NF_ID':
                col_nm = 'cid'
            identifier_col_list.append(Identifier(col_nm.lower()))

        try:
            createSql = self.sqlStatement.get("SQL", "createPointsViewForCtrln")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                col_list=SQL(', ').join(identifier_col_list),
                                                                view=Identifier(view_nm),
                                                                index=Identifier(index))))
            threadExecuteSql(cur, SQL(createSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        col_list=SQL(', ').join(identifier_col_list),
                                                        view=Identifier(view_nm),
                                                        index=Identifier(index)))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            self.conn.rollback()

        else:
            self.conn.commit()

        if cur:
            cur.close()

        self.vacuumSchema(schema, [view_nm])

        return result

    def selectGeometryType(self, schema, table):
        geomType = ''
        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectGeometryType")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema": schema, "table": table}))
            threadExecuteSql(cur, SQL(selectSql), {"schema": schema, "table": table})
            sqlResults = cur.fetchone()

            geomType = sqlResults[0]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return geomType

    # 도형 꼬임 검사
    def selectSelfIntersects(self, schema, table, geomType):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            if geomType == 'POLYGON':
                selectSql = self.sqlStatement.get("SQL", "selectSelfIntersectsForPolygon")
            else:
                selectSql = self.sqlStatement.get("SQL", "selectSelfIntersectsForLinestring")

            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    # 1 포인트 객체 검사
    def selectSinglePoint(self, schema, table, geomType):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        if geomType.endswith("POLYGON"):
            stdVal = 3
        else:
            stdVal = 2

        try:
            selectSql = self.sqlStatement.get("SQL", "selectSinglePoint")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table)),
                                          {"stdVal": stdVal}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)),
                             {"stdVal": stdVal})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    # 미세 폴리곤 검사
    def selectMicroPolygon(self, schema, table, std_val):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            val = float(std_val.split(",")[1])

            selectSql = self.sqlStatement.get("SQL", "selectMicroPolygon")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table)),
                                          {"val": val}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)), {"val": val})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectMicroLinestring(self, schema, table, std_val):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            val = float(std_val.split(",")[1])

            # TODO: 변화 정보 쿼리 추가
            selectSql = self.sqlStatement.get("SQL", "selectMicroLinestring")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table)),
                                          {"val": val}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)),
                             {"val": val})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectSliver(self, schema, table, std_val):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:

            std_val_list = std_val.split(",")
            t = float(std_val_list[1])
            area = float(std_val_list[0])

            selectSql = self.sqlStatement.get("SQL", "selectSliver")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table)),
                                          {"t": t, "area": area}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)),
                             {"t": t, "area": area})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    # 근접 vertex 검사
    def selectNearVertex(self, schema, table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            view_nm = "{table}_points".format(table=table)
            selectSql = self.sqlStatement.get("SQL", "selectNearVertex")

            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(view_nm))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema), table=Identifier(view_nm)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                geom_list = sqlResult[2]

                res = {
                    "cid": sqlResult[0],
                    "details": list()
                }

                for geom in geom_list:
                    res["details"].append(
                        {
                            "refCid": "",
                            "refNfId": "",
                            "refLayerId": "",
                            "colId": "",
                            "colVal": "",
                            "tmp_geom": geom,
                            "resCode": "IVS005",
                        }
                    )

                selectResult.append(res)

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectDuplicatedFeatures(self, schema, table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectDuplicatedFeatures")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                main_cid = sqlResult[0][0]

                res_cidList = [ref[0] for ref in sqlResult[1]]
                res_nfid_list = [ref[1] for ref in sqlResult[1]]

                selectResult.append(
                    {
                        "cid": main_cid,
                        "details": [
                            {
                                "refCid": ','.join(res_cidList),
                                "refNfId": ','.join(res_nfid_list),
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    # TODO: 삭제
    def selectRiverDuplicatedFeatures(self, schema, table, sub_table, inspectCode):
        selectResult = list()
        cids = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectRiverDuplicatedFeatures")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                river_bt=Identifier(table),
                                                                river_bndry=Identifier(sub_table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        river_bt=Identifier(table),
                                                        river_bndry=Identifier(sub_table)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                cids.append(sqlResult[0][0])

                res_cidList = [ref[0] for ref in sqlResult[1]]
                res_nfid_list = [ref[1] for ref in sqlResult[1]]

                selectResult.append(
                    {
                        "cid": sqlResult[0][0],
                        "insTCode": inspectCode,
                        "nfid": sqlResult[0][1],
                        "passGb": "N",
                        "errReason": "",
                        "details": [
                            {
                                "colId": "",
                                "colNm": "",
                                "colVal": "",
                                "refCid": ','.join(res_cidList),
                                "refNfid": ','.join(res_nfid_list),
                                "refLayerNm": sub_table,
                                "refImg": ""
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return cids, selectResult

    def selectIntersects(self, schema, table, main_attr_filter, sub_table, sub_attr_filter, geomType):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        filter_sql = 'AND {col_nm} IN %(attrList)s'

        main_filter = ''
        sub_filter = ''

        if main_attr_filter and len(main_attr_filter) != 0:
            tmp_table_nm = table.split("_")[1:]

            if len(tmp_table_nm) == 1:
                col_nm = "{table_nm}_se".format(table_nm=tmp_table_nm[0])
            else:
                add_on = ''
                if tmp_table_nm[1] == 'fclty':
                    add_on = 'fc'
                col_nm = "{table_nm}{add_on}_se".format(table_nm=tmp_table_nm[0][:5], add_on=add_on)

            main_filter = cur.mogrify(SQL(filter_sql).format(col_nm=Identifier(col_nm)),
                                      {"attrList": tuple(main_attr_filter)})

        if sub_attr_filter and len(sub_attr_filter) != 0:
            tmp_table_nm = sub_table.split("_")[1:]

            if len(tmp_table_nm) == 1:
                col_nm = "{table_nm}_se".format(table_nm=tmp_table_nm[0])
            else:
                add_on = ''
                if tmp_table_nm[1] == 'fclty':
                    add_on = 'fc'
                col_nm = "{table_nm}{add_on}_se".format(table_nm=tmp_table_nm[0][:-1], add_on=add_on)

            sub_filter = cur.mogrify(SQL(filter_sql).format(col_nm=Identifier(col_nm)),
                                     {"attrList": tuple(sub_attr_filter)})

        geomErrFilter = 'ST_NPoints(wkb_geometry) >= 3 AND ST_isValid(wkb_geometry)'

        if geomType == 'POLYGON':
            if main_filter == '':
                main_filter = "AND {filter}".format(filter=geomErrFilter.format(schema=schema, table=table))
            else:
                main_filter = "{attrFilter} AND {geomFilter}".format(attrFilter=main_filter, geomFilter=geomErrFilter)
        else:
            if sub_filter == '':
                sub_filter = "AND {filter}".format(filter=geomErrFilter.format(schema=schema, table=sub_table))
            else:
                sub_filter = "{attrFilter} AND {geomFilter}".format(attrFilter=sub_filter, geomFilter=geomErrFilter)

        try:
            selectSql = self.sqlStatement.get("SQL", "selectIntersects")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                sub_table=Identifier(sub_table),
                                                                main_filter=SQL(main_filter),
                                                                sub_filter=SQL(sub_filter))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        sub_table=Identifier(sub_table),
                                                        main_filter=SQL(main_filter),
                                                        sub_filter=SQL(sub_filter)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                main_cid = sqlResult[0][0]

                res_cidList = [ref[0] for ref in sqlResult[1]]
                res_nfid_list = [ref[1] for ref in sqlResult[1]]

                selectResult.append(
                    {
                        "cid": main_cid,
                        "details": [
                            {
                                "refCid": ','.join(res_cidList),
                                "refNfId": ','.join(res_nfid_list),
                                "refLayerId": sub_table,
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectIntersectsPolygonToLinestring(self, schema, table, main_attr_filter, sub_table, sub_attr_filter,
                                            main_geomType, std_val, inspectCode):
        selectResult = list()

        if inspectCode in ['LCTCBV18']:
            resCode = "IVS004"
        else:
            resCode = "IVS005"

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        filter_sql = 'AND {col_nm} IN %(attrList)s'

        main_filter = ''
        sub_filter = ''

        if main_attr_filter and len(main_attr_filter) != 0:
            tmp_table_nm = table.split("_")[1:]

            if len(tmp_table_nm) == 1:
                col_nm = "{table_nm}_se".format(table_nm=tmp_table_nm[0])
            else:
                add_on = ''
                if tmp_table_nm[1] == 'fclty':
                    add_on = 'fc'
                col_nm = "{table_nm}{add_on}_se".format(table_nm=tmp_table_nm[0][:5], add_on=add_on)

            main_filter = cur.mogrify(SQL(filter_sql).format(col_nm=Identifier(col_nm)),
                                      {"attrList": tuple(main_attr_filter)})

        if sub_attr_filter and len(sub_attr_filter) != 0:
            tmp_table_nm = sub_table.split("_")[1:]

            if len(tmp_table_nm) == 1:
                col_nm = "{table_nm}_se".format(table_nm=tmp_table_nm[0])
            else:
                add_on = ''
                if tmp_table_nm[1] == 'fclty':
                    add_on = 'fc'
                col_nm = "{table_nm}{add_on}_se".format(table_nm=tmp_table_nm[0][:-1], add_on=add_on)

            sub_filter = cur.mogrify(SQL(filter_sql).format(col_nm=Identifier(col_nm)),
                                     {"attrList": tuple(sub_attr_filter)})

        if main_geomType == 'POLYGON':
            polygon_table = table
            polygon_id = 'main_id'
            mainPointLimit = 3
            subPointLimit = 2
        else:
            polygon_table = sub_table
            polygon_id = 'sub_id'
            mainPointLimit = 2
            subPointLimit = 3

        geomErrFilter = 'ST_NPoints(wkb_geometry) >= {limit} AND ST_isValid(wkb_geometry)'

        if main_filter == '':
            main_filter = "AND {filter}".format(filter=geomErrFilter.format(limit=mainPointLimit))
        else:
            main_filter = "{attrFilter} AND {geomFilter}".format(attrFilter=main_filter,
                                                                 geomFilter=geomErrFilter.format(limit=mainPointLimit))

        if sub_filter == '':
            sub_filter = "AND {filter}".format(filter=geomErrFilter.format(limit=subPointLimit))
        else:
            sub_filter = "{attrFilter} AND {geomFilter}".format(attrFilter=sub_filter,
                                                                geomFilter=geomErrFilter.format(limit=subPointLimit))

        try:
            selectSql = self.sqlStatement.get("SQL", "selectIntersectsPolygonToLinestring")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                sub_table=Identifier(sub_table),
                                                                main_filter=SQL(main_filter),
                                                                sub_filter=SQL(sub_filter),
                                                                polygon_table=Identifier(polygon_table),
                                                                polygon_id=Identifier(polygon_id)),
                                          {"std_val": float(std_val)}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        sub_table=Identifier(sub_table),
                                                        main_filter=SQL(main_filter),
                                                        sub_filter=SQL(sub_filter),
                                                        polygon_table=Identifier(polygon_table),
                                                        polygon_id=Identifier(polygon_id)),
                             {"std_val": float(std_val)})
            sqlResults = cur.fetchall()

            tmpDict = dict()
            for sqlResult in sqlResults:
                main_cid = sqlResult[0][0]

                res_cid = sqlResult[1][0]
                res_nfid = sqlResult[1][1]

                if main_cid not in tmpDict.keys():
                    tmpDict[main_cid] = {
                        "cid": main_cid,
                        "details": list()
                    }

                geomList = sqlResult[2]
                for geom in geomList:
                    tmpDict[main_cid]["details"].append({
                        "refCid": res_cid,
                        "refNfId": res_nfid,
                        "refLayerId": sub_table,
                        "colId": "",
                        "colVal": "",
                        "resCode": resCode,
                        "tmp_geom": geom
                    })

            for key in tmpDict.keys():
                selectResult.append(tmpDict[key])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectIntersectsPolygonToPolygon(self, schema, table, main_attr_filter, sub_table, sub_attr_filter,
                                         std_val, inspectCode):
        selectResult = list()

        if inspectCode in ['LCTCBV04', 'LCTCBV07', 'LCTCBV08', 'LCTCBV17', 'LCTCBV18']:
            resCode = "IVS004"
        else:
            resCode = "IVS005"

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        filter_sql = 'AND {col_nm} IN %(attrList)s'

        main_filter = ''
        sub_filter = ''

        if main_attr_filter and len(main_attr_filter) != 0:
            tmp_table_nm = table.split("_")[1:]

            if len(tmp_table_nm) == 1:
                col_nm = "{table_nm}_se".format(table_nm=tmp_table_nm[0])
            else:
                add_on = ''
                if tmp_table_nm[1] == 'fclty':
                    add_on = 'fc'
                col_nm = "{table_nm}{add_on}_se".format(table_nm=tmp_table_nm[0][:5], add_on=add_on)

            main_filter = cur.mogrify(SQL(filter_sql).format(col_nm=Identifier(col_nm)),
                                      {"attrList": tuple(main_attr_filter)})

        if sub_attr_filter and len(sub_attr_filter) != 0:
            tmp_table_nm = sub_table.split("_")[1:]

            if len(tmp_table_nm) == 1:
                col_nm = "{table_nm}_se".format(table_nm=tmp_table_nm[0])
            else:
                add_on = ''
                if tmp_table_nm[1] == 'fclty':
                    add_on = 'fc'
                col_nm = "{table_nm}{add_on}_se".format(table_nm=tmp_table_nm[0][:-1], add_on=add_on)

            sub_filter = cur.mogrify(SQL(filter_sql).format(col_nm=Identifier(col_nm)),
                                     {"attrList": tuple(sub_attr_filter)})

        geomErrFilter = 'ST_NPoints(wkb_geometry) >= 3 AND ST_isValid(wkb_geometry)'

        if main_filter == '':
            main_filter = "AND {filter}".format(filter=geomErrFilter.format(schema=schema, table=table))
        else:
            main_filter = "{attrFilter} AND {geomFilter}".format(attrFilter=main_filter, geomFilter=geomErrFilter)

        if sub_filter == '':
            sub_filter = "AND {filter}".format(filter=geomErrFilter.format(schema=schema, table=sub_table))
        else:
            sub_filter = "{attrFilter} AND {geomFilter}".format(attrFilter=sub_filter, geomFilter=geomErrFilter)

        not_eq_filter = ""
        if table == sub_table:
            not_eq_filter = 'AND a.cid != b.cid'

        try:
            selectSql = self.sqlStatement.get("SQL", "selectIntersectsPolygonToPolygon")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                sub_table=Identifier(sub_table),
                                                                main_filter=SQL(main_filter),
                                                                sub_filter=SQL(sub_filter),
                                                                not_eq_filter=SQL(not_eq_filter)),
                                          {"std_val": float(std_val)}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        sub_table=Identifier(sub_table),
                                                        main_filter=SQL(main_filter),
                                                        sub_filter=SQL(sub_filter),
                                                        not_eq_filter=SQL(not_eq_filter)),
                             {"std_val": float(std_val)})
            sqlResults = cur.fetchall()

            tmpDict = dict()
            for sqlResult in sqlResults:
                main_cid = sqlResult[0][0]

                res_cid = sqlResult[1][0]
                res_nfid = sqlResult[1][1]

                if main_cid not in tmpDict.keys():
                    tmpDict[main_cid] = {
                        "cid": main_cid,
                        "details": list()
                    }

                geomList = sqlResult[2]
                for geom in geomList:
                    tmpDict[main_cid]["details"].append({
                        "refCid": res_cid,
                        "refNfId": res_nfid,
                        "refLayerId": sub_table,
                        "colId": "",
                        "colVal": "",
                        "tmp_geom": geom,
                        "resCode": resCode
                    })

            for key in tmpDict.keys():
                selectResult.append(tmpDict[key])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectCheckCenterLine(self, schema, table, subTable, joinFilter):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectCheckCenterLine")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                bndry=Identifier(table),
                                                                ctln=Identifier(subTable),
                                                                join_filter=SQL(joinFilter))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        bndry=Identifier(table),
                                                        ctln=Identifier(subTable),
                                                        join_filter=SQL(joinFilter)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": subTable,
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectContinuousAttr(self, schema, table, column_list):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        attr_filter = list()
        point_table = '{}_points'.format(table)

        for column_nm in column_list:
            attr_filter.append(SQL("COALESCE({column_nm}, '')")
                               .format(column_nm=Identifier(column_nm.lower())))

        try:
            selectSql = self.sqlStatement.get("SQL", "selectContinuousAttr")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                view=Identifier(point_table),
                                                                table=Identifier(table),
                                                                attrList=SQL(', ').join(attr_filter))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        view=Identifier(point_table),
                                                        table=Identifier(table),
                                                        attrList=SQL(', ').join(attr_filter)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append({
                    "cid": sqlResult[0],
                    "details": [
                        {
                            "refCid": "",
                            "refNfId": "",
                            "refLayerId": "",
                            "colId": "",
                            "colVal": "",
                            "resCode": "IVS005"
                        }
                    ]
                })

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectContinuousAttrForCtrln(self, schema, table, column_list):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        attr_filter = list()
        point_table = '{}_points'.format(table)

        for column_nm in column_list:
            attr_filter.append(
                SQL("COALESCE(a.{filter}, 0) != COALESCE(b.{filter}, 0)").format(filter=Identifier(column_nm.lower())))

        try:
            selectSql = self.sqlStatement.get("SQL", "selectContinuousAttrForCtrln")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                view=Identifier(point_table),
                                                                attr_filter=SQL(' OR ').join(attr_filter))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        view=Identifier(point_table),
                                                        attr_filter=SQL(' OR ').join(attr_filter)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append({
                    "cid": sqlResult[0],
                    "details": [
                        {
                            "refCid": "",
                            "refNfId": "",
                            "refLayerId": "",
                            "colId": "",
                            "colVal": "",
                            "resCode": "IVS005"
                        }
                    ]
                })

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectContinuousEdgeForArrfc(self, schema, table, sub_tables, attrList):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        sub_query_sql = list()

        sub_query_sql_str = """
            SELECT a.cid FROM filter AS a, {schema}.{sub_layer} AS b
            WHERE COALESCE(b.obchg_se, '') != (SELECT code FROM qiresult.com_code WHERE code_nm = '삭제')
            AND ST_NPoints(b.wkb_geometry) >= 3 AND ST_isValid(b.wkb_geometry)
            AND ST_Intersects(b.wkb_geometry, a.wkb_geometry)
            AND ST_Area(ST_Intersection(b.wkb_geometry, a.wkb_geometry))/ST_Area(a.wkb_geometry) > 0.95
        """

        for sub_table_nm in sub_tables:
            tmp_sql = SQL(sub_query_sql_str).format(schema=Identifier(schema), sub_layer=Identifier(sub_table_nm))
            sub_query_sql.append(tmp_sql)

        try:
            selectSql = self.sqlStatement.get("SQL", "selectContinuousEdgeForArrfc")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                sub_query=SQL(' EXCEPT ').join(sub_query_sql)),
                                          {"attrList": tuple(attrList)}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        sub_query=SQL(' EXCEPT ').join(sub_query_sql)),
                             {"attrList": tuple(attrList)})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0][0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": ','.join(sub_tables),
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectContinuousEdgeForRoad(self, schema, table, sub_table, stdVal):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectContinuousEdgeForRoad")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                sub_table=Identifier(sub_table)),
                                          {"stdVal": stdVal}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        sub_table=Identifier(sub_table)),
                             {"stdVal":stdVal})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": sub_table,
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    # 등고선 단락 검사
    def selectCtrlnContinuous(self, schema, table, subTable):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        view = '{}_points'.format(table)

        sub_query_sql = [SQL("SELECT cid, n, flag FROM err")]

        sub_query_sql_str = """
            SELECT a.cid, a.n, a.flag FROM err AS a, {schema}.{table} AS b
            WHERE b.obchg_se != (SELECT code FROM qiresult.com_code WHERE code_nm = '삭제')
            AND ST_DWithin(a.geom, b.wkb_geometry, 0.1)
        """

        for subTable_nm in subTable:
            tmp_sql = SQL(sub_query_sql_str).format(schema=Identifier(schema), table=Identifier(subTable_nm))
            sub_query_sql.append(tmp_sql)

        try:
            selectSql = self.sqlStatement.get("SQL", "selectCtrlnContinuous")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                view=Identifier(view),
                                                                sub_query=SQL(' EXCEPT ').join(sub_query_sql))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        view=Identifier(view),
                                                        sub_query=SQL(' EXCEPT ').join(sub_query_sql)))
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                geom_list = sqlResult[1]

                res = {
                    "cid": sqlResult[0][0],
                    "details": list()
                }

                for geom in geom_list:
                    res["details"].append(
                        {
                            "refCid": "",
                            "refNfId": "",
                            "refLayerId": ','.join(subTable),
                            "colId": "",
                            "colVal": "",
                            "resCode": "IVS005",
                            "tmp_geom": geom
                        }
                    )

                selectResult.append(res)

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    # hole 동일 객체
    def selectHoleFeature(self, schema, table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectHoleFeature")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "",
                                "colVal": "",
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectStdColExist(self, schema, table, inspectCode):
        failResult = None
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return failResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectStdColExist")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema": schema, "table": table}))
            threadExecuteSql(cur, SQL(selectSql), {"schema": schema, "table": table})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                failResult = {
                    "inspectCode": inspectCode,
                    "layer_id": table,
                    "col_list": sqlResult[0]
                }

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return failResult

    def selectReqValueExist(self, schema, table, inspectCode):
        failResult = None
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return failResult
        try:
            colSql = self.sqlStatement.get("SQL", "selectReqValueChk")
            self.logger.debug(cur.mogrify(SQL(colSql), {"schema": schema, "table": table}))
            threadExecuteSql(cur, SQL(colSql), {"schema": schema, "table": table})

            colRes = cur.fetchall()

            if len(colRes) > 0:
                colList = [i[0] for i in colRes]

                selectStr = ', '.join(colList)
                whereStr = ' IS NULL OR '.join(colList) + " IS NULL "

                if table == 'tn_rodway_ctln':
                    whereStr += ' OR nf_id IS NULL'

                selectSql = self.sqlStatement.get("SQL", "selectReqValueExist")
                self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table),
                                                                    columnNm=SQL(selectStr),
                                                                    condition=SQL(whereStr))))

                threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                            table=Identifier(table),
                                                            columnNm=(SQL(selectStr)),
                                                            condition=(SQL(whereStr))))
                sqlResults = cur.fetchall()

                res = None

                for sqlResult in sqlResults:

                    if not res:
                        res = {
                            "inspectCode": inspectCode,
                            "layer_id": table,
                            "col_list": selectStr,
                            "cid_list": list()
                        }

                    res['cid_list'].append(sqlResult[0])

                failResult = res

                self.logger.debug(failResult)

        except Exception as e:
            self.logger.warning(e)
        if cur:
            cur.close()

        return failResult

    def selectGeomTypeMatch(self, schema, table, inspectCode):
        failResult = None
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return failResult

        try:
            selectSql = self.sqlStatement.get("SQL", "selectGeomTypeMatch")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema": schema, "table": table}))
            threadExecuteSql(cur, SQL(selectSql), {"schema": schema, "table": table})

            sqlResult = cur.fetchone()

            resFlag = sqlResult[4]

            if not resFlag:
                failResult = {
                    "inspectCode": inspectCode,
                    "layer_id": table
                }

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return failResult

    def selectColTypeMatch(self, schema, table, inspectCode):
        failResult = None
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return failResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectColTypeMatch")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema": schema, "table": table}))
            threadExecuteSql(cur, SQL(selectSql), {"schema": schema, "table": table})
            sqlResult = cur.fetchone()

            if sqlResult:
                failResult = {
                    "inspectCode": inspectCode,
                    "layer_id": table,
                    "col_list": sqlResult[0]
                }

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return failResult

    def selectCodezipMatch(self, schema, table):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            # 코드가 있는 칼럼 리스트 조회
            colSql = self.sqlStatement.get("SQL", "selectCodezipChk")
            self.logger.debug(cur.mogrify(SQL(colSql), {"schema": schema, "table": table}))
            threadExecuteSql(cur, SQL(colSql), {"schema": schema, "table": table})

            colList = cur.fetchall()

            if len(colList) > 0:
                selectStr = ''
                caseStr = "case when {column} IN (SELECT code FROM qiresult.std_codezip " \
                          "WHERE codezip_id = '{colCode}') THEN 't' ELSE {column} END"
                whereStr = ''
                for i in range(len(colList)):
                    if i == len(colList) - 1:
                        selectStr += caseStr.format(column=colList[i][0], colCode=colList[i][1])
                        whereStr += colList[i][0] + " != 't'"
                    else:
                        selectStr += caseStr.format(column=colList[i][0], colCode=colList[i][1]) + ','
                        whereStr += colList[i][0] + "!= 't' OR "

                selectSql = self.sqlStatement.get("SQL", "selectCodezipMatch")
                self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table),
                                                                    columnNm=SQL(selectStr),
                                                                    condition=SQL(whereStr))))

                threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                            table=Identifier(table),
                                                            columnNm=(SQL(selectStr)),
                                                            condition=(SQL(whereStr))))
                sqlResults = cur.fetchall()
                for sqlResult in sqlResults:
                    res = {
                        "cid": sqlResult[0],
                        "details": list()
                    }
                    for j in range(2, len(sqlResult)):
                        if sqlResult[j] != 't':
                            res["details"].append(
                                {
                                    "refCid": "",
                                    "refNfId": "",
                                    "refLayerId": "",
                                    "colId": colList[j-2][0],
                                    "colVal": sqlResult[j],
                                    "resCode": "IVS005",
                                }
                            )

                    selectResult.append(res)

        except Exception as e:
            self.logger.warning(e)
        if cur:
            cur.close()
        return selectResult

    def selectRoadSoro(self, schema, table, attrList, stdVal):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return selectResult

        try:

            selectSql = self.sqlStatement.get("SQL", "selectRoadSoro")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                roadSe=Identifier(attrList[0].lower()),
                                                                roadBt=Identifier(attrList[2].lower())),
                                          {"roadSe": attrList[1], "stdVal": float(stdVal)}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        roadSe=Identifier(attrList[0].lower()),
                                                        roadBt=Identifier(attrList[2].lower())),
                             {"roadSe": attrList[1], "stdVal": float(stdVal)})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "ROAD_BT",
                                "colVal": sqlResult[2],
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return selectResult

    def selectRoadEmd(self, schema, table, attrList, stdVal):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()
        valList = stdVal.split(",")

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectRoadEmd")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                roadSe=Identifier(attrList[0].lower()),
                                                                roadBt=Identifier(attrList[2].lower())),
                                          {"roadSe": attrList[1], "min": valList[0], "max": valList[1]}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        roadSe=Identifier(attrList[0].lower()),
                                                        roadBt=Identifier(attrList[2].lower())),
                             {"roadSe": attrList[1], "min": float(valList[0]), "max": float(valList[1])})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "ROAD_BT",
                                "colVal": sqlResult[2],
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)
        if cur:
            cur.close()
        return selectResult

    def selectRoadEtc(self, schema, table, attrList, stdVal):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()
        valList = stdVal.split(",")

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectRoadEtc")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                roadSe=Identifier(attrList[0].lower()),
                                                                roadBt=Identifier(attrList[3].lower())),
                                          {"attrList": tuple(attrList[1:3]), "stdVal": float(valList[1])}))

            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        roadSe=Identifier(attrList[0].lower()),
                                                        roadBt=Identifier(attrList[3].lower())),
                             {"attrList": tuple(attrList[1:3]), "stdVal": float(valList[1])})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "ROAD_BT",
                                "colVal": sqlResult[2],
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return selectResult

    def selectRoadLine(self, schema, table, attrList, stdVal):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()
        valList = stdVal.split(",")

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectRoadLine")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                cartrkCo=Identifier(attrList[0].lower())),
                                          {"stdVal": float(valList[1])}))

            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        cartrkCo=Identifier(attrList[0].lower())),
                             {"stdVal": float(valList[1])})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "CARTRK_CO",
                                "colVal": sqlResult[2],
                                "resCode": "IVS005",
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)
        if cur:
            cur.close()
        return selectResult

    def selectBuldFloor(self, schema, table, attrList, stdVal):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()
        valList = stdVal.split(",")

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectBuldFloor")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                blfrCo=Identifier(attrList[0].lower())),
                                          {"stdVal": float(valList[1])}))

            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        blfrCo=Identifier(attrList[0].lower())),
                             {"stdVal": float(valList[1])})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "BFLR_CO",
                                "colVal": sqlResult[2],
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return selectResult

    def selectBuldGeneralHouse(self, schema, table, attrList):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectBuldGeneralHouse")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                buldSe=Identifier(attrList[0].lower()),
                                                                buldNm=Identifier(attrList[2].lower())),
                                          {"attr": attrList[1]}))

            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        buldSe=Identifier(attrList[0].lower()),
                                                        buldNm=Identifier(attrList[2].lower())),
                             {"attr": attrList[1]})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "BULD_NM",
                                "colVal": sqlResult[2],
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return selectResult

    def selectHeightChk(self, schema, table, column, stdVal):
        selectResult = list()
        schema = schema.lower()
        table = table.lower()
        valList = stdVal.split(",")

        cur = self.getCursor()
        if not cur:
            return selectResult
        try:
            selectSql = self.sqlStatement.get("SQL", "selectHeightChk")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                column=Identifier(column[0].lower())),
                                          {"stdVal": float(valList[1])}))

            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        column=Identifier(column[0].lower())),
                             {"stdVal": float(valList[1])})
            sqlResults = cur.fetchall()
            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": column[0],
                                "colVal": sqlResult[2],
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e)

        if cur:
            cur.close()

        return selectResult

    def selectExceptionInfo(self, schema):
        exceptionInfo = list()
        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectExceptionInfo")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                exceptionInfo.append({
                    "cid": sqlResult[2],
                    "insTCode": sqlResult[4],
                    "imgNm": sqlResult[5],
                    "bCode": "DLC",
                    "resCode": "IVS010",
                    "errorDc": sqlResult[6]
                })

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return exceptionInfo

    def selectNfIdValid(self, schema, table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectNfIdValid")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table)),
                                          {"table":table}))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)),
                             {"table": table})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "NF_ID",
                                "colVal": sqlResult[1],
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectRefNfIdValid(self, schema, table, sub_table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectRefNfIdValid")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                sub_table=Identifier(sub_table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        sub_table=Identifier(sub_table)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "REFNF_ID",
                                "colVal": sqlResult[1],
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectDuplicateNfId(self, schema, table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectDuplicateNfId")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refCid": "",
                                "refNfId": "",
                                "refLayerId": "",
                                "colId": "NF_ID",
                                "colVal": sqlResult[1],
                                "resCode": "IVS005"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult
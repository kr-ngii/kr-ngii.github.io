# -*- coding: utf-8 -*-
import os
from qgis.core import *

from ..util.ImgUtil import ImgUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class LogicalImgUtil(ImgUtil):

    def __init__(self, dock, dbUtil):
        ImgUtil.__init__(self, dock.iface, dock)
        self.logger = logger
        self.dbUtil = dbUtil

    def saveImg(self, schemaNm, layerNm, inspectCode, result, errInfo):
        layer = QgsMapLayerRegistry.instance().mapLayersByName(layerNm)[0]
        legend = self.iface.legendInterface()

        legend.setLayerVisible(layer, True)
        self.iface.mapCanvas().setExtent(layer.extent())
        self.iface.mapCanvas().zoomScale(1000.0)
        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        if inspectCode == 'LCTCSG02':
            reaultAddImg = self.saveNearVertexImg(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode in ['LCTCDO01', 'LCTCDO02']:
            reaultAddImg = self.saveDuplicatedFeaturesImg(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode.startswith('LCTCMC'):
            reaultAddImg = self.saveCheckCenterLineImg(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode.startswith("LCTCBM"):
            reaultAddImg = self.saveContinuousEdgeImg(schemaNm, layer, inspectCode, result, errInfo)
        # elif inspectCode.startswith("LCTCMM"):
        #     reaultAddImg = self.saveContinuousAttrImg(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode in ['LCTCBV03', 'LCTCBV09', 'LCTCBV11', 'LCTCBV12', 'LCTCBV13', 'LCTCBV15', 'LCTCBV18']:
            reaultAddImg = self.saveIntersectsPolygonToLinestring(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode in ['LCTCBV01', 'LCTCBV04', 'LCTCBV05', 'LCTCBV07', 'LCTCBV08', 'LCTCBV14', 'LCTCBV17',
                             'LCTCBV19']:
            reaultAddImg = self.saveIntersectsPolygonToPolygon(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode.startswith("LCTCBV"):
            reaultAddImg = self.saveIntersectsImg(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode == 'LCTCEC03':
            reaultAddImg = self.saveCtrlnContinuousImg(schemaNm, layer, inspectCode, result, errInfo)
        elif inspectCode == 'LCTCHL01':
            reaultAddImg = self.saveHoleFeatureImg(schemaNm, layer, inspectCode, result, errInfo)
        else:
            # self_intersects, single_point, micro_feature, sliver
            reaultAddImg = self.saveCommonImg(schemaNm, layer, inspectCode, result, errInfo)

        self.setDefaultSymbol(layer)
        legend.setLayerVisible(layer, False)

        self.forceRefresh()

        return reaultAddImg

    def saveCommonImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{cid}\''

        for res in detailRes:
            cid = res["cid"]

            expr = exprStr.format(cid=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            if inspectCode in ['LCTCSG04', 'LCTCSG05'] or layer.name() == 'tn_alpt':
                centerPoint = bbox.center()
                self.iface.mapCanvas().setCenter(centerPoint)
                self.iface.mapCanvas().zoomScale(500.0)
            else:
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)

            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                   'err_{cid}.png'.format(cid=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                     'err_{cid}_tn.png'.format(cid=cid))
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            detailRes[resIdx]["details"][0]["imgNm"] = os.path.basename(imgPath)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, res["details"][0], errInfo)
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)
            # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        return detailRes

    def saveHoleFeatureImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Polygon?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_polygon", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            cid = res["cid"]

            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            feat = QgsFeature(tmpLayer.pendingFields())
            feat.setGeometry(featureGeometry[0])
            feat.setAttribute('cid', cid)

            newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            cid = res["cid"]

            expr = exprStr.format(id=cid)
            selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                  cid=cid))
                continue

            self.setErrorSymbol(tmpLayer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)
            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                   'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                     'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            detailRes[resIdx]["details"][0]["imgNm"] = os.path.basename(imgPath)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, res["details"][0], errInfo)
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)
            # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        return detailRes

    def saveNearVertexImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Point?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_point", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]

            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                cid = res["cid"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                      cid=cid))
                    continue

                self.setErrorSymbol(tmpLayer, expr)

                bbox = featureGeometry[0].boundingBox()
                centerPoint = bbox.center()
                self.iface.mapCanvas().setCenter(centerPoint)
                self.iface.mapCanvas().zoomScale(100.0)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                         'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

                if not thumbnailResult:
                    return False, None

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)

                detailRes[resIdx]["details"][detailIdx]["imgNm"] = os.path.basename(imgPath)

                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                with open(tnImgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["imgTn"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()

                detailRes[resIdx]["details"][detailIdx]["minX"] = round(imgExtent.xMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["minY"] = round(imgExtent.yMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxX"] = round(imgExtent.xMaximum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxY"] = round(imgExtent.yMaximum(), 2)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, detail, errInfo)
                self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                           imgExtent)
                # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        return detailRes

    def saveDuplicatedFeaturesImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{cid}\''

        for res in detailRes:
            cid = res["cid"]

            resDetail = res['details'][0]
            refCid = resDetail['refCid']

            if inspectCode == 'river_duplicated_features':
                expr = exprStr.format(cid=cid)
            else:
                expr = '"cid" IN (\'{cid}\', \'{refCid}\')'.format(cid=cid, refCid=refCid)

            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(exprStr.format(cid=cid))))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                  cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)

            geomType = layer.wkbType()

            if geomType == QGis.WKBMultiPoint or geomType == QGis.WKBPoint:
                self.iface.mapCanvas().zoomScale(750.0)

            else:
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)

            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgFileNm = 'err_{cid}.png'.format(cid=cid)
            imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode, imgFileNm)
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgFileNm = 'err_{cid}_tn.png'.format(cid=cid)
            tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode, tnImgFileNm)
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            detailRes[resIdx]["details"][0]["imgNm"] = os.path.basename(imgPath)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, resDetail, errInfo)
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)
            # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        return detailRes

    def saveCheckCenterLineImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        for res in detailRes:

            cid = res["cid"]
            resDetail = res['details'][0]
            # refCid = resDetail['refCid']

            subLayerNm = resDetail['refLayerId']
            if subLayerNm != layerNm:
                if not subLayer or subLayer.name() != subLayerNm:
                    legend.setLayerVisible(subLayer, False)

                    subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                    legend.setLayerVisible(subLayer, True)
                    self.forceRefresh()
            else:
                subLayer = None

            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)
            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, layerNm, inspectCode,
                                   'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgPath = os.path.join(self.IMG_SAVE_PATH, layerNm, inspectCode,
                                     'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            detailRes[resIdx]["details"][0]["imgNm"] = os.path.basename(imgPath)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, resDetail, errInfo)
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)
            # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveContinuousEdgeImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''

        legend = self.iface.legendInterface()

        subLayersList = list()

        for res in detailRes:
            cid = res["cid"]
            subLayers = res['details'][0]['refLayerId'].split(',')

            if len(subLayersList) <= 0:
                for subLayerNm in subLayers:
                    subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                    legend.setLayerVisible(subLayer, True)

                    subLayersList.append(subLayer)

                self.forceRefresh()

            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)
            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                   'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                     'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, res["details"][0], errInfo)
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)
            # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        for subLayer in subLayersList:
            legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveContinuousAttrImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        for res in detailRes:
            cid = res["cid"]
            details = res['details']

            for detail in details:
                refCid = detail['refCid']
                refCid = refCid.replace(',', "','")

                expr = '"cid" IN (\'{cid}\', \'{refCid}\')'.format(cid=cid, refCid=refCid)

                selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                    continue

                # self.setErrorSymbol(layer, expr, scale=self.iface.mapCanvas().scale())
                self.setErrorSymbol(layer, expr)

                centerGeom = QgsGeometry().fromWkt(detail['tmp_geom'])
                self.iface.mapCanvas().setExtent(centerGeom.boundingBox())
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgFileNm = 'err_{cid}_{refCid}.png'.format(cid=cid, refCid=refCid.replace("','", "_"))
                imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode, imgFileNm)

                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgFileNm = 'err_{cid}_{refCid}_tn.png'.format(cid=cid, refCid=refCid.replace("','", "_"))
                tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode, tnImgFileNm)
                thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

                if not thumbnailResult:
                    return False, None

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)

                detailRes[resIdx]["details"][detailIdx]["imgNm"] = os.path.basename(imgPath)

                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                with open(tnImgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["imgTn"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()

                detailRes[resIdx]["details"][detailIdx]["minX"] = round(imgExtent.xMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["minY"] = round(imgExtent.yMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxX"] = round(imgExtent.xMaximum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxY"] = round(imgExtent.yMaximum(), 2)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, detail, errInfo)
                self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                           imgExtent)
                # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        return detailRes

    def saveIntersectsImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        for res in detailRes:

            cid = res["cid"]
            resDetail = res['details'][0]
            # refCid = resDetail['refCid']

            subLayerNm = resDetail['refLayerId']
            if subLayerNm != layerNm:
                if not subLayer or subLayer.name() != subLayerNm:
                    legend.setLayerVisible(subLayer, False)

                    subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                    legend.setLayerVisible(subLayer, True)
                    self.forceRefresh()
            else:
                subLayer = None

            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)

            geomType = layer.wkbType()

            if geomType == QGis.WKBMultiPoint or geomType == QGis.WKBPoint:
                self.iface.mapCanvas().zoomScale(750.0)
            else:
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)

            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, layerNm, inspectCode,
                                   'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgPath = os.path.join(self.IMG_SAVE_PATH, layerNm, inspectCode,
                                     'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            detailRes[resIdx]["details"][0]["imgNm"] = os.path.basename(imgPath)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, resDetail, errInfo)
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)
            # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveIntersectsPolygonToLinestring(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("LineString?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_linestring", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]

            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                subLayerNm = detail['refLayerId']
                if subLayerNm != layerNm:
                    if not subLayer or subLayer.name() != subLayerNm:
                        legend.setLayerVisible(subLayer, False)

                        subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                        legend.setLayerVisible(subLayer, True)
                        self.forceRefresh()
                else:
                    subLayer = None

                cid = res["cid"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                      cid=cid))
                    continue

                self.setErrorSymbol(tmpLayer, expr)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                         'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

                if not thumbnailResult:
                    return False, None

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)

                detailRes[resIdx]["details"][detailIdx]["imgNm"] = os.path.basename(imgPath)

                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                with open(tnImgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["imgTn"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()

                detailRes[resIdx]["details"][detailIdx]["minX"] = round(imgExtent.xMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["minY"] = round(imgExtent.yMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxX"] = round(imgExtent.xMaximum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxY"] = round(imgExtent.yMaximum(), 2)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, detail, errInfo)
                self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                           imgExtent)
                # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveIntersectsPolygonToPolygon(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Polygon?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_polygon", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]

            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                subLayerNm = detail['refLayerId']
                if subLayerNm != layerNm:
                    if not subLayer or subLayer.name() != subLayerNm:
                        legend.setLayerVisible(subLayer, False)

                        subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                        legend.setLayerVisible(subLayer, True)
                        self.forceRefresh()
                else:
                    subLayer = None

                cid = res["cid"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                      cid=cid))
                    continue

                self.setErrorSymbol(tmpLayer, expr)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                         'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

                if not thumbnailResult:
                    return False, None

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)

                detailRes[resIdx]["details"][detailIdx]["imgNm"] = os.path.basename(imgPath)

                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                with open(tnImgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["imgTn"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()

                detailRes[resIdx]["details"][detailIdx]["minX"] = round(imgExtent.xMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["minY"] = round(imgExtent.yMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxX"] = round(imgExtent.xMaximum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxY"] = round(imgExtent.yMaximum(), 2)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, detail, errInfo)
                self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                           imgExtent)
                # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtent)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    # TODO: 변경 적용
    def saveCtrlnContinuousImg(self, schemaNm, layer, inspectCode, detailRes, errInfo):
        exprStr = '"cid" = \'{id}\''

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Point?crs=epsg:5179&field=g_id:int&field=cid:string&index=yes",
                                  "temporary_point", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]
            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                cid = res["cid"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                    continue

                expr = exprStr.format(id=cid)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(750.0)

                self.setErrorSymbol(tmpLayer, expr)

                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgPath = os.path.join(self.IMG_SAVE_PATH, layer.name(), inspectCode,
                                         'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

                if not thumbnailResult:
                    return False, None

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)

                detailRes[resIdx]["details"][detailIdx]["imgNm"] = os.path.basename(imgPath)

                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                with open(tnImgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["imgTn"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()

                detailRes[resIdx]["details"][detailIdx]["minX"] = round(imgExtent.xMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["minY"] = round(imgExtent.yMinimum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxX"] = round(imgExtent.xMaximum(), 2)
                detailRes[resIdx]["details"][detailIdx]["maxY"] = round(imgExtent.yMaximum(), 2)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, tnImgPath, detail, errInfo)
                self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                           imgExtent)
                # self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        return detailRes

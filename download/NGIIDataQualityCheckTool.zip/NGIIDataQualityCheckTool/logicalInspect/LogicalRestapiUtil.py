# -*- coding: utf-8 -*-

from ..util.RestapiUtil import RestAPIUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class LogicalRestapiUtil(RestAPIUtil):

    def __init__(self):
        RestAPIUtil.__init__(self)
        self.logger = logger



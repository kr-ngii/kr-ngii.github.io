# -*- coding: utf-8 -*-
import os
import glob
import platform
import datetime
import json

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from qgis.gui import *
from qgis import utils

from ui.ThematicInspect import Ui_ThematicInspect
from thematicInspect.ThematicInspector import ThematicInspector
from InspectProgress import InspectProgress

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class IdentifyGeometry(QgsMapToolIdentify):
    geomIdentified = pyqtSignal(QgsVectorLayer, QgsFeature)

    def __init__(self, canvas):
        self.canvas = canvas
        QgsMapToolIdentify.__init__(self, canvas)
        self.setCursor(QCursor())

    def canvasReleaseEvent(self, mouseEvent):
        try:
            results = self.identify(mouseEvent.x(), mouseEvent.y(), self.LayerSelection, self.AllLayers)
        except:
            results = self.identify(mouseEvent.x(), mouseEvent.y(), self.TopDownStopAtFirst, self.AllLayers)
        if len(results) > 0:
            self.geomIdentified.emit(results[0].mLayer, QgsFeature(results[0].mFeature))
        else:
            self.geomIdentified.emit(QgsVectorLayer(), QgsFeature())


class ThematicInspect(QDockWidget, Ui_ThematicInspect):

    EDIT_IMG = os.path.join(os.path.dirname(__file__), "icons", "edit.png")
    DELETE_IMG = os.path.join(os.path.dirname(__file__), "icons", "delete.png")

    standardLayerStructure = None

    inspectSchema = None
    selecfFlag = False
    editFlag = False

    currentLayer = None
    customMouseEvent = None

    errImgLayer = None

    # test #
    CODEZIP = {
        "tn_arrfc_railroad": "arrfckd_se",
        "tn_mtc_bndry": "vtn_se",
        "tn_lnpgr": "lnpgr_se",
        "tn_buld": "buld_se",
        "tn_river_ctln": "river_se",
        "tn_signgu_bndry": "adzone_se",
        "tn_arpgr": "arpgr_se",
        "tn_fclty_zone_bndry": "fzonbn_se",
        "tn_ctprvn_bndry": "adzone_se",
        "tn_lnrfc": "lnrfckd_se",
        "tn_ptrfc_road": "ptrfckd_se",
        "tn_shorline": "shorlne_se",
        "tn_ptafc": "ptafckd_se",
        "tn_arrfc_road": "arrfcty_se",
        "tn_emd_bndry": "adzone_se",
        "tn_ptpgr": "ptpgr_se",
        "tn_wtcors_fclty": "wtcorfc_se",
        "tn_fmlnd_bndry": "vtn_se",
        "tn_pthfc": "pthkckd_se",
        "tn_rlroad_ctln": "rlroad_se",
        "tn_ctrln": "ctrln_se",
        "tn_buld_adcls": "adcls_se",
        "tn_rodway_ctln": "road_se"
    }

    ########

    def __init__(self, dock):
        super(ThematicInspect, self).__init__(dock.parent)
        self.setupUi(self)

        self.__initTree()
        self.__setBimgTn()

        self.logger = logger

        self.iface = dock.iface
        self.parent = dock.parent
        self.crrWidget = dock

        self.thematicInspect = ThematicInspector(self)
        self.inspectSchema = self.thematicInspect.getSchema()
        self.imgSavePath = self.thematicInspect.getImgSavePath()

        self.__connectFn()
        self.txtErrMsg.setEnabled(False)

    def __connectFn(self):
        self.btnSelectFeature.clicked.connect(self.__changeSelectFlag)
        self.btnSaveErr.clicked.connect(self.__saveErr)
        self.btnDelete.clicked.connect(self.deleteErr)
        self.btnEdit.clicked.connect(self.editErr)
        self.btnCompleteInspect.clicked.connect(self.completeInspect)
        self.treeResult.doubleClicked.connect(self.loadImg)
        self.treeResult.clicked.connect(self.setFeatureInfo)

    def keyReleaseEvent(self, QKeyEvent):
        curIdx = self.treeResult.currentIndex()
        if curIdx:
            self.setFeatureInfo(curIdx)

    def __initTree(self):
        self.treeResult.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeResult.setHeaderHidden(True)
        self.treeModel = QStandardItemModel()
        self.treeModel.setColumnCount(1)

        self.treeResult.setModel(self.treeModel)

    def __setBimgTn(self):
        editIcon = QIcon()
        editIcon.addPixmap(QPixmap(self.EDIT_IMG))
        self.btnEdit.setIcon(editIcon)

        deleteIcon = QIcon()
        deleteIcon.addPixmap(QPixmap(self.DELETE_IMG))
        self.btnDelete.setIcon(deleteIcon)

    def loadData(self):
        self.iface.newProject()
        self.iface.mapCanvas().setCanvasColor(Qt.black)

        layerList = self.thematicInspect.dbUtil.selectTableList(self.inspectSchema)
        layerListLen = len(layerList)

        if layerListLen <= 0:
            QMessageBox.information(self.parent, u'검사 대상 정보', u'검사할 대상이 없습니다.')

        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        self.standardLayerStructure = self.thematicInspect.dbUtil.selectStandardLayerStructure()

        loadResult = self.__loadData(layerList)
        if not loadResult:
            QMessageBox.warning(self.parent, u'검사 대상 오류', u'검사 대상을 불러오는데 실패하였습니다.')
            return

    def __loadData(self, layerList):
        result = False

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        try:
            layerGroupList = self.standardLayerStructure['layerGroup']
            dbInfo = self.thematicInspect.dbUtil.getDbInfo()
            groupRoot = QgsProject.instance().layerTreeRoot()

            for layerGroup in layerGroupList:
                self.iface.legendInterface().addGroup(layerGroup.decode("UTF-8"))

            stdLayerNmList = self.standardLayerStructure.keys()
            for layerNm in layerList:
                if layerNm not in stdLayerNmList:
                    continue

                uri = QgsDataSourceURI()
                uri.setConnection(dbInfo["host"], dbInfo["port"], dbInfo["dbname"],
                                  dbInfo["user"], dbInfo["password"])
                uri.setDataSource(self.inspectSchema, layerNm, "wkb_geometry", "", "id")
                ngdLayer = QgsVectorLayer(uri.uri(), layerNm, "postgres")

                self.thematicInspect.imgUtil.setDefaultSymbol(ngdLayer)

                group = groupRoot.findGroup(self.standardLayerStructure[layerNm]['layer_package'].decode("UTF-8"))

                if group:
                    QgsMapLayerRegistry.instance().addMapLayer(ngdLayer, False)

                    group.addLayer(ngdLayer)

                    # legend = self.iface.legendInterface()
                    # legend.setLayerVisible(ngdLayer, False)

                if ngdLayer.geometryType() == 0:
                    layerOrder.insert(0, ngdLayer.id())
                else:
                    layerOrder.append(ngdLayer.id())

                self.iface.mapCanvas().setExtent(ngdLayer.extent())

            groupList = groupRoot.children()
            for group in groupList:
                loadedLayerList = group.children()

                for layer in loadedLayerList:
                    layer.setExpanded(False)

            result = True

        except Exception as e:
            self.logger.debug(e)

        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)
        self.iface.layerTreeCanvasBridge().setHasCustomLayerOrder(True)

        return result

    def closeDB(self):
        self.thematicInspect.dbUtil.closeDB()

    def __changeSelectFlag(self):
        self.selecfFlag = True
        self.editFlag = False
        self.btnSelectFeature.setEnabled(False)

        if not self.customMouseEvent:
            self.customMouseEvent = IdentifyGeometry(self.iface.mapCanvas())
            self.customMouseEvent.geomIdentified.connect(self.selectFeature)

        self.iface.mapCanvas().setMapTool(self.customMouseEvent)
        self.iface.mapCanvas().mapToolSet.connect(self.clearStyle)

    def selectFeature(self, selLayer, selFeature):
        try:
            cid = selFeature.attribute('cid')
        except:
            self.__setFeatureInfo()

            if self.currentLayer:
                self.thematicInspect.imgUtil.setDefaultSymbol(self.currentLayer)
            return

        if selLayer != self.currentLayer:
            self.thematicInspect.imgUtil.setDefaultSymbol(self.currentLayer)

        expr = '"cid"=\'{id}\''.format(id=cid)
        self.thematicInspect.imgUtil.setErrorSymbol(selLayer, expr)

        codeKeys = self.CODEZIP.keys()
        layerNm = selLayer.name()
        attr = ""

        if layerNm in codeKeys:
            attr = selFeature.attribute(self.CODEZIP[layerNm])

        self.__setFeatureInfo(cid=cid, attr=attr, errMsgFlag=True)

        self.currentLayer = selLayer

    def __saveErr(self):
        if self.editFlag:
            idxList = self.treeResult.selectedIndexes()

            if len(idxList) != 1:
                # TODO: 한 개만 선택
                return

            idx = idxList[0]

            selData = self.treeModel.itemFromIndex(idx)  # type: QStandardItem
            featureInfo = selData.data()

            featureInfo["errMsg"] = self.txtErrMsg.toPlainText()

            selData.setData(featureInfo)

            self.editErr()

            QMessageBox.information(self.parent, u"객체 오류 수정", u"객체 오류 내용이 수정되었습니다.")

        else:
            cid = self.txtFeatureId.text()

            if not cid or cid == "":
                return

            attrVal = self.txtFeatureAttr.text()
            layerNm = self.currentLayer.name()
            attrCol = ""
            if layerNm in self.CODEZIP.keys():
                attrCol = self.CODEZIP[layerNm]
            errMsg = self.txtErrMsg.toPlainText()

            imgSaveResult, imgData = self.thematicInspect.saveImg(self.inspectSchema, self.currentLayer, cid)

            if not imgSaveResult:
                return

            errData = {
                "id": cid,
                "layerNm": layerNm,
                "attrCol": attrCol,
                "attrVal": attrVal,
                "errMsg": errMsg,
                "imgPath": imgData["imgPath"],
                "imgTnPath": imgData["imgTnPath"],
                "imgExtent": imgData["imgExtent"]
            }

            self.__addTree(errData)

            self.selecfFlag = False
            self.btnSelectFeature.setEnabled(True)
            self.__setFeatureInfo()

            self.iface.actionPan().trigger()

            QMessageBox.information(self.parent, u"객체 오류 저장", u"객체 오류 내용이 저장되었습니다.")

    def clearStyle(self, mapTool):
        print mapTool
        if self.customMouseEvent and self.customMouseEvent != mapTool:
            if self.currentLayer:
                self.thematicInspect.imgUtil.setDefaultSymbol(self.currentLayer)
            self.btnSelectFeature.setEnabled(True)
            self.iface.mapCanvas().mapToolSet.disconnect(self.clearStyle)

    def __setFeatureInfo(self, cid="", attr="", errMsg="", errImgPath="", errMsgFlag=False):
        self.txtFeatureId.setText(cid)
        self.txtFeatureAttr.setText(attr)
        self.txtErrMsg.setPlainText(errMsg)

        if errImgPath != "":
            errImg = QPixmap(errImgPath)
            errImgWidth = errImg.width()
            errImgHeight = errImg.height()

            labelWidth = self.labelErrImg.width()
            labelHeight = self.labelErrImg.height()

            if errImgWidth >= errImgHeight:
                resizeImg = errImg.scaledToWidth(labelWidth)
                if resizeImg.height() > labelHeight:
                    resizeImg = resizeImg.scaledToHeight(labelHeight)
            else:
                resizeImg = errImg.scaledToHeight(labelHeight)
                if resizeImg.width() > labelWidth:
                    resizeImg = resizeImg.scaledToWidth(labelWidth)

            self.labelErrImg.setPixmap(resizeImg)
        else:
            self.labelErrImg.setText(errImgPath)

        self.txtErrMsg.setEnabled(errMsgFlag)

    def __addTree(self, result):
        layerNm = result["layerNm"]
        cid = result["id"]
        layerNmKo = self.standardLayerStructure[layerNm]["layer_nm"].decode("UTF-8")

        rootNodeRes = self.treeModel.findItems(layerNmKo)

        if len(rootNodeRes) > 0:
            rootNode = rootNodeRes[0]
        else:
            rootNode = QStandardItem(layerNmKo)
            rootNode.setEditable(False)
            rootNode.setSelectable(False)

            self.treeModel.appendRow([rootNode])

        rootNodeRows = rootNode.rowCount()

        for idx in range(0, rootNodeRows):
            tmpNode = rootNode.child(idx)
            if tmpNode.text() == cid:
                return

        cidNode = QStandardItem(cid)
        cidNode.setEditable(False)
        cidNode.setData(result)

        rootNode.appendRow([cidNode])

        imgPath = result["imgPath"]
        self.__writeXml(imgPath)

    def loadImg(self, index):
        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        if self.errImgLayer:
            QgsMapLayerRegistry.instance().removeMapLayer(self.errImgLayer)

        featureInfo = selData.data()

        imgPath = featureInfo["imgPath"]

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()
        self.errImgLayer = QgsRasterLayer(imgPath, os.path.splitext(os.path.basename(imgPath))[0])
        # 이미지를 반투명하에 캔버스에 추가
        self.errImgLayer.renderer().setOpacity(0.5)

        QgsMapLayerRegistry.instance().addMapLayer(self.errImgLayer, False)

        groupRoot = QgsProject.instance().layerTreeRoot()
        groupRoot.insertLayer(0, self.errImgLayer)

        layerOrder.insert(0, self.errImgLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        legend = self.iface.legendInterface()  # type: QgsLegendInterface
        layer = QgsMapLayerRegistry.instance().mapLayersByName(featureInfo["layerNm"])[0]  # type: QgsVectorLayer

        if not legend.isLayerVisible(layer):
            legend.setLayerVisible(layer, True)

        self.iface.mapCanvas().setExtent(self.errImgLayer.extent())
        self.iface.mapCanvas().refresh()

    def __writeXml(self, imgPath):
        baseNm = os.path.splitext(imgPath)[0]
        worldFile = "{}.pgw".format(baseNm)
        xmlFile = "{}.png.aux.xml".format(baseNm)

        if os.path.exists(xmlFile):
            return

        xmlTemplate = """
            <PAMDataset>
              <SRS>PROJCS["Korea 2000 / Unified CS",GEOGCS["Korea 2000",DATUM["Geocentric_datum_of_Korea",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],TOWGS84[0,0,0,0,0,0,0],AUTHORITY["EPSG","6737"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4737"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",38],PARAMETER["central_meridian",127.5],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",1000000],PARAMETER["false_northing",2000000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AUTHORITY["EPSG","5179"]]</SRS>
              <GeoTransform> {}, {}, {}, {}, {}, {} </GeoTransform>
              <Metadata domain="IMAGE_STRUCTURE">
                <MDI key="INTERLEAVE">PIXEL</MDI>
              </Metadata>
              <Metadata>
                <MDI key="AREA_OR_POINT">Area</MDI>
              </Metadata>
            </PAMDataset>
        """
        with open(worldFile, 'rb') as f:
            data = f.readlines()

        with open(xmlFile, 'wb') as f:
            f.write(xmlTemplate.format(data[4], data[0], data[1], data[5], data[2], data[3]))

    def setFeatureInfo(self, index):
        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        featureInfo = selData.data()

        cid = featureInfo["id"]
        attrVal = featureInfo["attrVal"]
        errMsg = featureInfo["errMsg"]
        errImgPath = featureInfo["imgTnPath"]

        self.__setFeatureInfo(cid=cid, attr=attrVal, errMsg=errMsg, errImgPath=errImgPath)

        self.selecfFlag = False
        self.btnSelectFeature.setEnabled(True)

        self.iface.actionPan().trigger()

    def deleteErr(self):
        idxList = self.treeResult.selectedIndexes()

        for idx in idxList:
            selData = self.treeModel.itemFromIndex(idx)  # type: QStandardItem
            featureInfo = selData.data()

            imgPath = featureInfo["imgPath"]

            imgNm = os.path.splitext(os.path.basename(imgPath))[0]
            if self.errImgLayer and self.errImgLayer.name() == imgNm:
                QgsMapLayerRegistry.instance().removeMapLayer(self.errImgLayer)
                self.errImgLayer = None
            else:
                imgLayerList = QgsMapLayerRegistry.instance().mapLayersByName(imgNm)

                for imgLayer in imgLayerList:
                    QgsMapLayerRegistry.instance().removeMapLayer(imgLayer)

            for delFile in glob.glob(os.path.splitext(imgPath)[0] + "*"):
                if platform.system() == 'Windows':
                    os.remove(delFile.replace('/', '\\'))
                else:
                    os.remove(delFile)
            idxRow = idx.row()
            idxParent = idx.parent()

            self.treeModel.removeRow(idxRow, idxParent)

            parent = self.treeModel.itemFromIndex(idxParent)  # type: QStandardItem
            if not parent.hasChildren():
                self.treeModel.removeRow(idxParent.row(), idxParent.parent())

        self.__setFeatureInfo()

    def editErr(self):
        if self.editFlag:
            self.txtErrMsg.setEnabled(False)
            self.btnSaveErr.setText(u"오류 저장")
            self.editFlag = False

        else:
            self.txtErrMsg.setEnabled(True)
            self.btnSaveErr.setText(u"오류 수정")
            self.editFlag = True

        self.selecfFlag = False
        self.btnSelectFeature.setEnabled(True)

    def completeInspect(self):
        stdLayerNmList = self.standardLayerStructure.keys()
        insLayerNmList = list()

        for layer in QgsMapLayerRegistry.instance().mapLayers().values():
            layerNm = layer.name()
            if layerNm in stdLayerNmList:
                insLayerNmList.append(layerNm)

        res = QMessageBox.question(self.parent, u"검사 완료", u"주제정확도 검사를 완료하시겠습니까?",
                                   QMessageBox.Yes | QMessageBox.No)
        if res == QMessageBox.No:
            return

        progress = InspectProgress(self.iface, u"결과 저장 중 ...", 2, self.parent)
        progress.show()

        inspectResult = {"result": list()}

        rootRowCount = self.treeModel.rowCount()

        for rootRow in range(0, rootRowCount):
            subRes = None

            layerNode = self.treeModel.item(rootRow)

            layerRowCount = layerNode.rowCount()
            for layerRow in range(0, layerRowCount):
                featureNode = layerNode.child(layerRow)

                featureInfo = featureNode.data()

                imgPath = featureInfo["imgPath"]
                with open(imgPath, "rb") as imgFile:
                    img = imgFile.read().encode('base64')

                imgTnPath = featureInfo["imgTnPath"]
                with open(imgTnPath, "rb") as imgFile:
                    imgTn = imgFile.read().encode('base64')

                if not subRes:
                    layerNm = featureInfo["layerNm"]

                    insLayerNmList.remove(layerNm)

                    subRes = {
                        "bCode": "DTA",
                        "insGroupId": None,
                        "layerId": layerNm.upper(),
                        "insTCode": "TATACC01",
                        "errFeatureList": list()
                    }

                imgExtent = featureInfo["imgExtent"]

                datailRes = {
                    "cid": featureInfo["id"],
                    "details": [
                        {
                            "colId": featureInfo["attrCol"],
                            "colVal": featureInfo["attrVal"],
                            "img": img,
                            "imgTn": imgTn,
                            "minX": imgExtent.xMinimum(),
                            "minY": imgExtent.yMinimum(),
                            "maxX": imgExtent.xMaximum(),
                            "maxY": imgExtent.yMaximum(),
                            "imgNm": os.path.basename(imgPath),
                            "resCode": "IVS005",
                            "erReason": featureInfo["errMsg"].encode("utf-8")
                        }
                    ]
                }

                subRes["errFeatureList"].append(datailRes)

            inspectResult["result"].append(subRes)

        for layerNm in insLayerNmList:
            subRes = {
                "bCode": "DTA",
                "insGroupId": None,
                "layerId": layerNm.upper(),
                "insTCode": "TATACC01",
                "errFeatureList": list()
            }

            inspectResult["result"].append(subRes)

        # 결과 전송
        self.thematicInspect.saveResult(inspectResult)

        # 검사 완료
        self.thematicInspect.completeInspect(None)

        progress.setFinish()
        progress.close()

        QMessageBox.information(self.parent, u"검사 완료", u"검사 결과가 서버로 전송되었습니다.")

        self.btnCompleteInspect.setDisabled(True)
        self.btnSelectFeature.setDisabled(True)
        self.btnSaveErr.setDisabled(True)
        self.btnEdit.setDisabled(True)
        self.btnDelete.setDisabled(True)

# -*- coding: utf-8 -*-
import os

from TemporalDBUtil import TemporalDBUtil
from TemporalRestapiUtil import TemporalRestapiUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class TemporalInspector:
    B_CODE = "DTQ"  # 시간정확성

    M_CODE = {
        "validity": "STV",  # 시간유효성
        "accuracy": "STM",  # 시간측정정확도
        "consistency": "STC",  # 시간일관성
    }

    progress = None

    def __init__(self, dock, properties_file, schema):
        self.logger = logger

        self.dbUtil = TemporalDBUtil(properties_file)
        self.restapiUtil = TemporalRestapiUtil()

        self.schema_nm = schema

    def inspectData(self, progress, layer_list):
        pass

    def __inspect_validity(self, layer):
        pass

    def __inspect_accuracy(self, layer):
        pass

    def __inspect_consistency(self, layer):
        pass

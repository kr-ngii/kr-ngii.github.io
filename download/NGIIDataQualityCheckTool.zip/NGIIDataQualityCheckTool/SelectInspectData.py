# -*- coding: utf-8 -*-
import os

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic
from qgis import utils
from osgeo import gdal
import ogr
from ui.SelectInspectData import Ui_SelectInspectData

from LogicalTemporalInspect import LogicalTemporalInspect
from ThematicInspect import ThematicInspect
from InspectProgress import InspectProgress

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


# class SelectInspectData(QDialog, Ui_SelectInspectData):
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/SelectInspectData.ui'))


class SelectInspectData(QDialog, FORM_CLASS):

    inspectWidget = None
    __oldDataDir = None

    def __init__(self, iface, parent=None):
        super(SelectInspectData, self).__init__(parent)
        self.setupUi(self)

        self.logger = logger

        self.iface = iface
        self.parent = parent
        self.fileFlag = None
        self.__connectFn()

        self.plugin = utils.plugins['NGIIDataQualityCheckTool']

        if self.plugin.MODE == 'external':
            while self.horizontalLayout.count():
                item = self.horizontalLayout.itemAt(0)
                self.horizontalLayout.removeItem(item)

            self.txtInspectorNm.hide()
            self.label.hide()

        else:
            self.txtInspectorNm.setText(u"홍길동")

    def __connectFn(self):
        self.btnInspectData.clicked.connect(self.findInspectData)
        self.btnLogicalInspect.clicked.connect(self.showLogicalTemporalInspect)
        self.btnThematicInspect.clicked.connect(self.showThematicInspect)

    def findInspectData(self):
        if self.radioShp.isChecked():
            dataPath = QFileDialog.getExistingDirectory(self.iface.mainWindow(), u'검사 대상 폴더 선택',
                                                        self.__oldDataDir, options=QFileDialog.DontUseNativeDialog)
            self.__oldDataDir = os.path.dirname(dataPath)

            self.logger.info("Set inspect data : " + dataPath)
            self.txtInspectData.setText(dataPath)
            self.fileFlag = True
        else:
            fileFilter = "GeoPackage (*.gpkg)"

            dataPath = QFileDialog.getOpenFileName(self.iface.mainWindow(), u'검사 대상 GeoPackage 선택',
                                                   self.__oldDataDir, filter=fileFilter,
                                                   options=QFileDialog.DontUseNativeDialog)
            self.__oldDataDir = os.path.dirname(dataPath)

            self.logger.info("Set inspect data : " + dataPath)
            self.txtInspectData.setText(dataPath)
            self.fileFlag = False

        try:
            # 한글검사
            str(dataPath)

        except:
            QMessageBox.warning(self.parent, u'검사 대상 경로 오류',
                                u'검사 대상의 경로에 한글이 포함되어 있습니다.\n'
                                u'검사 대상의 위치를 이동해주시기 바랍니다.\n\n'
                                u'선택한 경로 : ' + dataPath)
            self.txtInspectData.setText('')

    def showLogicalTemporalInspect(self):
        inspectorNm = self.txtInspectorNm.text()
        inspectData = self.txtInspectData.text()

        if self.plugin.MODE != 'external' and inspectorNm == "":
            QMessageBox.warning(self.parent, u'입력값 오류', u'검사자 정보를 입력하셔야 검사가 가능합니다.')
            return

        elif inspectData == "":
            QMessageBox.warning(self.parent, u'입력값 오류', u'검사 대상을 먼저 선택하시고 실행할 검사종류를 선택해 주십시오.')
            return

        if self.inspectWidget:
            self.inspectWidget.hide()
            self.iface.removeDockWidget(self.inspectWidget)
            del self.inspectWidget
            self.inspectWidget = None

        checkFormat, errMsg = self.checkLayerFormat(inspectData)
        if checkFormat is False:
            QMessageBox.warning(self.parent, u'포맷일관성오류', u'{} 포맷일관성 오류'.format(errMsg))
            return
        else:
            self.inspectWidget = LogicalTemporalInspect(self, inspectData)

            self.inspectWidget.checkStandard()

            inspectProgress = InspectProgress(self.iface, u"검사 대상 확인 중", self.iface.mainWindow())
            inspectProgress.setSize(0)
            inspectProgress.show()

            checkResult, msg = self.inspectWidget.logicalInspector.dbUtil.checkInspectData(inspectData, inspectProgress)
            if not checkResult:
                QMessageBox.warning(self.parent, u"데이터 오류", msg)
            else:
                self.iface.addDockWidget(Qt.RightDockWidgetArea, self.inspectWidget)
                self.close()

            inspectProgress.close()
            del inspectProgress

            self.inspectWidget.startInspect()

    def showThematicInspect(self, opener=None):
        if not opener:
            inspectorNm = self.txtInspectorNm.text()
            inspectData = self.txtInspectData.text()

            if self.plugin.MODE != 'external' and inspectorNm == "":
                QMessageBox.warning(self.parent, u'입력값 오류', u'검사자는 필수 입력값입니다.')
                return

            elif inspectData == "":
                QMessageBox.warning(self.parent, u'입력값 오류', u'검사 대상은 필수 입력값입니다.')
                return

            if self.inspectWidget:
                self.inspectWidget.hide()
                self.iface.removeDockWidget(self.inspectWidget)
                del self.inspectWidget
                self.inspectWidget = None

            checkFormat, errMsg = self.checkLayerFormat(inspectData)
            if checkFormat is False:
                QMessageBox.warning(self.parent, u'포맷일관성오류', u'{} 포맷일관성 오류'.format(errMsg))
                return
            else:
                self.inspectWidget = ThematicInspect(self)

                inspectProgress = InspectProgress(self.iface, u"검사 대상 확인 중 ...", self.iface.mainWindow())
                inspectProgress.setSize(0)
                inspectProgress.show()

                checkResult, msg = self.inspectWidget.thematicInspect.dbUtil.checkInspectData(inspectData, inspectProgress)
                if not checkResult:
                    QMessageBox.warning(self.parent, u"데이터 오류", msg)
                    self.inspectWidget.close()
                    return

                inspectProgress.close()
                del inspectProgress

        else:
            if self.inspectWidget:
                self.inspectWidget.hide()
                self.iface.removeDockWidget(self.inspectWidget)
                del self.inspectWidget
                self.inspectWidget = None

            self.inspectWidget = ThematicInspect(self)

        self.close()

        if self.plugin.MODE != 'external':
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.inspectWidget)
        else:
            QMessageBox.information(self.parent, u'주제정확도 검사',
                                    u'주제정확도 검사는\n별도의 검사 기능은 제공하지 않습니다.\n'
                                    u'제공되는 화면은 검사가 용이하도록 \n'
                                    u'레이어의 속성별로 분류한 화면입니다.\n참고하시기 바랍니다.')

        self.inspectWidget.loadData()

    def checkLayerFormat(self, file_dir):
        if self.fileFlag:
            driver = ogr.GetDriverByName("ESRI Shapefile")
            shp_list = ''
            file_list = os.listdir(file_dir)
            for file_name in file_list:
                shp_nm = os.path.join(file_dir, file_name)
                ext = os.path.splitext(shp_nm)[-1]
                if ext == '.shp':
                    layer_nm = file_name.replace('.shp', '')
                    chk_shp = os.path.isfile("{}\\{}{}".format(file_dir,layer_nm,".shp"))
                    chk_shx = os.path.isfile("{}\\{}{}".format(file_dir, layer_nm, ".shx"))
                    chk_dbf = os.path.isfile("{}\\{}{}".format(file_dir, layer_nm, ".dbf"))
                    if chk_shp is True and chk_shx is True and chk_dbf is True:
                        pass
                    else:
                        shp_list += layer_nm + '\n'
                    # try:
                    #     driver.Open(shp_nm, 0)
                    # except:
                    # if shp_data is None:
                    #     shp_list += layer_nm + '\n'
                    # gdal.OpenEx(shp_nm, gdal.OF_VECTOR, ["ESRI Shapefile"], ["ENCODING=UTF-8"])
            if shp_list == '':
                return True, None
            else:
                return False, shp_list
        else:
            driver = ogr.GetDriverByName("GPKG")
            gpkgNm = file_dir.split("/")[-1].replace(".gpkg", "")
            gpkg_data=driver.Open(file_dir, 0)
            if gpkg_data is None:
                return False, gpkgNm
            else:
                return True, None
            # gdal.OpenEx(file_dir, gdal.OF_VECTOR, ["GPKG"], ["ENCODING=UTF-8"])

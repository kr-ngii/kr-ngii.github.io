# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'InspectProgress.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_progress(object):
    def setupUi(self, progress):
        progress.setObjectName(_fromUtf8("progress"))
        progress.setWindowModality(QtCore.Qt.ApplicationModal)
        progress.resize(525, 115)
        progress.setMinimumSize(QtCore.QSize(525, 115))
        progress.setMaximumSize(QtCore.QSize(525, 115))
        progress.setAutoFillBackground(True)
        self.verticalLayout = QtGui.QVBoxLayout(progress)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.labelInspectInfo = QtGui.QLabel(progress)
        self.labelInspectInfo.setMinimumSize(QtCore.QSize(500, 16))
        self.labelInspectInfo.setMaximumSize(QtCore.QSize(500, 16))
        self.labelInspectInfo.setObjectName(_fromUtf8("labelInspectInfo"))
        self.verticalLayout.addWidget(self.labelInspectInfo)
        self.progressInspect = QtGui.QProgressBar(progress)
        self.progressInspect.setMinimumSize(QtCore.QSize(500, 25))
        self.progressInspect.setMaximumSize(QtCore.QSize(500, 25))
        self.progressInspect.setProperty("value", 0)
        self.progressInspect.setTextVisible(True)
        self.progressInspect.setObjectName(_fromUtf8("progressInspect"))
        self.verticalLayout.addWidget(self.progressInspect)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QtGui.QSpacerItem(150, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.btnOk = QtGui.QPushButton(progress)
        self.btnOk.setEnabled(False)
        self.btnOk.setMinimumSize(QtCore.QSize(100, 30))
        self.btnOk.setMaximumSize(QtCore.QSize(100, 30))
        self.btnOk.setFocusPolicy(QtCore.Qt.NoFocus)
        self.btnOk.setAutoFillBackground(True)
        self.btnOk.setObjectName(_fromUtf8("btnOk"))
        self.horizontalLayout.addWidget(self.btnOk)
        spacerItem1 = QtGui.QSpacerItem(150, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(progress)
        QtCore.QMetaObject.connectSlotsByName(progress)

    def retranslateUi(self, progress):
        progress.setWindowTitle(_translate("progress", "검사 진행 상황", None))
        self.labelInspectInfo.setText(_translate("progress", "논리일관성 검사 (0/0) - 위상일관성 검사", None))
        self.btnOk.setText(_translate("progress", "확 인", None))


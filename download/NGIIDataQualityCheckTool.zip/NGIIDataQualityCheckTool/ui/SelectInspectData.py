# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SelectInspectData.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_SelectInspectData(object):
    def setupUi(self, SelectInspectData):
        pass

    #     SelectInspectData.setObjectName(_fromUtf8("SelectInspectData"))
    #     SelectInspectData.resize(270, 170)
    #     SelectInspectData.setMinimumSize(QtCore.QSize(270, 170))
    #     SelectInspectData.setMaximumSize(QtCore.QSize(270, 170))
    #     self.verticalLayout = QtGui.QVBoxLayout(SelectInspectData)
    #     self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
    #     self.gridLayout = QtGui.QGridLayout()
    #     self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
    #     self.txtInspectorNm = QtGui.QLineEdit(SelectInspectData)
    #     self.txtInspectorNm.setMinimumSize(QtCore.QSize(100, 20))
    #     self.txtInspectorNm.setMaximumSize(QtCore.QSize(150, 20))
    #     self.txtInspectorNm.setObjectName(_fromUtf8("txtInspectorNm"))
    #     self.gridLayout.addWidget(self.txtInspectorNm, 0, 1, 1, 1)
    #     self.btnInspectData = QtGui.QPushButton(SelectInspectData)
    #     self.btnInspectData.setMinimumSize(QtCore.QSize(20, 20))
    #     self.btnInspectData.setMaximumSize(QtCore.QSize(20, 20))
    #     self.btnInspectData.setObjectName(_fromUtf8("btnInspectData"))
    #     self.gridLayout.addWidget(self.btnInspectData, 1, 2, 1, 1)
    #     self.txtInspectData = QtGui.QLineEdit(SelectInspectData)
    #     self.txtInspectData.setMinimumSize(QtCore.QSize(100, 20))
    #     self.txtInspectData.setMaximumSize(QtCore.QSize(150, 20))
    #     self.txtInspectData.setObjectName(_fromUtf8("txtInspectData"))
    #     self.gridLayout.addWidget(self.txtInspectData, 1, 1, 1, 1)
    #     self.label = QtGui.QLabel(SelectInspectData)
    #     self.label.setMinimumSize(QtCore.QSize(60, 25))
    #     self.label.setMaximumSize(QtCore.QSize(60, 25))
    #     self.label.setObjectName(_fromUtf8("label"))
    #     self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
    #     self.label_2 = QtGui.QLabel(SelectInspectData)
    #     self.label_2.setMinimumSize(QtCore.QSize(60, 25))
    #     self.label_2.setMaximumSize(QtCore.QSize(60, 25))
    #     self.label_2.setObjectName(_fromUtf8("label_2"))
    #     self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
    #     self.verticalLayout.addLayout(self.gridLayout)
    #     self.gridLayout_2 = QtGui.QGridLayout()
    #     self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
    #     self.btnLogicalInspect = QtGui.QPushButton(SelectInspectData)
    #     self.btnLogicalInspect.setMinimumSize(QtCore.QSize(75, 50))
    #     self.btnLogicalInspect.setMaximumSize(QtCore.QSize(75, 50))
    #     self.btnLogicalInspect.setObjectName(_fromUtf8("btnLogicalInspect"))
    #     self.gridLayout_2.addWidget(self.btnLogicalInspect, 0, 0, 1, 1)
    #     self.btnThematicInspect = QtGui.QPushButton(SelectInspectData)
    #     self.btnThematicInspect.setMinimumSize(QtCore.QSize(75, 50))
    #     self.btnThematicInspect.setMaximumSize(QtCore.QSize(75, 50))
    #     self.btnThematicInspect.setObjectName(_fromUtf8("btnThematicInspect"))
    #     self.gridLayout_2.addWidget(self.btnThematicInspect, 0, 1, 1, 1)
    #     self.btnInfoInspect = QtGui.QPushButton(SelectInspectData)
    #     self.btnInfoInspect.setMinimumSize(QtCore.QSize(75, 50))
    #     self.btnInfoInspect.setMaximumSize(QtCore.QSize(75, 50))
    #     self.btnInfoInspect.setObjectName(_fromUtf8("btnInfoInspect"))
    #     self.gridLayout_2.addWidget(self.btnInfoInspect, 0, 2, 1, 1)
    #     self.btnClose = QtGui.QPushButton(SelectInspectData)
    #     self.btnClose.setMinimumSize(QtCore.QSize(75, 25))
    #     self.btnClose.setMaximumSize(QtCore.QSize(75, 25))
    #     self.btnClose.setObjectName(_fromUtf8("btnClose"))
    #     self.gridLayout_2.addWidget(self.btnClose, 1, 1, 1, 1)
    #     self.verticalLayout.addLayout(self.gridLayout_2)
    #
    #     self.retranslateUi(SelectInspectData)
    #     QtCore.QMetaObject.connectSlotsByName(SelectInspectData)

    def retranslateUi(self, SelectInspectData):
        SelectInspectData.setWindowTitle(_translate("SelectInspectData", "검사 대상 선택", None))
        self.btnInspectData.setText(_translate("SelectInspectData", "...", None))
        self.label.setText(_translate("SelectInspectData", "검사자", None))
        self.label_2.setText(_translate("SelectInspectData", "검사 대상", None))
        self.btnLogicalInspect.setText(_translate("SelectInspectData", "논리일관성\n"
"검사", None))
        self.btnThematicInspect.setText(_translate("SelectInspectData", "주제정확도\n"
"검사", None))
        self.btnInfoInspect.setText(_translate("SelectInspectData", "정보완전성\n"
"검사", None))
        self.btnClose.setText(_translate("SelectInspectData", "닫 기", None))


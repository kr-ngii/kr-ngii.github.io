# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ExportReport.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ExportReport(object):
    def setupUi(self, ExportReport):
        ExportReport.setObjectName(_fromUtf8("ExportReport"))
        ExportReport.setEnabled(True)
        ExportReport.resize(553, 127)
        self.gridLayout = QtGui.QGridLayout(ExportReport)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.txtStatus = QtGui.QLabel(ExportReport)
        self.txtStatus.setEnabled(True)
        self.txtStatus.setObjectName(_fromUtf8("txtStatus"))
        self.gridLayout.addWidget(self.txtStatus, 0, 0, 1, 1)
        self.progress = QtGui.QProgressBar(ExportReport)
        self.progress.setProperty("value", 24)
        self.progress.setTextVisible(False)
        self.progress.setObjectName(_fromUtf8("progress"))
        self.gridLayout.addWidget(self.progress, 1, 0, 1, 1)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.btnOpenReport = QtGui.QPushButton(ExportReport)
        self.btnOpenReport.setEnabled(False)
        self.btnOpenReport.setMinimumSize(QtCore.QSize(150, 40))
        self.btnOpenReport.setMaximumSize(QtCore.QSize(150, 40))
        self.btnOpenReport.setAutoDefault(True)
        self.btnOpenReport.setObjectName(_fromUtf8("btnOpenReport"))
        self.horizontalLayout.addWidget(self.btnOpenReport)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.gridLayout.addLayout(self.horizontalLayout, 2, 0, 1, 1)

        self.retranslateUi(ExportReport)
        QtCore.QMetaObject.connectSlotsByName(ExportReport)

    def retranslateUi(self, ExportReport):
        ExportReport.setWindowTitle(_translate("ExportReport", "리포트 출력", None))
        self.txtStatus.setText(_translate("ExportReport", "리포트 생성 중 ...", None))
        self.btnOpenReport.setText(_translate("ExportReport", "리포트 열기", None))


# -*- coding: utf-8 -*-
import os

from ThematicDBUtil import ThematicDBUtil
from ThematicImgUtil import ThematicImgUtil
from ThematicRestapiUtil import ThematicRestapiUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ThematicInspector:
    B_CODE = "DTA"  # 주제정확성

    M_CODE = {
        "accuracy": "JTA",  # 주제정확도
    }

    progress = None

    def __init__(self, dock):
        self.logger = logger

        self.dbUtil = ThematicDBUtil()
        self.imgUtil = ThematicImgUtil(dock)
        self.restapiUtil = ThematicRestapiUtil()

    def getSchema(self):
        return self.dbUtil.INS_SCHEMA

    def getImgSavePath(self):
        return self.imgUtil.IMG_SAVE_PATH

    def saveImg(self, schema, layer, cid):
        return self.imgUtil.saveImg(schema, layer, "TATACC01", cid)

    def saveResult(self, data):
        return self.restapiUtil.saveResult(data)

    def completeInspect(self, insGroupId):
        return self.restapiUtil.completeInspect(self.B_CODE, insGroupId)
# -*- coding: utf-8 -*-
from psycopg2.sql import SQL, Identifier

from ..util.DBUtil import DBUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ThematicDBUtil(DBUtil):

    def __init__(self):
        DBUtil.__init__(self)
        self.logger = logger

    def closeDB(self):
        self.conn.close()
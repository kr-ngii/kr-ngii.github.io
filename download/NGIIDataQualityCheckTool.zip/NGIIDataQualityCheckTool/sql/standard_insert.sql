--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 9.6.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: qiresult; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA IF NOT EXISTS qiresult;

SET search_path = qiresult, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: com_code; Type: TABLE; Schema: qiresult; Owner: -
--

CREATE TABLE com_code (
    code character varying(20) NOT NULL,
    code_nm character varying(50) NOT NULL,
    group_cd character varying(20) NOT NULL,
    group_nm character varying(20) NOT NULL,
    upper_grp character varying(20),
    upper_cd character varying(20),
    use_yn character(1),
    crt_dt timestamp without time zone,
    code_lv integer
);


--
-- Name: TABLE com_code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON TABLE com_code IS '공통코드';


--
-- Name: COLUMN com_code.code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.code IS '코드ID';


--
-- Name: COLUMN com_code.code_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.code_nm IS '코드명';


--
-- Name: COLUMN com_code.group_cd; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.group_cd IS '그룹코드';


--
-- Name: COLUMN com_code.group_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.group_nm IS '그룹코드명';


--
-- Name: COLUMN com_code.upper_grp; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.upper_grp IS '상위코드그룹';


--
-- Name: COLUMN com_code.upper_cd; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.upper_cd IS '상위코드';


--
-- Name: COLUMN com_code.use_yn; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.use_yn IS '사용유무';


--
-- Name: COLUMN com_code.crt_dt; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.crt_dt IS '생성일시';


--
-- Name: COLUMN com_code.code_lv; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN com_code.code_lv IS '코드레벨';


--
-- Name: ins_standard; Type: TABLE; Schema: qiresult; Owner: -
--

CREATE TABLE ins_standard (
    seq_no integer NOT NULL,
    b_code character varying(20) NOT NULL,
    m_code character varying(20) NOT NULL,
    s_code character varying(20),
    t_code character varying(20),
    t_code_nm character varying(50),
    ins_unit character varying(20),
    ins_method character varying(100),
    ins_target_id character varying(100),
    ins_target_nm character varying(100),
    ins_std character varying(100),
    std_val character varying(10),
    use_yn character(1),
    crt_dt timestamp without time zone,
    sort_order integer
);


--
-- Name: TABLE ins_standard; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON TABLE ins_standard IS '검사기준';


--
-- Name: COLUMN ins_standard.seq_no; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.seq_no IS '순번';


--
-- Name: COLUMN ins_standard.b_code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.b_code IS '대분류코드';


--
-- Name: COLUMN ins_standard.m_code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.m_code IS '중분류코드';


--
-- Name: COLUMN ins_standard.s_code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.s_code IS '소분류코드';


--
-- Name: COLUMN ins_standard.t_code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.t_code IS '세분류코드';


--
-- Name: COLUMN ins_standard.t_code_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.t_code_nm IS '세분류코드명';


--
-- Name: COLUMN ins_standard.ins_unit; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.ins_unit IS '검사단위';


--
-- Name: COLUMN ins_standard.ins_method; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.ins_method IS '검사방법';


--
-- Name: COLUMN ins_standard.ins_target_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.ins_target_id IS '검사대상ID';


--
-- Name: COLUMN ins_standard.ins_target_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.ins_target_nm IS '검사대상명';


--
-- Name: COLUMN ins_standard.ins_std; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.ins_std IS '검사기준';


--
-- Name: COLUMN ins_standard.std_val; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.std_val IS '기준값';


--
-- Name: COLUMN ins_standard.use_yn; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.use_yn IS '사용유무';


--
-- Name: COLUMN ins_standard.crt_dt; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.crt_dt IS '생성일시';


--
-- Name: COLUMN ins_standard.sort_order; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN ins_standard.sort_order IS '정렬순서';


--
-- Name: ins_standard_seq_no_seq; Type: SEQUENCE; Schema: qiresult; Owner: -
--

CREATE SEQUENCE ins_standard_seq_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ins_standard_seq_no_seq; Type: SEQUENCE OWNED BY; Schema: qiresult; Owner: -
--

ALTER SEQUENCE ins_standard_seq_no_seq OWNED BY ins_standard.seq_no;


--
-- Name: std_codezip; Type: TABLE; Schema: qiresult; Owner: -
--

CREATE TABLE std_codezip (
    seq_no integer NOT NULL,
    codezip_id character varying(50),
    code character varying(30),
    code_nm character varying(30),
    code_order integer,
    crt_dt timestamp without time zone,
    use_yn character(1)
);


--
-- Name: TABLE std_codezip; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON TABLE std_codezip IS '표준코드집';


--
-- Name: COLUMN std_codezip.seq_no; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_codezip.seq_no IS '순번';


--
-- Name: COLUMN std_codezip.codezip_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_codezip.codezip_id IS '코드집ID';


--
-- Name: COLUMN std_codezip.code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_codezip.code IS '코드ID';


--
-- Name: COLUMN std_codezip.code_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_codezip.code_nm IS '코드명';


--
-- Name: COLUMN std_codezip.code_order; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_codezip.code_order IS '코드순서';


--
-- Name: std_codezip_seq_no_seq; Type: SEQUENCE; Schema: qiresult; Owner: -
--

CREATE SEQUENCE std_codezip_seq_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: std_codezip_seq_no_seq; Type: SEQUENCE OWNED BY; Schema: qiresult; Owner: -
--

ALTER SEQUENCE std_codezip_seq_no_seq OWNED BY std_codezip.seq_no;


--
-- Name: std_layer; Type: TABLE; Schema: qiresult; Owner: -
--

CREATE TABLE std_layer (
    layer_id character varying(50) NOT NULL,
    layer_nm character varying(50),
    layer_cd character varying(8),
    std_layer_id character varying(100),
    layer_package character varying(20),
    geom_type integer,
    use_yn character(1),
    crt_dt timestamp without time zone
);


--
-- Name: TABLE std_layer; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON TABLE std_layer IS '표준레이어목록';


--
-- Name: COLUMN std_layer.layer_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_layer.layer_id IS '레이어ID';


--
-- Name: COLUMN std_layer.layer_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_layer.layer_nm IS '레이어명';


--
-- Name: COLUMN std_layer.layer_cd; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_layer.layer_cd IS '레이어 분류코드';


--
-- Name: COLUMN std_layer.std_layer_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_layer.std_layer_id IS '레이어표준ID';


--
-- Name: COLUMN std_layer.layer_package; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_layer.layer_package IS '레이어패키지';


--
-- Name: COLUMN std_layer.geom_type; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_layer.geom_type IS '공간객체타입';


--
-- Name: std_struct; Type: TABLE; Schema: qiresult; Owner: -
--

CREATE TABLE std_struct (
    seq_no integer NOT NULL,
    layer_id character varying(50) NOT NULL,
    col_id character varying(30) NOT NULL,
    col_nm character varying(50),
    col_order integer NOT NULL,
    std_col_id character varying(100),
    col_type character varying(2),
    col_length integer,
    col_preci integer,
    col_mandt integer,
    codezip_id character varying(50),
    use_yn character(1),
    crt_dt timestamp without time zone
);


--
-- Name: TABLE std_struct; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON TABLE std_struct IS '표준레이어구조';


--
-- Name: COLUMN std_struct.seq_no; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.seq_no IS '순번';


--
-- Name: COLUMN std_struct.layer_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.layer_id IS '레이어ID';


--
-- Name: COLUMN std_struct.col_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_id IS '컬럼ID';


--
-- Name: COLUMN std_struct.col_nm; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_nm IS '컬럼명';


--
-- Name: COLUMN std_struct.col_order; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_order IS '컬럼순서';


--
-- Name: COLUMN std_struct.std_col_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.std_col_id IS '컬럼표준ID';


--
-- Name: COLUMN std_struct.col_type; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_type IS '컬럼타입';


--
-- Name: COLUMN std_struct.col_length; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_length IS '컬럼길이';


--
-- Name: COLUMN std_struct.col_preci; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_preci IS '컬럼정확도';


--
-- Name: COLUMN std_struct.col_mandt; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.col_mandt IS '컬럼필수여부';


--
-- Name: COLUMN std_struct.codezip_id; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON COLUMN std_struct.codezip_id IS '코드집ID';


--
-- Name: std_struct_seq_no_seq; Type: SEQUENCE; Schema: qiresult; Owner: -
--

CREATE SEQUENCE std_struct_seq_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: std_struct_seq_no_seq; Type: SEQUENCE OWNED BY; Schema: qiresult; Owner: -
--

ALTER SEQUENCE std_struct_seq_no_seq OWNED BY std_struct.seq_no;


--
-- Name: ins_standard seq_no; Type: DEFAULT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY ins_standard ALTER COLUMN seq_no SET DEFAULT nextval('ins_standard_seq_no_seq'::regclass);


--
-- Name: std_codezip seq_no; Type: DEFAULT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY std_codezip ALTER COLUMN seq_no SET DEFAULT nextval('std_codezip_seq_no_seq'::regclass);


--
-- Name: std_struct seq_no; Type: DEFAULT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY std_struct ALTER COLUMN seq_no SET DEFAULT nextval('std_struct_seq_no_seq'::regclass);


--
-- TOC entry 5746 (class 0 OID 184941)
-- Dependencies: 556
-- Data for Name: com_code; Type: TABLE DATA; Schema: qiresult; Owner: ngii
--

INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('DCN', '정보완전성', 'DBR_CODE', '품질요소', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', 1);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('DLC', '논리일관성', 'DBR_CODE', '품질요소', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', 1);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('DPA', '위치정확성', 'DBR_CODE', '품질요소', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', 1);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('DTA', '주제정확성', 'DBR_CODE', '품질요소', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', 1);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('DTQ', '시간정확성', 'DBR_CODE', '품질요소', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', 1);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JCC', '개념일관성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DLC', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JCN', '정보완전성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DCN', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JDC', '도메인일관성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DLC', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JFC', '포맷일관성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DLC', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JPA', '위치정확성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DPA', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JTA', '주제정확성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DTA', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JTC', '위상일관성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DLC', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('JTQ', '시간정확성', 'JBR_CODE', '세부요소', 'DBR_CODE', 'DTQ', 'Y', '2018-05-16 03:04:22.62579', 2);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SBM', '경계 불일치', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SBV', '경계 침범', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SCC', '분류정확도', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTA', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SCV', '코드리스트 규칙준수', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JDC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SDO', '객체 중복', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SEC', '등고선 오류', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SHL', '홀(Hole) 폴리곤', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SMC', '중심선 누락', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SMD', '메타데이터', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JFC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SMM', '중심선속성불일지', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SNE', '숫자오류', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JDC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SNI', 'NFID 무결성', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SPE', '위치오류', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JPA', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SPM', '정기수정', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JCN', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SRV', '범위 불일치', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JDC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SSF', '성과포맷준수', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JFC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SSG', '도형 형상', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('SSR', '스키마규칙준수', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JCC', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('STC', '시간일관성', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTQ', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('STM', '시간측정정확성', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTQ', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('STV', '시간유효성', 'SBR_CODE', '검사항목', 'JBR_CODE', 'JTQ', 'Y', '2018-05-16 03:04:22.62579', 3);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CNCNFM01', '누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SFM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CNCNFM02', '초과', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SFM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CNCNPM01', '누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SPM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CNCNPM02', '초과', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SPM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CNCNPM03', '묘사오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SPM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCCCSR01', '미정의 레이어', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSR', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCCCSR02', '테이블 컬럼 규칙 비준수', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSR', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCCCSR03', '필수 컬럼 속성 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSR', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCCCSR04', '객체타입 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSR', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCCCSR05', '컬럼타입 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSR', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCCV01', '코드리스트 비준수', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SCV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCNE01', '숫자 타입 입력 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SNE', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV01', '소로폭 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV02', '면리간도로폭 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV03', '실폭차도폭 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV04', '차로수 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV05', '건물 층수 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV06', '일반주택의 주기', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCDCRV07', '높이값 범위 초과', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SRV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCFCMD01', '메타데이터 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMD', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCFCSF01', '포맷 규칙 비준수', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSF', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBM01', '교량경계 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBM02', '터널경계 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBM03', '입체교차부 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBM04', '차도경계면 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV01', '건물/건물 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV03', '건물/부속시설 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV04', '건물/차도 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV05', '건물/보도 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV07', '건물/경지 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV08', '건물/산지 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV09', '건물/등고선 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV10', '건물/표고점 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV11', '건물/제방 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV12', '실폭하천/제방 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV13', '하천경계/제방 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV14', '건물/면형구조시설 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV15', '건물/선형구조시설 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV16', '건물/점형구조시설 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV17', '하천경계/건물 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV18', '하천경계/건물부속시설 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCBV19', '하천경계/면형구조시설 침범', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SBV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCDO01', '중복객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SDO', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCEC01', '등고선 교차', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SEC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCEC02', '등고선 미연결', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SEC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCEC03', '등고선 단락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SEC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCEC04', '등고선 꺽임', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SEC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCHL01', '홀(Hole) 과 동일한 객체 존재', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SHL', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMC01', '차도중심선 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMC02', '보도중심선 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMC03', '자전거도로중심선 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMC05', '철도중심선 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMC06', '하천중심선 누락', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMM01', '차도중심선 속성불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMM02', '철도중심선 속성불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCMM03', '하천중심선 속성불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SMM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCNI01', '수정/삭제객체 NFID 오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SNI', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCNI02', '경계면 참조NFID블일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SNI', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCNI03', '중심선 NFID 중복', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SNI', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG01', '꼬임선형 객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG02', '정점중복선형 객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG03', '1 포인트 객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG04', '미세면적 객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG05', '짧은선형 객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG06', '결함있는 연결', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG07', '언더슛', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG08', '오버슛', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG09', '댕글링', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('LCTCSG10', '슬리버 객체', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SSG', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('PAPAPE01', '수평위치정확도', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SPE', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('PAPAPE02', '수직위치정확도', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SPE', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('TATACC01', '지형지물 분류 불일치', 'ERR_CODE', '오류유형', 'SBR_CODE', 'SCC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('TQTQTC01', '시간충돌오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'STC', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('TQTQTM01', '시간범위오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'STM', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('TQTQTV01', '시간포맷오류', 'ERR_CODE', '오류유형', 'SBR_CODE', 'STV', 'Y', '2018-05-16 03:04:22.62579', 4);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CAS001', '승인', 'CAS_CODE', '승인처리여부구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('CAS002', '미승인', 'CAS_CODE', '승인처리여부구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS001', '검사대기', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS002', '적합', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS003', '미검사', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS004', '주의', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS005', '부적합', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS006', '진행중', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('IVS010', '예외', 'IVS_CODE', '품질검사결과', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('OCS001', '추가', 'OCS_CODE', '객체변동구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('OCS002', '삭제', 'OCS_CODE', '객체변동구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('OCS003', '형상수정', 'OCS_CODE', '객체변동구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('OCS004', '속성수정', 'OCS_CODE', '객체변동구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('OCS005', '형상/속성수정', 'OCS_CODE', '객체변동구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('UBS000', '미분류', 'UBS_CODE', '갱신사업구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('UBS001', '사진측량수정', 'UBS_CODE', '갱신사업구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('UBS002', '현황측량수정', 'UBS_CODE', '갱신사업구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);
INSERT INTO com_code (code, code_nm, group_cd, group_nm, upper_grp, upper_cd, use_yn, crt_dt, code_lv) VALUES ('UBS003', '기타', 'UBS_CODE', '갱신사업구분', NULL, NULL, 'Y', '2018-05-16 03:04:22.62579', NULL);

--
-- TOC entry 5745 (class 0 OID 184927)
-- Dependencies: 555
-- Data for Name: ins_standard; Type: TABLE DATA; Schema: qiresult; Owner: ngii
--

INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (14, 'DLC', 'JDC', 'SRV', 'LCDCRV04', '차로수 오류', '차선', '차도중심선의 차로수가 1 이상인지 확인', 'TN_RODWAY_CTLN(CARTRK_CO)', '차도중심선', '차로수 1차선 미만', ',1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (47, 'DLC', 'JTC', 'SMC', 'LCTCMC01', '차도중심선 누락', '-', 'NFID로 연결되는 차도중심선과 차도경계면에서 중심선이 경계면을 10cm 이상 벗어나거나 10cm 이상의 거리로 닿지 못하는지 확인', 'TN_RODWAY_BNDRY,TN_RODWAY_CTLN', '차도중심선, 차도경계면', '차도중심선과 차도경계면 연결 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (38, 'DLC', 'JTC', 'SBV', 'LCTCBV17', '하천경계/건물 침범', 'm', '하천경계를 건물이 침범하는지 확인', 'TN_RIVER_BNDRY,TN_BULD', '하천경계, 건물', '하천경계를 건물이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (39, 'DLC', 'JTC', 'SBV', 'LCTCBV18', '하천경계/건물부속시설 침범', 'm', '하천경계를 건물부속시설이 침범하는지 확인', 'TN_RIVER_BNDRY,TN_BULD_ADCLS', '하천경계, 건물부속시설', '하천경계를 건물부속시설이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (40, 'DLC', 'JTC', 'SBV', 'LCTCBV19', '하천경계/면형구조시설 침범', 'm', '하천경계를 면형구조시설이 침범하는지 확인', 'TN_RIVER_BNDRY,TN_ARSFC', '하천경계, 면형구조시설', '하천경계를 면형구조시설이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (27, 'DLC', 'JTC', 'SBV', 'LCTCBV05', '건물/보도 침범', 'm', '건물을 보도경계면이 침범하는지 확인', 'TN_BULD,TN_FTPTH_BNDRY', '건물, 보도경계면', '건물을 보도경계면이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (31, 'DLC', 'JTC', 'SBV', 'LCTCBV10', '건물/표고점 침범', '-', '건물위에 표고점이 있는지 확인', 'TN_BULD,TN_ALPT', '건물, 표고점', '건물을 표고점이 침범', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (45, 'DLC', 'JTC', 'SEC', 'LCTCEC04', '등고선 꺽임', '도', '등고선의 정점 사이에 90도 미만 예각 연결이 있는지 확인', 'TN_CTRLN', '등고선', '90도 미만', ',90', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (18, 'DLC', 'JFC', 'SMD', 'LCFCMD01', '메타데이터 누락', '-', '좌표계(EPSG:5179), 기반자료일자, 갱신일자, 갱신사유, 갱신업체명, 사업정보의 필수 메타정보 확인', 'ALL', '납품 파일', '필수 메타데이터 누락', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (44, 'DLC', 'JTC', 'SEC', 'LCTCEC03', '등고선 단락', '-', '등고선 끝점에 다른 등고선 혹은 해안, 하천, 호소 객체가 있는지 확인', 'TN_CTRLN,TN_SHORLINE,TN_RIVER_BNDRY,TN_LKMH', '등고선, 해안선, 하천, 호소', '등고선이 연결되지 않고 수계가 아닌 곳에서 끊어져 있음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (32, 'DLC', 'JTC', 'SBV', 'LCTCBV11', '건물/제방 침범', 'm', '건물을 제방이 침범하는지 확인', 'TN_BULD,TN_WTCORS_FCLTY(WWF001/WWF002)', '건물, 수로시설 중 제방', '건물을 수로시설 중 제방이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (33, 'DLC', 'JTC', 'SBV', 'LCTCBV12', '실폭하천/제방 침범', 'm', '실폭하천이 종류가 제방인 수로시설을 침범하는지 확인', 'TN_WTCORS_FCLTY(WWF001/WWF002),TN_RIVER_BT', '실폭하천, 수로시설 중 제방', '실폭하천이 제방을 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (17, 'DLC', 'JDC', 'SRV', 'LCDCRV07', '높이값 범위 초과', 'm', '높이값에 한라산 높이보다 큰 값이 입력되었는지 확인', 'TN_CTRLN(CTRLN_HG),TN_ALPT(ALPT_HG)', '등고선, 표고점', '2000 미만만 허용', ',2000', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (34, 'DLC', 'JTC', 'SBV', 'LCTCBV13', '하천경계/제방 침범', 'm', '하천경계를 종류가 제방 상단인 수로시설이 침범하는지 확인', 'TN_WTCORS_FCLTY(WWF001),TN_RIVER_BNDRY', '하천경계, 수로시설 중 제방', '하천경계를 제방 상단이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (25, 'DLC', 'JTC', 'SBV', 'LCTCBV03', '건물/부속시설 침범', 'm', '건물을 건물부속시설이 침범하는지 확인', 'TN_BULD,TN_BULD_ADCLS', '건물, 건물부속시설', '건물을 건물부속시설이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (46, 'DLC', 'JTC', 'SHL', 'LCTCHL01', '홀(Hole) 과 동일한 객체 존재', '-', '홀(Hole) 과 동일한 객체가 존재하는지 확인', 'TN_BULD,TN_FMLND_BNDRY,TN_RIVER_BT,TN_LKMH', '건물, 경지경계, 실폭하천, 호소', '홀(Hole) 과 동일한 객체가 존재', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (26, 'DLC', 'JTC', 'SBV', 'LCTCBV04', '건물/차도 침범', 'm', '건물을 차도경계면이 침범하는지 확인', 'TN_BULD(BDK001/BDK002/BDK003/BDK004/BDK006/BDK007/BDK008),TN_RODWAY_BNDRY', '건물, 차도경계면', '건물을 차도경계면이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (48, 'DLC', 'JTC', 'SMC', 'LCTCMC02', '보도중심선 누락', '-', '보도중심선과 보도경계면에서 중심선이 경계면을 10cm 이상 벗어나거나 10cm 이상의 거리로 닿지 못하는지 확인', 'TN_FTPTH_BNDRY,TN_FTPTH_CTLN', '보도중심선, 보도경계면', '보도중심선과 보도경계면 연결 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (61, 'DLC', 'JTC', 'SSG', 'LCTCSG04', '미세면적 객체', '㎡', '미세 면적 객체가 있는지 확인', 'POLYGON', '면형 타입 레이어', '0.1㎡ 미만', ',0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (10, 'DLC', 'JDC', 'SNE', 'LCDCNE01', '숫자 타입 입력 오류', '-', '숫자 컬럼에 숫자로 해석할 수 없는 문자(m 등) 있는지 확인', 'ALL', '모든 레이어의 숫자타입 컬럼', '숫자 컬럼에 해석할 수 없는 문제 있음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (56, 'DLC', 'JTC', 'SNI', 'LCTCNI02', '경계면 참조NFID 불일치', '-', '경계면 신규객체에 참조NFID에 해당하는 중심선 신규객체의 NFID가 있는지 확인', 'TN_RODWAY_BNDRY,TN_RODWAY_CTLN', '차도경계면의 신규 객체', '연결되는 중심선 NFID 없음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (55, 'DLC', 'JTC', 'SNI', 'LCTCNI01', '수정/삭제객체 NFID 오류', '-', '수정 혹은 삭제된 객체에 NFID가 있어야 하며 표준형식에 맞아야 함', 'ALL', '삭제, 수정 객체', 'NFID가 표준과 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (57, 'DLC', 'JTC', 'SNI', 'LCTCNI03', '중심선 NFID 중복', '-', '중심선 신규객체들의 NFID가 중복되는지 확인', 'TN_RODWAY_CTLN', '차도중심선의 신규 객체', '중심선 NFID 중복', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (52, 'DLC', 'JTC', 'SMM', 'LCTCMM01', '차도중심선 속성불일치', '-', '교차로가 아닌 곳에서 접한 2개의 도로중심선의 주요 속성이 다른지 확인', 'TN_RODWAY_CTLN(ROAD_NO/ROAD_NM/ROAD_SE)', '차도중심선', '도로번호, 도로명칭, 도로구분 속성 중 하나라도 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (53, 'DLC', 'JTC', 'SMM', 'LCTCMM02', '철도도중심선 속성불일치', '-', '철도교차점이 아닌 곳에서 접한 2개의 철도중심선의 주요 속성이 다른지 확인', 'TN_RLROAD_CTLN(RLWAY_NM/RLWTY_SE)', '철도중심선', '철도선로명칭, 철도선로유형 속성 중 하나라도 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (60, 'DLC', 'JTC', 'SSG', 'LCTCSG03', '1 포인트 객체', '-', '선형의 경우 1점, 면형의 경우 2점 이하인지 확인', 'LINESTRING,POLYGON', '선형 혹은 면형 타입 레이어', '도형을 만들기에 점이 부족', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (63, 'DLC', 'JTC', 'SSG', 'LCTCSG06', '결함있는 연결', '-', '사거리, 삼거리 등의 중심선이 한 점에 일치하는지 확인', 'TN_RODWAY_CTLN,TN_RLROAD_CTLN,TN_RIVER_CTLN', '차도중심선, 철도중심선, 하천중심선', '다수의 중심선이 한 점에서 연결되지 않음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (64, 'DLC', 'JTC', 'SSG', 'LCTCSG07', '언더슛', 'm', '중심선 끝이 1m 미만의 거리로 다른 중심선과 떨어져 있음', 'TN_RODWAY_CTLN,TN_RLROAD_CTLN,TN_RIVER_CTLN', '차도중심선, 철도중심선, 하천중심선', '1m 미만', ',1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (65, 'DLC', 'JTC', 'SSG', 'LCTCSG08', '오버슛', 'm', '중심선 끝이 1m 미만의 거리로 다른 중심선을 지나치고 있음', 'TN_RODWAY_CTLN,TN_RLROAD_CTLN,TN_RIVER_CTLN', '차도중심선, 철도중심선, 하천중심선', '1m 미만', ',1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (66, 'DLC', 'JTC', 'SSG', 'LCTCSG09', '댕글링', 'm', '계속 연결되지 않는 1m 미만 중심선 존재', 'TN_RODWAY_CTLN,TN_RLROAD_CTLN,TN_RIVER_CTLN', '차도중심선, 철도중심선, 하천중심선', '1m 미만', ',1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (67, 'DLC', 'JTC', 'SSG', 'LCTCSG10', '슬리버 객체', '㎡', '슬리버 객체가 있는지 확인', 'POLYGON', '면형 타입 레이어', '2㎡ 미만, 두께지수(T) 0.2 미만', '2,0.2', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (54, 'DLC', 'JTC', 'SMM', 'LCTCMM03', '하천중심선 속성불일치', '-', '하천교차점이 아닌 곳에서 접한 2개의 하천중심선의 주요 속성이 다른지 확인', 'TN_RIVER_CTLN(RIVER_NO/RIVER_NM/RIVER_SE)', '하천중심선', '하천번호, 하천명칭, 하천구분 속성 중 하나라도 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (59, 'DLC', 'JTC', 'SSG', 'LCTCSG02', '정점중복선형 객체', 'm', '정점간격 거리가 너무 짧은지 확인', 'LINESTRING,POLYGON', '선형 혹은 면형 타입 레이어', '1cm 미만', ',0.01', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (62, 'DLC', 'JTC', 'SSG', 'LCTCSG05', '짧은선형 객체', 'm', '짧은 선형 객체가 있는지 확인', 'LINESTRING', '선형 타입 레이어', '1cm 미만', ',0.01', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (58, 'DLC', 'JTC', 'SSG', 'LCTCSG01', '꼬임선형 객체', '-', '도형이 꼬이거나 정점이 동일 구간 중복되는지 확인', 'LINESTRING,POLYGON', '선형 혹은 면형 타입 레이어', '선 혹은 면에 꼬임이 있음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (50, 'DLC', 'JTC', 'SMC', 'LCTCMC05', '철도중심선 누락', '-', '철도중심선과 철도경계면에서 중심선이 경계면을 10cm 이상 벗어나거나 10cm 이상의 거리로 닿지 못하는지 확인', 'TN_RLROAD_BNDRY,TN_RLROAD_CTLN', '철도중심선, 철도경계면', '철도중심선과 철도경계면 연결 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (51, 'DLC', 'JTC', 'SMC', 'LCTCMC06', '하천중심선 누락', '-', '하천중심선과 하천경계에서 중심선이 경계면을 10cm 이상 벗어나거나 10cm 이상의 거리로 닿지 못하는지 확인', 'TN_RIVER_BNDRY,TN_RIVER_CTLN', '하천경계, 하천중심선', '하천경계와 하천중심선 연결 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (36, 'DLC', 'JTC', 'SBV', 'LCTCBV15', '건물/선형구조시설 침범', 'm', '건물을 선형구조시설이 침범하는지 확인', 'TN_BULD,TN_LNSFC', '건물, 선형구조시설', '건물을 선형구조시설이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (37, 'DLC', 'JTC', 'SBV', 'LCTCBV16', '건물/점형구조시설 침범', '-', '건물을 점형구조시설이 침범하는지 확인', 'TN_BULD,TN_PTSFC', '건물, 점형구조시설', '건물을 점형구조시설이 침범', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (29, 'DLC', 'JTC', 'SBV', 'LCTCBV08', '건물/산지 침범', 'm', '건물을 산지경계가 침범하는지 확인', 'TN_BULD,TN_MTC_BNDRY', '건물, 산지경계', '건물을 산지경계가 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (7, 'DLC', 'JCC', 'SSR', 'LCCCSR04', '객체타입 불일치', '-', '점, 선, 면의 형태와 Multi 타입이 맞는지 확인', 'ALL', '모든 레이어의 도형 컬럼', '레이어의 도형타입이 표준과 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (20, 'DLC', 'JTC', 'SBM', 'LCTCBM01', '교량경계 불일치', '-', '종류가 교량인 면형도로시설은 차도경계면 혹은 철도경계면에 완전히 포함 되는지 확인', 'TN_ARRFC(PGR001/PGR005),TN_RLROAD_BNDRY,TN_RODWAY_BNDRY', '차도경계면, 철도경계면, 면형도로시설 중 교량', '교량이 차도경계면 혹은 철도경계면에 포함 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (21, 'DLC', 'JTC', 'SBM', 'LCTCBM02', '터널경계 불일치', '-', '종류가 터널인 면형도로시설은 차도경계면 혹은 철도경계면에 완전히 포함 되는지 확인', 'TN_ARRFC(PGR008/PGR010),TN_RLROAD_BNDRY,TN_RODWAY_BNDRY', '차도경계면, 철도경계면, 면형도로시설 중 터널', '터널이 차도경계면 혹은 철도경계면에 포함 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (22, 'DLC', 'JTC', 'SBM', 'LCTCBM03', '입체교차부 불일치', '-', '종류가 입체교차부인 면형도로시설은 차도경계면 혹은 철도경계면에 완전히 포함 되는지 확인', 'TN_ARRFC(PGR014/PGR015),TN_RLROAD_BNDRY,TN_RODWAY_BNDRY', '차도경계면, 철도경계면, 면형도로시설 중 입체교차부', '입체교차부가 차도경계면 혹은 철도경계면에 포함 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (1, 'DCN', 'JCN', 'SPM', 'CNCNPM01', '누락', '-', '단사진 검사', 'ALL', '지형 및 법상에 존재하지 않은 모든 레이어', '영상의 객체 누락', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (2, 'DCN', 'JCN', 'SPM', 'CNCNPM02', '초과', '-', '단사진 검사', 'ALL', '지형 및 법상에 존재하지 않은 모든 레이어', '영상에 없는 객체가 존재', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (4, 'DLC', 'JCC', 'SSR', 'LCCCSR01', '미정의 레이어', '-', '납품받은 레이어 목록 중 표준에 없는 것이 있는지 확인 ', 'ALL', '모든 레이어', '미정의 레이어 있으면 안됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (5, 'DLC', 'JCC', 'SSR', 'LCCCSR02', '테이블 컬럼 규칙 비준수', '-', '표준 컬럼이 모두 존재하는지 확인', 'ALL', '모든 레이어', '표준에 정의된 컬럼이 누락됨', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (6, 'DLC', 'JCC', 'SSR', 'LCCCSR03', '필수 컬럼 속성 누락', '-', '필수 컬럼에 값이 들어 있는지 확인', 'ALL', '모든 레이어', '필수 컬럼에 값이 없음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (3, 'DCN', 'JCN', 'SPM', 'CNCNPM03', '묘사오류', '-', '단사진 검사', 'ALL', '지형 및 법상에 존재하지 않은 모든 레이어', '영상과 다른 형태로 그려짐', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (8, 'DLC', 'JCC', 'SSR', 'LCCCSR05', '컬럼타입 불일치', '-', '국가기본도 자료표준과 일치 확인', 'ALL', '모든 레이어의 모든 컬럼', '컬럼의 타입이 표준과 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (28, 'DLC', 'JTC', 'SBV', 'LCTCBV07', '건물/경지 침범', 'm', '건물을 경지경계가 침범하는지 확인', 'TN_BULD,TN_FMLND_BNDRY', '건물, 경지경계', '건물을 경지경계가 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (35, 'DLC', 'JTC', 'SBV', 'LCTCBV14', '건물/면형구조시설 침범', 'm', '건물을 면형구조시설이 침범하는지 확인', 'TN_BULD,TN_ARSFC', '건물, 면형구조시설', '건물을 면형구조시설이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (30, 'DLC', 'JTC', 'SBV', 'LCTCBV09', '건물/등고선 침범', 'm', '건물위로 등고선이 지나가는지 확인', 'TN_BULD,TN_CTRLN', '건물, 등고선', '건물을 등고선이 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (15, 'DLC', 'JDC', 'SRV', 'LCDCRV05', '건물 층수 오류', '층', '건물층수가 1 이상인지 확인', 'TN_BULD(BFLR_CO)', '건물', '건물층수가 1 미만', ',1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (13, 'DLC', 'JDC', 'SRV', 'LCDCRV03', '실폭차도폭 오류', 'm', '도로구분이 실폭차도인 경우 도로폭이 3.0m 이상인지 확인', 'TN_RODWAY_CTLN(ROAD_SE/RDD010/RDD014/ROAD_BT)', '차도중심선', '실포차도의 도로폭이 3.0m이상 이외 값 입력', ',3', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (9, 'DLC', 'JDC', 'SCV', 'LCDCCV01', '코드리스트 비준수', '-', '각 컬럼에 해당하는 코드집 내의 값인지 확인', 'ALL', '모든 레이어의 코드타입 컬럼', '해당 코드집 내의 값이 아님', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (16, 'DLC', 'JDC', 'SRV', 'LCDCRV06', '일반주택의 주기', '-', '건물구분이 일반주택인 경우 건물명칭이 있는지 확인', 'TN_BULD(BULD_SE/BDK001/BULD_NM)', '건물', '일반주택에 건물명칭 입력', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (12, 'DLC', 'JDC', 'SRV', 'LCDCRV02', '면리간도로폭 오류', 'm', '도로구분이 면리간도로인 경우 도로폭이 1.5m초과~3.0m 미만인지 확인', 'TN_RODWAY_CTLN(ROAD_SE/RDD010/ROAD_BT)', '차도중심선', '면리간도로의 도로폭이 1.5m초과~3.0m미만 이외 값 입력', '1.6,3.0', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (24, 'DLC', 'JTC', 'SBV', 'LCTCBV01', '건물/건물 침범', 'm', '건물간에 침범이 있는지 확인', 'TN_BULD', '건물', '건물간에 서로 침범', '0.1', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (11, 'DLC', 'JDC', 'SRV', 'LCDCRV01', '소로폭 오류', 'm', '도로구분이 소로인 경우 도로폭이 1.5인지 확인', 'TN_RODWAY_CTLN(ROAD_SE/RDD014/ROAD_BT)', '차도중심선', '소로의 도로폭이 1.5m 인지 확인', '1.5', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (19, 'DLC', 'JFC', 'SSF', 'LCFCSF01', '포맷 규칙 비준수', '-', 'Shape 읽어 GeoPackage 변환, 납품된 파일이 GeoPackage 1.2 포맷인지 확인', 'ALL', '납품 파일', 'Shape 파일 읽지 못함, GeoPackage 1.2 아님', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (68, 'DPA', 'JPA', 'SPE', 'PAPAPE01', '수평위치정확도', 'm', '위치정확도 검증대상점들의 실측값과 도상값 수평 오차 확인', 'ALL', '모든레이어', '1.5m(최대허용오차3.0m)', '1.5', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (69, 'DPA', 'JPA', 'SPE', 'PAPAPE02', '수직위치정확도', 'm', '위치정확도 검증대상점들의 실측값과 도상값 수직 오차 확인', 'ALL', '모든레이어', '1.5m(최대허용오차3.0m)', '1.5', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (41, 'DLC', 'JTC', 'SDO', 'LCTCDO01', '중복객체', '-', '같은 위치에 동일 형상 객체가 있는지 확인', 'ALL', '모든 레이어', '동일객체 여러 개 존재', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (42, 'DLC', 'JTC', 'SEC', 'LCTCEC01', '등고선 교차', '-', '등고선 간의 교차가 있어서는 안됨', 'TN_CTRLN', '등고선', '다른 등고선과 교차 발생', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (70, 'DTA', 'JTA', 'SCC', 'TATACC01', '지형지물 분류 불일치', '-', '각 레이어의 주요 속성을 시각화하여 분류가 실제와 일치하는지 육안검사', 'ALL', '모든 레이어', '실제와 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (43, 'DLC', 'JTC', 'SEC', 'LCTCEC02', '등고선 미연결', '-', '인접해 닿아 있는 등고선의 높이가 같은지 확인', 'TN_CTRLN(CTRLN_HG)', '등고선', '인접하는 등고선과 높이 다름', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (71, 'DTQ', 'JTQ', 'STC', 'TQTQTC01', '시간충돌오류', '-', '국가기본도 DB의 변동객체 공간범위에 기반자료일자부터 현재까지 수정 이력이 있는지 확인', 'ALL', '객체별 메타데이터의 기반자료일자', '동일 영역에 기반자료일자까지 변경 있음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (73, 'DTQ', 'JTQ', 'STV', 'TQTQTV01', '시간포맷오류', '-', '객체 메타데이터의 시간자료의 값이 해석 가능한지 확인', 'ALL', '객체별 메타데이터의 기반자료일자, 갱신일자', '해석할 수 없는 시간', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);
INSERT INTO ins_standard (seq_no, b_code, m_code, s_code, t_code, t_code_nm, ins_unit, ins_method, ins_target_id, ins_target_nm, ins_std, std_val, use_yn, crt_dt, sort_order) VALUES (72, 'DTQ', 'JTQ', 'STM', 'TQTQTM01', '시간범위오류', '-', '기반자료일자 값이 갱신일자보다 늦은 값이 입력되었는지 확인', 'ALL', '객체별 메타데이터의 기반자료일자, 갱신일자', '기반자료일자가 갱신일자보다 늦음', '-', 'Y', '2018-05-16 03:03:52.806447', NULL);


--
-- TOC entry 5756 (class 0 OID 0)
-- Dependencies: 554
-- Name: ins_standard_seq_no_seq; Type: SEQUENCE SET; Schema: qiresult; Owner: ngii
--

SELECT pg_catalog.setval('ins_standard_seq_no_seq', 73, true);


--
-- TOC entry 5748 (class 0 OID 184950)
-- Dependencies: 558
-- Data for Name: std_codezip; Type: TABLE DATA; Schema: qiresult; Owner: ngii
--

INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (49, 'kind_Code', 'OSF002', '극장', 38, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (70, 'kind_Code', 'LSF007', '승마장', 59, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (71, 'kind_Code', 'LSF008', '해수욕장', 60, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (72, 'kind_Code', 'LSF009', '운동장', 61, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (73, 'kind_Code', 'LSF010', '체육관', 62, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (74, 'kind_Code', 'LSF011', '기타레저시설', 63, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (75, 'kind_Code', 'PRF001', '국립공원', 64, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (76, 'kind_Code', 'PRF002', '도립공원', 65, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (77, 'kind_Code', 'PRF003', '군립공원', 66, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (78, 'kind_Code', 'PRF004', '근린공원', 67, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (79, 'kind_Code', 'PRF005', '도시자연공원', 68, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (80, 'kind_Code', 'PRF006', '어린이공원', 69, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (81, 'kind_Code', 'PRF007', '체육공원', 70, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (82, 'kind_Code', 'PRF008', '유원지', 71, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (83, 'kind_Code', 'PRF009', '수목원', 72, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (84, 'kind_Code', 'PRF010', '휴양림', 73, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (85, 'kind_Code', 'PRF011', '기타공원', 74, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (86, 'kind_Code', 'TMF001', '관광지시설', 75, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (87, 'kind_Code', 'TMF002', '온천', 76, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (88, 'kind_Code', 'TMF003', '놀이동산', 77, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (89, 'kind_Code', 'TMF004', '특화거리구역', 78, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (90, 'kind_Code', 'TMF005', '문화재', 79, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (91, 'kind_Code', 'ICF001', '산업단지구역', 80, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (92, 'kind_Code', 'ICF002', '채취장', 81, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (93, 'kind_Code', 'ICF003', '밀집공업지역', 82, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (94, 'kind_Code', 'ICF004', '공업지역', 83, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (95, 'kind_Code', 'ICF005', '준공업지역', 84, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (96, 'kind_Code', 'AFF001', '양식장', 85, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (97, 'kind_Code', 'AFF002', '수산업지역', 86, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (98, 'kind_Code', 'AFF003', '농업지역', 87, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (99, 'kind_Code', 'AFF004', '축산지역', 88, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (100, 'kind_Code', 'SPF001', '백화점', 89, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (101, 'kind_Code', 'SPF002', '대형판매점', 90, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (102, 'kind_Code', 'SPF003', '시장', 91, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (103, 'kind_Code', 'SPF004', '기타쇼핑단지', 92, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (104, 'kind_Code', 'BSF001', '방송국', 93, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (105, 'kind_Code', 'BSF002', '신문사', 94, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (106, 'kind_Code', 'BSF003', '오피스텔', 95, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (107, 'kind_Code', 'BSF004', '업무시설', 96, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (108, 'kind_Code', 'BSF005', '금융시설', 97, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (109, 'kind_Code', 'MDF001', '병원', 98, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (110, 'kind_Code', 'MDF002', '보건소', 99, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (111, 'kind_Code', 'MDF003', '기타의료단지', 100, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (112, 'kind_Code', 'FCF001', '장례식장', 101, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (113, 'kind_Code', 'FCF002', '묘지공원', 102, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (114, 'kind_Code', 'FCF003', '공동묘지', 103, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (115, 'kind_Code', 'RLF001', '교회', 104, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (116, 'kind_Code', 'RLF002', '사찰', 105, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (117, 'kind_Code', 'RLF003', '성당', 106, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (118, 'kind_Code', 'RLF004', '기타종교집회장', 107, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (119, 'kind_Code', 'RSF001', '아파트단지', 108, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (120, 'kind_Code', 'RSF002', '다세대주택', 109, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (121, 'kind_Code', 'RSF003', '주택단지', 110, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (122, 'kind_Code', 'RSF004', '기숙사', 111, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (123, 'kind_Code', 'RSF005', '공관', 112, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (124, 'roadDivision_Code', 'RDD001', '고속국도', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (125, 'roadDivision_Code', 'RDD002', '일반국도', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (126, 'roadDivision_Code', 'RDD003', '지방도', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (127, 'roadDivision_Code', 'RDD004', '특별시도', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (128, 'roadDivision_Code', 'RDD005', '광역시도', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (129, 'roadDivision_Code', 'RDD006', '시도', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (130, 'roadDivision_Code', 'RDD007', '군도', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (131, 'roadDivision_Code', 'RDD008', '구도', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (132, 'roadDivision_Code', 'RDD009', '공사중도로', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (133, 'roadDivision_Code', 'RDD010', '면리간도로', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (134, 'roadDivision_Code', 'RDD011', '부지안도로', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (135, 'roadDivision_Code', 'RDD012', '건설예정도로', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (136, 'roadDivision_Code', 'RDD013', '터널안도로', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (137, 'roadDivision_Code', 'RDD014', '소로', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (138, 'pavementMaterial_Code', 'RDQ001', '아스팔트', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (139, 'pavementMaterial_Code', 'RDQ002', '아스팔트콘크리트', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (140, 'pavementMaterial_Code', 'RDQ003', '콘크리트', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (141, 'pavementMaterial_Code', 'RDQ004', '블록', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (142, 'pavementMaterial_Code', 'RDQ005', '비포장', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (143, 'pavementMaterial_Code', 'RDQ006', '포장', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (144, 'pavementMaterial_Code', 'SWQ005', '아스콘/블록', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (145, 'pavementMaterial_Code', 'RDQ999', '기타', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (146, 'onewayInfo_Code', 'ITH001', '일방통행', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (147, 'onewayInfo_Code', 'ITH002', '양방통행', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (148, 'motorwayInfo_Code', 'MOR001', '일반', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (149, 'motorwayInfo_Code', 'MOR002', '자동차전용', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (150, 'bikewayKind_Code', 'BIW001', '자전거전용도로', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (151, 'bikewayKind_Code', 'BIW002', '자전거보행자겸용도로', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (152, 'bikewayKind_Code', 'BIW003', '자전거자동차겸용도로', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (153, 'roadFacilityKind_Code', 'PIR001', '정류장/버스', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (154, 'roadFacilityKind_Code', 'PIR002', '정류장/택시', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (155, 'roadFacilityKind_Code', 'PGR001', '교량/도로교', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (156, 'roadFacilityKind_Code', 'PGR005', '교량/도로철도교', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (157, 'roadFacilityKind_Code', 'PGR008', '터널/도로터널', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (158, 'roadFacilityKind_Code', 'PGR010', '터널/공용터널', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (159, 'roadFacilityKind_Code', 'PGR014', '입체교차부/고가차도', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (160, 'roadFacilityKind_Code', 'PGR015', '입체교차부/지하차도', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (161, 'roadFacilityKind_Code', 'PGR027', '도로분리대', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (163, 'lineStructure_Code', 'MSS001', '화단', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (164, 'lineStructure_Code', 'MSS002', '콘크리트', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (165, 'lineStructure_Code', 'MSS003', '철제', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (166, 'lineStructure_Code', 'MSS004', '플라스틱', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (167, 'lineStructure_Code', 'MSS999', '기타', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (168, 'polygonType_Code', 'PGR002', '교량/보행교', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (169, 'polygonType_Code', 'PGR003', '교량/철도교', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (170, 'polygonType_Code', 'PGR004', '교량/도로보행교', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (171, 'polygonType_Code', 'PGR006', '교량/철도보행교', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (172, 'polygonType_Code', 'PGR007', '교량/생태교', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (173, 'polygonType_Code', 'PGR009', '터널/철도터널', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (174, 'polygonType_Code', 'PGR011', '보행시설/지하보도', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (175, 'polygonType_Code', 'PGR012', '보행시설/육교', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (176, 'polygonType_Code', 'PGR013', '보행시설/횡단보도', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (177, 'polygonType_Code', 'PGR016', '안전지대/교통섬', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (178, 'polygonType_Code', 'PGR017', '안전지대/어린이보호구역', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (179, 'polygonType_Code', 'PGR018', '안전지대/노인보호구역', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (180, 'polygonType_Code', 'PGR019', '주유소/유류', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (181, 'polygonType_Code', 'PGR020', '주유소/가스', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (182, 'polygonType_Code', 'PGR021', '주유소/전기', 15, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (183, 'polygonType_Code', 'PGR022', '주차장', 16, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (184, 'polygonType_Code', 'PGR023', '휴게소/고속국도', 17, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (185, 'polygonType_Code', 'PGR024', '휴게소/일반국도', 18, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (186, 'polygonType_Code', 'PGR025', '휴게소/지방도', 19, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (187, 'polygonType_Code', 'PGR026', '졸음쉼터', 20, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (188, 'polygonTopology_Code', 'TPR001', '평면/단독', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (189, 'polygonTopology_Code', 'TPR002', '평면/포함함', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (190, 'polygonTopology_Code', 'TPR003', '평면/포함된', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (191, 'polygonTopology_Code', 'TPR004', '입체/지하', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (192, 'polygonTopology_Code', 'TPR005', '입체/공중', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (193, 'polygonTopology_Code', 'TPR006', '입체/다중', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (194, 'polygonMaterial_Code', 'RFM001', '아스팔트', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (195, 'polygonMaterial_Code', 'RFM002', '아스팔트콘크리트', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (196, 'polygonMaterial_Code', 'RFM003', '콘크리트', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (197, 'polygonMaterial_Code', 'RFM004', '강재', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (198, 'polygonMaterial_Code', 'RFM005', '목재', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (199, 'polygonMaterial_Code', 'RFM006', '석재', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (200, 'polygonMaterial_Code', 'RFM099', '해당없음', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (201, 'polygonMaterial_Code', 'RFM999', '기타', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (202, 'railroadDivision_Code', 'RRD001', '고속철도', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (203, 'railroadDivision_Code', 'RRD002', '보통철도', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (204, 'railroadDivision_Code', 'RRD003', '특수철도', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (205, 'railroadDivision_Code', 'RRD004', '지하철(지상)', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (206, 'railroadDivision_Code', 'RRD005', '삭도(케이블카)', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (207, 'railroadDivision_Code', 'RRD006', '모노레일', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (208, 'railroadDivision_Code', 'RRD999', '기타', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (209, 'railroadTrackType_Code', 'RRS001', '철도중심선', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (210, 'railroadTrackType_Code', 'RRS002', '선로', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (211, 'railFacilityKind_Code', 'RAF001', '철도정거장', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (212, 'railFacilityKind_Code', 'RAF002', '지하철역', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (213, 'railFacilityKind_Code', 'RAF003', '공용', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (214, 'railFacilityKind_Code', 'PLW001', '승강장', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (215, 'airportFacilityKind_Code', 'APF001', '공항시설', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (216, 'airportFacilityKind_Code', 'PAF002', '공항부속시설', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (217, 'airportFacilityKind_Code', 'PAF003', '계류장', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (218, 'airportFacilityKind_Code', 'POM001', '등대/항공', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (219, 'airportFacilityKind_Code', 'LAF001', '활주로', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (220, 'airportFacilityKind_Code', 'LAF002', '철책', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (221, 'portFacilityKind_Code', 'POM003', '등대/항해', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (222, 'portFacilityKind_Code', 'POM005', '등대/기타', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (223, 'portFacilityKind_Code', 'WTC001', '항구', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (224, 'portFacilityKind_Code', 'WTC002', '선착장', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (225, 'buildingUsage_Code', 'BDS001', '주거', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (226, 'buildingUsage_Code', 'BDS002', '근린생활시설', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (227, 'buildingUsage_Code', 'BDS003', '문화및집회시설', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (228, 'buildingUsage_Code', 'BDS004', '종교시설', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (229, 'buildingUsage_Code', 'BDS005', '판매시설', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (230, 'buildingUsage_Code', 'BDS006', '운수시설', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (231, 'buildingUsage_Code', 'BDS007', '의료시설', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (232, 'buildingUsage_Code', 'BDS008', '교육연구시설', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (233, 'buildingUsage_Code', 'BDS009', '노유자(노인및어린이)시설', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (234, 'buildingUsage_Code', 'BDS010', '수련시설', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (235, 'buildingUsage_Code', 'BDS011', '운동시설', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (236, 'buildingUsage_Code', 'BDS012', '업무시설', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (237, 'buildingUsage_Code', 'BDS013', '숙박시설', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (238, 'buildingUsage_Code', 'BDS014', '위락시설', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (239, 'buildingUsage_Code', 'BDS015', '공장', 15, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (240, 'buildingUsage_Code', 'BDS016', '창고시설', 16, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (37, 'kind_Code', 'ERF012', '복지단지', 26, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (38, 'kind_Code', 'ERF013', '수련원', 27, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (241, 'buildingUsage_Code', 'BDS017', '위험물저장및처리시설', 17, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (242, 'buildingUsage_Code', 'BDS018', '자동차관련시설', 18, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (243, 'buildingUsage_Code', 'BDS019', '동물및식물관련시설', 19, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (244, 'buildingUsage_Code', 'BDS020', '분뇨및쓰레기처리시설', 20, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (245, 'buildingUsage_Code', 'BDS021', '교정및군사시설', 21, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (246, 'buildingUsage_Code', 'BDS022', '방송통신시설', 22, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (247, 'buildingUsage_Code', 'BDS023', '발전시설', 23, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (248, 'buildingUsage_Code', 'BDS024', '묘지관련시설', 24, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (249, 'buildingUsage_Code', 'BDS025', '관광휴게시설', 25, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (250, 'buildingUsage_Code', 'BDS026', '장례시설', 26, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (251, 'buildingUsage_Code', 'BDS999', '기타시설', 27, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (252, 'buildingDivision_Code', 'BDK001', '일반주택', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (253, 'buildingDivision_Code', 'BDK002', '연립주택', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (254, 'buildingDivision_Code', 'BDK003', '아파트', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (255, 'buildingDivision_Code', 'BDK004', '주택외건물', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (256, 'buildingDivision_Code', 'BDK005', '무벽건물', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (257, 'buildingDivision_Code', 'BDK006', '온실', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (258, 'buildingDivision_Code', 'BDK007', '공사중건물', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (259, 'buildingDivision_Code', 'BDK008', '가건물', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (260, 'attachmentDivision_Code', 'BDF001', '담장', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (261, 'attachmentDivision_Code', 'BDF002', '문주', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (262, 'polygonStructureDivision_Code', 'PDD001', '유원지시설', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (263, 'polygonStructureDivision_Code', 'PDD002', '동물원시설', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (264, 'polygonStructureDivision_Code', 'PDD003', '식물원시설', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (265, 'polygonStructureDivision_Code', 'PDD004', '옥외수영장시설', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (266, 'polygonStructureDivision_Code', 'PDD005', '골프장/골프연습장시설', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (267, 'polygonStructureDivision_Code', 'PDD006', '스키장시설', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (268, 'polygonStructureDivision_Code', 'PDD007', '테니스장시설', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (269, 'polygonStructureDivision_Code', 'PDD008', '어린이놀이터시설', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (270, 'polygonStructureDivision_Code', 'PDD009', '운동장시설', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (271, 'polygonStructureDivision_Code', 'PDD010', '번지점프장시설', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (272, 'polygonStructureDivision_Code', 'PDD011', '경륜장시설', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (273, 'polygonStructureDivision_Code', 'PDD012', '수련원시설', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (274, 'polygonStructureDivision_Code', 'PDD014', '공원시설', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (275, 'polygonStructureDivision_Code', 'PDD900', '분수대', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (276, 'polygonStructureDivision_Code', 'PDD999', '기타놀이시설', 15, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (277, 'polygonStructureDivision_Code', 'SRD001', '계단', 16, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (278, 'polygonStructureDivision_Code', 'SRD002', '스탠드', 17, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (279, 'polygonStructureDivision_Code', 'STD001', '저수조', 18, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (280, 'polygonStructureDivision_Code', 'STD002', '저유조', 19, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (281, 'polygonStructureDivision_Code', 'STD999', '기타저장소', 20, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (282, 'lineStructureDivision_Code', 'CST001', '성(성벽)', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (283, 'lineStructureDivision_Code', 'UPS001', '지하도입구', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (284, 'lineStructureDivision_Code', 'UPE001', '지하주차장입구', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (285, 'lineStructureDivision_Code', 'BDP999', '기타구조물', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (286, 'pointStructureDivision_Code', 'WET001', '우물/약수터', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (287, 'pointStructureDivision_Code', 'WET004', '온천시설', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (288, 'pointStructureDivision_Code', 'WET006', '낚시터', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (289, 'pointStructureDivision_Code', 'MNS000', '광산(미분류)', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (290, 'pointStructureDivision_Code', 'MNS001', '광산(운영중)', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (291, 'pointStructureDivision_Code', 'MNS002', '광산(폐쇄)', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (292, 'pointStructureDivision_Code', 'PPD000', '채취장(미분류)', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (293, 'pointStructureDivision_Code', 'PPD001', '채취장(채석장)', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (294, 'pointStructureDivision_Code', 'PPD002', '채취장(토취장)', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (295, 'pointStructureDivision_Code', 'OSD000', '관측소(미분류)', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (296, 'pointStructureDivision_Code', 'OSD001', '관측소(수위)', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (297, 'pointStructureDivision_Code', 'OSD002', '관측소(유량)', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (298, 'pointStructureDivision_Code', 'OSD003', '관측소(수질)', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (299, 'pointStructureDivision_Code', 'OSD004', '관측소(풍향/풍속)', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (300, 'pointStructureDivision_Code', 'OSD005', '관측소(대기오염)', 15, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (301, 'pointStructureDivision_Code', 'OSD006', '관측소(파랑)', 16, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (302, 'pointStructureDivision_Code', 'OSD007', '관측소(지질)', 17, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (303, 'pointStructureDivision_Code', 'OSD008', '관측소(지진)', 18, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (304, 'pointStructureDivision_Code', 'CAT000', '문화재(미분류)', 19, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (305, 'pointStructureDivision_Code', 'CAT001', '문화재(비/탑/각)', 20, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (306, 'pointStructureDivision_Code', 'CAT002', '문화재(정자)', 21, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (307, 'pointStructureDivision_Code', 'CAT003', '문화재(암자)', 22, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (308, 'pointStructureDivision_Code', 'CAT004', '문화재(절)', 23, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (336, 'lineTopoDivision_Code', 'LTG004', '절토하단', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (337, 'lineTopoDivision_Code', 'LTG005', '옹벽상단', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (2, 'administrativeDistrictDivision_Code', 'HJD002', '광역시', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (3, 'administrativeDistrictDivision_Code', 'HJD003', '도', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (4, 'administrativeDistrictDivision_Code', 'HJD004', '특별자치도', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (5, 'administrativeDistrictDivision_Code', 'HJD005', '특별자치시', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (39, 'kind_Code', 'ERF014', '기숙학원', 28, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (40, 'kind_Code', 'ERF015', '기타교육연구단지', 29, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (41, 'kind_Code', 'TRF001', '공항시설', 30, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (42, 'kind_Code', 'TRF002', '항만시설', 31, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (43, 'kind_Code', 'TRF003', '철도시설', 32, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (44, 'kind_Code', 'TRF004', '버스터미널', 33, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (45, 'kind_Code', 'TRF005', '자동차정비수리소', 34, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (46, 'kind_Code', 'TRF006', '물류창고', 35, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (47, 'kind_Code', 'TRF007', '기타교통단지', 36, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (48, 'kind_Code', 'OSF001', '경기장', 37, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (50, 'kind_Code', 'OSF003', '기념관', 39, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (51, 'kind_Code', 'OSF004', '미술관', 40, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (52, 'kind_Code', 'OSF005', '박물관', 41, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (53, 'kind_Code', 'OSF006', '수족관', 42, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (54, 'kind_Code', 'OSF007', '식물원', 43, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (55, 'kind_Code', 'OSF008', '동물원', 44, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (56, 'kind_Code', 'OSF009', '기타관람및전시장', 45, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (57, 'kind_Code', 'CMF001', '예식장', 46, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (58, 'kind_Code', 'CMF002', '대형음식점', 47, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (59, 'kind_Code', 'CMF003', '기타근린상업시설', 48, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (60, 'kind_Code', 'ACF001', '호텔', 49, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (61, 'kind_Code', 'ACF002', '휴양콘도미니엄', 50, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (62, 'kind_Code', 'ACF003', '유스호스텔', 51, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (63, 'kind_Code', 'ACF004', '기타숙박시설', 52, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (64, 'kind_Code', 'LSF001', '골프장', 53, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (65, 'kind_Code', 'LSF002', '골프연습장', 54, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (66, 'kind_Code', 'LSF003', '리조트', 55, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (67, 'kind_Code', 'LSF004', '스키장', 56, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (68, 'kind_Code', 'LSF005', '야영장', 57, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (69, 'kind_Code', 'LSF006', '수영장', 58, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (309, 'pointStructureDivision_Code', 'CAT005', '문화재(절터)', 24, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (310, 'pointStructureDivision_Code', 'CAT006', '문화재(능)', 25, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (311, 'pointStructureDivision_Code', 'CAT007', '문화재(봉화대)', 26, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (312, 'pointStructureDivision_Code', 'CAT008', '문화재(유적지)', 27, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (313, 'pointStructureDivision_Code', 'TWD000', '탑(미분류)', 28, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (314, 'pointStructureDivision_Code', 'TWD001', '탑(소방탑)', 29, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (315, 'pointStructureDivision_Code', 'TWD002', '탑(저수탑)', 30, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (316, 'pointStructureDivision_Code', 'TWD003', '탑(취수탑)', 31, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (317, 'pointStructureDivision_Code', 'TWD004', '탑(전파탑)', 32, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (318, 'pointStructureDivision_Code', 'TWD005', '탑(송전탑)', 33, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (319, 'pointStructureDivision_Code', 'TWD006', '탑(시계탑)', 34, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (320, 'pointStructureDivision_Code', 'TWD007', '탑(송수신탑)', 35, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (321, 'pointStructureDivision_Code', 'TWD008', '탑(전망대)', 36, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (322, 'pointStructureDivision_Code', 'TWD009', '탑(감시탑)', 37, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (323, 'pointStructureDivision_Code', 'VTS002', '헬기장', 38, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (324, 'pointStructureDivision_Code', 'IUD006', '요금징수소', 39, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (325, 'contourDivision_Code', 'CTD001', '계곡선', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (326, 'contourDivision_Code', 'CTD002', '주곡선', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (327, 'contourDivision_Code', 'CTD003', '간곡선', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (328, 'contourDivision_Code', 'CTD004', '조곡선', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (329, 'topographyDivision_Code', 'TOP001', '볼록지', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (330, 'topographyDivision_Code', 'TOP002', '오목지', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (331, 'pointTopoDivision_Code', 'PGT001', '폭포', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (332, 'pointTopoDivision_Code', 'PGT002', '동굴입구', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (333, 'lineTopoDivision_Code', 'LTG001', '성토상단', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (334, 'lineTopoDivision_Code', 'LTG002', '성토하단', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (335, 'lineTopoDivision_Code', 'LTG003', '절토상단', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (6, 'administrativeDistrictDivision_Code', 'HJD006', '시', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (7, 'administrativeDistrictDivision_Code', 'HJD007', '군', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (8, 'administrativeDistrictDivision_Code', 'HJD008', '구', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (9, 'administrativeDistrictDivision_Code', 'HJD009', '읍', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (10, 'administrativeDistrictDivision_Code', 'HJD010', '면', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (11, 'administrativeDistrictDivision_Code', 'HJD011', '법정동', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (12, 'kind_Code', 'NTF001', '중앙행정기관(부)', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (13, 'kind_Code', 'NTF002', '중앙행정기관(처)', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (14, 'kind_Code', 'NTF003', '중앙행정기관(청)', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (15, 'kind_Code', 'NTF004', '중앙행정기관(소속기관)', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (16, 'kind_Code', 'NTF005', '중앙행정기관(기타)', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (17, 'kind_Code', 'NPF001', '자치단체청사', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (18, 'kind_Code', 'NPF002', '주민자치센타', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (19, 'kind_Code', 'NPF003', '기타근린공공시설', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (20, 'kind_Code', 'POF001', '소방서', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (21, 'kind_Code', 'POF002', '경찰서', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (22, 'kind_Code', 'PSF001', '분뇨 및 쓰레기 처리시설', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (23, 'kind_Code', 'PSF002', '정부투자기관', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (24, 'kind_Code', 'PSF003', '마을회관', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (25, 'kind_Code', 'PSF004', '기타공공단지', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (26, 'kind_Code', 'ERF001', '대학교', 15, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (27, 'kind_Code', 'ERF002', '고등학교', 16, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (28, 'kind_Code', 'ERF003', '중학교', 17, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (29, 'kind_Code', 'ERF004', '초등학교', 18, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (30, 'kind_Code', 'ERF005', '맹학교', 19, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (31, 'kind_Code', 'ERF006', '특수학교', 20, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (32, 'kind_Code', 'ERF007', '기타학교', 21, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (33, 'kind_Code', 'ERF008', '유치원', 22, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (34, 'kind_Code', 'ERF009', '어린이집', 23, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (35, 'kind_Code', 'ERF010', '도서관', 24, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (36, 'kind_Code', 'ERF011', '연구단지', 25, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (162, 'roadFacilityKind_Code', 'PGR999', '기타', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (338, 'lineTopoDivision_Code', 'LTG006', '옹벽하단', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (339, 'lineTopoDivision_Code', 'LTG007', '석축상단', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (340, 'lineTopoDivision_Code', 'LTG008', '석축하단', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (341, 'lineTopoDivision_Code', 'LTG009', '벼랑바위', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (342, 'lineTopoDivision_Code', 'LTG010', '너덜바위', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (343, 'polygonTopoDivision_Code', 'WPT001', '모래', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (344, 'polygonTopoDivision_Code', 'WPT002', '습지', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (345, 'polygonTopoDivision_Code', 'WPT003', '염전', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (346, 'polygonTopoDivision_Code', 'WPT004', '갯벌', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (347, 'coastlineDivision_Code', 'CLD001', '육지', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (348, 'coastlineDivision_Code', 'CLD002', '섬', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (349, 'riverDivision_Code', 'RCD001', '국가하천', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (350, 'riverDivision_Code', 'RCD002', '지방하천', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (351, 'riverDivision_Code', 'RCD003', '소하천', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (352, 'riverDivision_Code', 'RCD004', '기타하천', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (353, 'riverDivision_Code', 'RCD005', '세류', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (354, 'waterwayDivision_Code', 'WWF001', '제방상단', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (355, 'waterwayDivision_Code', 'WWF002', '제방하단', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (356, 'waterwayDivision_Code', 'WWF003', '방조제상단', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (357, 'waterwayDivision_Code', 'WWF004', '방조제하단', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (358, 'waterwayDivision_Code', 'WWF005', '방파제상단', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (359, 'waterwayDivision_Code', 'WWF006', '방파제하단', 6, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (360, 'waterwayDivision_Code', 'WWF007', '소파블럭', 7, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (361, 'waterwayDivision_Code', 'WWF008', '공업용수로', 8, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (362, 'waterwayDivision_Code', 'WWF009', '농업용수로', 9, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (363, 'waterwayDivision_Code', 'WWF010', '수문', 10, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (364, 'waterwayDivision_Code', 'WWF011', '배수갑문', 11, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (365, 'waterwayDivision_Code', 'WWF012', '보', 12, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (366, 'waterwayDivision_Code', 'WWF013', '암거', 13, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (367, 'waterwayDivision_Code', 'WWF014', '측구', 14, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (368, 'waterwayDivision_Code', 'WWF015', '잔교', 15, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (369, 'vegetationDivision_Code', 'FLD001', '논', 1, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (370, 'vegetationDivision_Code', 'FLD002', '밭', 2, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (371, 'vegetationDivision_Code', 'FLD003', '과수원', 3, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (372, 'vegetationDivision_Code', 'FLD004', '목초지', 4, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (373, 'vegetationDivision_Code', 'FLD005', '산지', 5, '2018-04-08 22:36:49.016339', 'Y');
INSERT INTO std_codezip (seq_no, codezip_id, code, code_nm, code_order, crt_dt, use_yn) VALUES (374, 'administrativeDistrictDivision_Code', 'HJD001', '특별시', 1, '2018-04-08 22:36:49.016339', 'Y');


--
-- TOC entry 5757 (class 0 OID 0)
-- Dependencies: 557
-- Name: std_codezip_seq_no_seq; Type: SEQUENCE SET; Schema: qiresult; Owner: ngii
--

SELECT pg_catalog.setval('std_codezip_seq_no_seq', 374, true);


--
-- TOC entry 5749 (class 0 OID 184956)
-- Dependencies: 559
-- Data for Name: std_layer; Type: TABLE DATA; Schema: qiresult; Owner: ngii
--

INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_CTPRVN_BNDRY', '시도구역경계', 'ARB_SiDoAreaBoundary', '구역경계', 3, 'Y', '2018-04-08 22:36:30.105094', 'ARB01000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_SIGNGU_BNDRY', '시군구구역경계', 'ARB_SiGunGuAreaBoundary', '구역경계', 3, 'Y', '2018-04-08 22:36:30.105094', 'ARB02000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_EMD_BNDRY', '읍면동구역경계', 'ARB_EupMyeonDongAreaBoundary', '구역경계', 3, 'Y', '2018-04-08 22:36:30.105094', 'ARB03000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_FCLTY_ZONE_BNDRY', '시설구역경계', 'ARB_FacilityAreaBoundary', '구역경계', 3, 'Y', '2018-04-08 22:36:30.105094', 'ARB04000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RODWAY_CTLN', '차도중심선', 'TRN_RoadwayCenterLine', '교통시설', 2, 'Y', '2018-04-08 22:36:30.105094', 'TRN01000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RODWAY_BNDRY', '차도경계면', 'TRN_RoadwayArea', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN02000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_FTPTH_CTLN', '보도중심선', 'TRN_SidewalkCenterline', '교통시설', 2, 'Y', '2018-04-08 22:36:30.105094', 'TRN03000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_FTPTH_BNDRY', '보도경계면', 'TRN_SidewalkArea', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN04000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_BCYCL_CTLN', '자전거도로중심선', 'TRN_BikewayCenterline', '교통시설', 2, 'Y', '2018-04-08 22:36:30.105094', 'TRN05000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ARRFC', '면형도로시설', 'TRN_PolygonRoadFacility', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN06000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_LNRFC', '선형도로시설', 'TRN_LineRoadFacility', '교통시설', 2, 'Y', '2018-04-08 22:36:30.105094', 'TRN07000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_PTRFC', '점형도로시설', 'TRN_PointRoadFacility', '교통시설', 1, 'Y', '2018-04-08 22:36:30.105094', 'TRN08000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RLROAD_CTLN', '철도중심선', 'TRN_RailroadCenterline', '교통시설', 2, 'Y', '2018-04-08 22:36:30.105094', 'TRN09000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RLROAD_BNDRY', '철도경계면', 'TRN_RailroadArea', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN10000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ARWFC', '면형철도시설', 'TRN_PolygonRailFacility', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN11000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_PTWFC', '점형철도시설', 'TRN_PointRailFacility', '교통시설', 1, 'Y', '2018-04-08 22:36:30.105094', 'TRN12000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ARAFC', '면형공항시설', 'TRN_PolygonAirportFacility', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN13000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_LNAFC', '선형공항시설', 'TRN_LineAirportFacility', '교통시설', 2, 'Y', '2018-04-08 22:36:30.105094', 'TRN14000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_PTAFC', '점형공항시설', 'TRN_PointAirportFacility', '교통시설', 1, 'Y', '2018-04-08 22:36:30.105094', 'TRN15000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ARHFC', '면형항만시설', 'TRN_PolygonPortFacility', '교통시설', 3, 'Y', '2018-04-08 22:36:30.105094', 'TRN16000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_PTHFC', '점형항만시설', 'TRN_PointPortFacility', '교통시설', 1, 'Y', '2018-04-08 22:36:30.105094', 'TRN17000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_BULD', '건물', 'BLD_Building', '건축구조물', 3, 'Y', '2018-04-08 22:36:30.105094', 'BLD01000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_BULD_ADCLS', '건물부속시설', 'BLD_BuildingAttachment', '건축구조물', 2, 'Y', '2018-04-08 22:36:30.105094', 'BLD02000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ARSFC', '면형구조시설', 'BLD_PolygonStructure', '건축구조물', 3, 'Y', '2018-04-08 22:36:30.105094', 'BLD03000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_LNSFC', '선형구조시설', 'BLD_LineStructure', '건축구조물', 2, 'Y', '2018-04-08 22:36:30.105094', 'BLD04000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_PTSFC', '점형구조시설', 'BLD_PointStructure', '건축구조물', 1, 'Y', '2018-04-08 22:36:30.105094', 'BLD05000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_CTRLN', '등고선', 'TPG_Contour', '지형', 2, 'Y', '2018-04-08 22:36:30.105094', 'TPG01000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_SHORLINE', '해안선', 'TPG_Coastline', '지형', 2, 'Y', '2018-04-08 22:36:30.105094', 'TPG02000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ALPT', '표고점', 'TPG_ElevationPoint', '지형', 1, 'Y', '2018-04-08 22:36:30.105094', 'TPG03000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_PTPGR', '점형지형', 'TPG_PointTopography', '지형', 1, 'Y', '2018-04-08 22:36:30.105094', 'TPG06000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_LNPGR', '선형지형', 'TPG_LineTopography', '지형', 2, 'Y', '2018-04-08 22:36:30.105094', 'TPG05000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_ARPGR', '면형지형', 'TPG_PolygonTopography', '지형', 3, 'Y', '2018-04-08 22:36:30.105094', 'TPG04000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RIVER_BNDRY', '하천경계', 'WTR_RiverArea', '수계', 3, 'Y', '2018-04-08 22:36:30.105094', 'WTR01000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RIVER_BT', '실폭하천', 'WTR_ActualRiver', '수계', 3, 'Y', '2018-04-08 22:36:30.105094', 'WTR02000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_RIVER_CTLN', '하천중심선', 'WTR_RiverCenterline', '수계', 2, 'Y', '2018-04-08 22:36:30.105094', 'WTR03000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_LKMH', '호소', 'WTR_Lake', '수계', 3, 'Y', '2018-04-08 22:36:30.105094', 'WTR04000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_WTCORS_FCLTY', '수로시설', 'WTR_WaterwayFacility', '수계', 2, 'Y', '2018-04-08 22:36:30.105094', 'WTR05000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_FMLND_BNDRY', '경지경계', 'VGT_ArableLandAreaBoundary', '식생', 3, 'Y', '2018-04-08 22:36:30.105094', 'VGT01000');
INSERT INTO std_layer (layer_id, layer_nm, std_layer_id, layer_package, geom_type, use_yn, crt_dt, layer_cd) VALUES ('TN_MTC_BNDRY', '산지경계', 'VGT_ForestAreaBoundary', '식생', 3, 'Y', '2018-04-08 22:36:30.105094', 'VGT02000');


--
-- TOC entry 5751 (class 0 OID 185105)
-- Dependencies: 567
-- Data for Name: std_struct; Type: TABLE DATA; Schema: qiresult; Owner: ngii
--

INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (9, 'TN_CTPRVN_BNDRY', 'ADZONE_SE', '행정구역 구분', 4, 'administrativeDistrictDivision', 'VC', 6, NULL, 1, 'administrativeDistrictDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (10, 'TN_SIGNGU_BNDRY', 'ADZONE_SE', '행정구역 구분', 4, 'administrativeDistrictDivision', 'VC', 6, NULL, 1, 'administrativeDistrictDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (11, 'TN_EMD_BNDRY', 'ADZONE_SE', '행정구역 구분', 4, 'administrativeDistrictDivision', 'VC', 6, NULL, 1, 'administrativeDistrictDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (12, 'TN_FCLTY_ZONE_BNDRY', 'FZONBN_SE', '시설구역경계 구분', 3, 'kind', 'VC', 6, NULL, 1, 'kind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (13, 'TN_RODWAY_CTLN', 'ROAD_SE', '도로 구분', 5, 'roadDivision', 'VC', 6, NULL, 1, 'roadDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (14, 'TN_RODWAY_CTLN', 'OSPS_SE', '일방통행 구분', 10, 'onewayInfo', 'VC', 6, NULL, 1, 'onewayInfo_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (15, 'TN_RODWAY_CTLN', 'MTRWY_SE', '자동차전용도로 구분', 11, 'motorwayInfo', 'VC', 6, NULL, 1, 'motorwayInfo_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (16, 'TN_FTPTH_CTLN', 'PMTR_SE', '포장재질 구분', 2, 'pavementMaterial', 'VC', 6, NULL, 1, 'pavementMaterial_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (17, 'TN_CTPRVN_BNDRY', 'ADZONE_NM', '행정구역 명칭', 2, 'administrativeName', 'VC', 100, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (18, 'TN_CTPRVN_BNDRY', 'LEGLCD_SE', '법정동코드 구분', 3, 'legalDongCode', 'VC', 10, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (19, 'TN_SIGNGU_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (20, 'TN_SIGNGU_BNDRY', 'ADZONE_NM', '행정구역 명칭', 2, 'administrativeName', 'VC', 100, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (21, 'TN_SIGNGU_BNDRY', 'LEGLCD_SE', '법정동코드 구분', 3, 'legalDongCode', 'VC', 10, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (22, 'TN_EMD_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (23, 'TN_EMD_BNDRY', 'ADZONE_NM', '행정구역 명칭', 2, 'administrativeName', 'VC', 100, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (24, 'TN_EMD_BNDRY', 'LEGLCD_SE', '법정동코드 구분', 3, 'legalDongCode', 'VC', 10, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (25, 'TN_FCLTY_ZONE_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (26, 'TN_FCLTY_ZONE_BNDRY', 'FZON_NM', '시설구역 명칭', 2, 'administrativeName', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (27, 'TN_RODWAY_CTLN', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (28, 'TN_RODWAY_CTLN', 'MOLIT_UFID', '국토부 UFID', 2, 'molitufid', 'VC', 17, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (29, 'TN_RODWAY_CTLN', 'ROAD_NO', '도로 번호', 3, 'roadNumber', 'VC', 30, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (30, 'TN_RODWAY_CTLN', 'ROAD_NM', '도로 명칭', 4, 'roadName', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (31, 'TN_RODWAY_CTLN', 'PMTR_SE', '포장재질 구분', 6, 'pavementMaterial', 'VC', 6, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (32, 'TN_RODWAY_CTLN', 'EDENNC_AT', '분리대유무 여부', 7, 'medianStripExist', 'VC', 6, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (33, 'TN_RODWAY_CTLN', 'CARTRK_CO', '차로 수', 8, 'laneNumber', 'N', 2, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (34, 'TN_RODWAY_CTLN', 'ROAD_BT', '도로 폭', 9, 'roadWidth', 'N', 5, 2, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (35, 'TN_RODWAY_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (36, 'TN_FTPTH_CTLN', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (37, 'TN_FTPTH_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (38, 'TN_BCYCL_CTLN', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (39, 'TN_BCYCL_CTLN', 'PMTR_SE', '포장재질 구분', 3, 'pavementMaterial', 'VC', 6, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (40, 'TN_ARRFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (41, 'TN_ARRFC', 'ARRFC_NM', '면형도로시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (42, 'TN_LNRFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (43, 'TN_PTRFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (44, 'TN_PTRFC', 'PTRFC_NM', '점형도로시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (45, 'TN_RLROAD_CTLN', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (46, 'TN_RLROAD_CTLN', 'RLWAY_NM', '철도선로 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (47, 'TN_ARWFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (48, 'TN_BCYCL_CTLN', 'BCYKND_SE', '자전거도로종류 구분', 2, 'bikewayKind', 'VC', 6, NULL, 1, 'bikewayKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (49, 'TN_ARRFC', 'ARRFCKD_SE', '면형도로시설종류 구분', 3, 'facilityKind', 'VC', 6, NULL, 0, 'roadFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (50, 'TN_ARRFC', 'ARTFCTY_SE', '면형교통시설유형 구분', 4, 'polygonType', 'VC', 6, NULL, 0, 'polygonType_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (51, 'TN_ARRFC', 'ARRFCPH_SE', '면형도로시설위상관계 구분', 5, 'polygonTopology', 'VC', 6, NULL, 1, 'polygonTopology_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (52, 'TN_ARRFC', 'ARRFCMT_SE', '면형도로시설재질 구분', 6, 'polygonMaterial', 'VC', 6, NULL, 1, 'polygonMaterial_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (53, 'TN_LNRFC', 'LNRFCKD_SE', '선형도로시설종류 구분', 2, 'facilityKind', 'VC', 6, NULL, 1, 'roadFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (54, 'TN_LNRFC', 'LNRFCST_SE', '선형도로시설구조 구분', 3, 'lineStructure', 'VC', 6, NULL, 1, 'lineStructure_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (55, 'TN_PTRFC', 'PTRFCKD_SE', '점형도로시설종류 구분', 3, 'facilityKind', 'VC', 6, NULL, 1, 'roadFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (56, 'TN_RLROAD_CTLN', 'RLROAD_SE', '철도 구분', 3, 'railroadDivision', 'VC', 6, NULL, 1, 'railroadDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (57, 'TN_RLROAD_CTLN', 'RLWTY_SE', '철도선로유형 구분', 4, 'railroadTrackType', 'VC', 6, NULL, 1, 'railroadTrackType_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (58, 'TN_ARWFC', 'ARWFC_NM', '면형철도시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (59, 'TN_PTWFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (60, 'TN_PTWFC', 'PTWFC_NM', '점형철도시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (61, 'TN_ARAFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (62, 'TN_ARAFC', 'ARAFC_NM', '면형공항시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (63, 'TN_LNAFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (64, 'TN_PTAFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (65, 'TN_PTAFC', 'PTAFC_NM', '점형공항시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (66, 'TN_ARHFC', 'ARHFC_NM', '면형항만시설명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (67, 'TN_PTHFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (68, 'TN_PTHFC', 'PTHFC_NM', '점형항만시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (69, 'TN_BULD', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (1, 'TN_RODWAY_BNDRY', 'REFNF_ID', '참조고유식별자 아이디', 2, 'refnfid', 'VC', 17, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (2, 'TN_ARWFC', 'ARWFCKD_SE', '면형철도시설종류 구분', 3, 'facilityKind', 'VC', 6, NULL, 1, 'railFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (3, 'TN_PTWFC', 'PTWFCKD_SE', '점형철도시설종류 구분', 3, 'facilityKind', 'VC', 6, NULL, 1, 'railFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (4, 'TN_CTPRVN_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (5, 'TN_ARAFC', 'ARAFCKD_SE', '면형공항시설종류 구분', 3, 'facilityKind', 'VC', 6, NULL, 1, 'airportFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (6, 'TN_BULD_ADCLS', 'ADCLS_SE', '부속시설 구분', 2, 'attachmentDivision', 'VC', 6, NULL, 1, 'attachmentDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (7, 'TN_ARPGR', 'ARPGR_SE', '면형지형 구분', 3, 'division', 'VC', 6, NULL, 1, 'polygonTopoDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (8, 'TN_BULD', 'BULD_NM', '건물 명칭', 4, 'name', 'VC', 200, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (70, 'TN_BULD', 'MOLIT_UFID', '국토부 UFID', 2, 'molitufid', 'VC', 17, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (71, 'TN_BULD', 'BATC_NM', '건물부속 명칭', 5, 'name2', 'VC', 200, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (72, 'TN_BULD', 'BFLR_CO', '건물층 수', 7, 'story', 'N', 3, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (73, 'TN_BULD', 'PNU_NO', 'PNU 번호', 8, 'parcelNumberUnit', 'VC', 19, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (74, 'TN_BULD', 'USECON_DE', '사용승인 일', 9, 'useApprovedDate', 'VC', 8, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (75, 'TN_BULD', 'RNCODE_DC', '도로명코드 설명', 10, 'roadNameCode', 'VC', 7, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (93, 'TN_PTPGR', 'PTPGR_NM', '점형지형 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (94, 'TN_LNPGR', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (95, 'TN_LNPGR', 'LNPGR_LT', '선형지형 길이', 3, 'length', 'N', 6, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (96, 'TN_LNPGR', 'LNPGR_HG', '선형지형 높이', 4, 'height', 'N', 5, 2, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (97, 'TN_ARPGR', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (98, 'TN_ARPGR', 'ARPGR_NM', '면형지형 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (99, 'TN_RIVER_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (100, 'TN_RIVER_BT', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (101, 'TN_RIVER_CTLN', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (102, 'TN_RIVER_CTLN', 'RIVER_NO', '하천 번호', 2, 'number', 'VC', 9, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (103, 'TN_RIVER_CTLN', 'RIVER_NM', '하천 명칭', 3, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (104, 'TN_LNAFC', 'LNAFCKD_SE', '선형공항시설종류 구분', 2, 'facilityKind', 'VC', 6, NULL, 1, 'airportFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (105, 'TN_PTAFC', 'PTAFCKD_SE', '점형공항시설종류 분류', 3, 'facilityKind', 'VC', 6, NULL, 1, 'airportFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (106, 'TN_ARHFC', 'ARHFCKD_SE', '면형항만시설종류', 3, 'facilityKind', 'VC', 6, NULL, 1, 'portFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (107, 'TN_PTHFC', 'PTHFCKD_SE', '점형항만시설종류 구분', 3, 'facilityKind', 'VC', 6, NULL, 1, 'portFacilityKind_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (108, 'TN_BULD', 'BPRP_SE', '건물용도 구분', 3, 'buildingUsage', 'VC', 6, NULL, 1, 'buildingUsage_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (109, 'TN_BULD', 'BULD_SE', '건물 구분', 6, 'buildingDivision', 'VC', 6, NULL, 1, 'buildingDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (110, 'TN_CTRLN', 'CTRLN_SE', '등고선 구분', 2, 'division', 'VC', 6, NULL, 1, 'contourDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (111, 'TN_CTRLN', 'TPGRPH_SE', '지형 구분', 3, 'topographyDivision', 'VC', 6, NULL, 1, 'topographyDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (112, 'TN_SHORLINE', 'SHORLNE_SE', '해안선 구분', 2, 'division', 'VC', 6, NULL, 1, 'coastlineDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (113, 'TN_PTPGR', 'PTPGR_SE', '점형지형 구분', 3, 'division', 'VC', 6, NULL, 1, 'pointTopoDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (114, 'TN_LNPGR', 'LNPGR_SE', '선형지형 구분', 2, 'division', 'VC', 100, NULL, 1, 'lineTopoDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (115, 'TN_LKMH', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (116, 'TN_LKMH', 'LKMH_NM', '호소 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (117, 'TN_WTCORS_FCLTY', 'NF_ID', '고유식별자 아이디', 1, 'ufid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (118, 'TN_WTCORS_FCLTY', 'WTCORFC_NM', '수로시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (119, 'TN_FMLND_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (120, 'TN_MTC_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (121, 'TN_RLROAD_BNDRY', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (122, 'TN_ARHFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (123, 'TN_ALPT', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (124, 'TN_RIVER_CTLN', 'RIVER_SE', '하천 구분', 4, 'division', 'VC', 6, NULL, 1, 'riverDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (125, 'TN_WTCORS_FCLTY', 'WTCORFC_SE', '수로시설 구분', 3, 'division', 'VC', 6, NULL, 1, 'waterwayDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (126, 'TN_FMLND_BNDRY', 'VTN_SE', '식생 구분', 2, 'division', 'VC', 6, NULL, 1, 'vegetationDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (127, 'TN_MTC_BNDRY', 'VTN_SE', '식생 구분', 2, 'vegetationDivision', 'VC', 6, NULL, 1, 'vegetationDivision_Code', 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (76, 'TN_BULD', 'BLDMN_NO', '건물본번 번호', 11, 'buildingMainNumber', 'N', 4, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (77, 'TN_BULD', 'BLDSL_NO', '건물부번 번호', 12, 'buildingSubNumber', 'N', 4, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (78, 'TN_BULD_ADCLS', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (79, 'TN_ARSFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (80, 'TN_ARSFC', 'ARSFC_NM', '면형구조시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (81, 'TN_ARSFC', 'ARSFCKD_SE', '면형구조시설종류 구분', 3, 'polygonStructureDivision', 'VC', 6, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (82, 'TN_LNSFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (83, 'TN_LNSFC', 'LNSFC_NM', '선형구조시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (84, 'TN_LNSFC', 'LNSFCKD_SE', '선형구조시설종류 구분', 3, 'lineStructureDivision', 'VC', 6, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (85, 'TN_PTSFC', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (86, 'TN_PTSFC', 'PTSFC_NM', '점형구조시설 명칭', 2, 'name', 'VC', 100, NULL, 0, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (87, 'TN_PTSFC', 'PTSFCKD_SE', '점형구조시설종류 구분', 3, 'pointStructureDivision', 'VC', 6, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (88, 'TN_CTRLN', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (89, 'TN_CTRLN', 'CTRLN_HG', '등고선 높이', 4, 'value', 'N', 4, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (90, 'TN_SHORLINE', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (91, 'TN_ALPT', 'ALPT_HG', '표고점 높이', 2, 'value', 'N', 7, 2, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');
INSERT INTO std_struct (seq_no, layer_id, col_id, col_nm, col_order, std_col_id, col_type, col_length, col_preci, col_mandt, codezip_id, use_yn, crt_dt) VALUES (92, 'TN_PTPGR', 'NF_ID', '고유식별자 아이디', 1, 'nfid', 'VC', 17, NULL, 1, NULL, 'Y', '2018-04-08 22:37:01.93874');


--
-- TOC entry 5758 (class 0 OID 0)
-- Dependencies: 566
-- Name: std_struct_seq_no_seq; Type: SEQUENCE SET; Schema: qiresult; Owner: ngii
--

SELECT pg_catalog.setval('std_struct_seq_no_seq', 127, true);

--
-- Name: com_code PK_com_code; Type: CONSTRAINT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY com_code
    ADD CONSTRAINT "PK_com_code" PRIMARY KEY (code);


--
-- Name: CONSTRAINT "PK_com_code" ON com_code; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON CONSTRAINT "PK_com_code" ON com_code IS '공통코드 기본키';


--
-- Name: ins_standard PK_ins_standard; Type: CONSTRAINT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY ins_standard
    ADD CONSTRAINT "PK_ins_standard" PRIMARY KEY (seq_no);


--
-- Name: CONSTRAINT "PK_ins_standard" ON ins_standard; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON CONSTRAINT "PK_ins_standard" ON ins_standard IS '검사기준 기본키';


--
-- Name: std_codezip PK_std_codezip; Type: CONSTRAINT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY std_codezip
    ADD CONSTRAINT "PK_std_codezip" PRIMARY KEY (seq_no);


--
-- Name: CONSTRAINT "PK_std_codezip" ON std_codezip; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON CONSTRAINT "PK_std_codezip" ON std_codezip IS '표준코드집 기본키';


--
-- Name: std_layer PK_std_layer; Type: CONSTRAINT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY std_layer
    ADD CONSTRAINT "PK_std_layer" PRIMARY KEY (layer_id);


--
-- Name: CONSTRAINT "PK_std_layer" ON std_layer; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON CONSTRAINT "PK_std_layer" ON std_layer IS '표준레이어목록 기본키';


--
-- Name: std_struct PK_std_struct; Type: CONSTRAINT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY std_struct
    ADD CONSTRAINT "PK_std_struct" PRIMARY KEY (seq_no);


--
-- Name: CONSTRAINT "PK_std_struct" ON std_struct; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON CONSTRAINT "PK_std_struct" ON std_struct IS '표준레이어구조 기본키';


--
-- Name: ins_standard UK_ins_standard; Type: CONSTRAINT; Schema: qiresult; Owner: -
--

ALTER TABLE ONLY ins_standard
    ADD CONSTRAINT "UK_ins_standard" UNIQUE (t_code);


--
-- Name: CONSTRAINT "UK_ins_standard" ON ins_standard; Type: COMMENT; Schema: qiresult; Owner: -
--

COMMENT ON CONSTRAINT "UK_ins_standard" ON ins_standard IS '검사기준 유니크 제약';


--
-- Name: com_code_code_idx; Type: INDEX; Schema: qiresult; Owner: -
--

CREATE INDEX com_code_code_idx ON com_code USING btree (code DESC NULLS LAST);


--
-- PostgreSQL database dump complete
--


CREATE TABLE qiresult.ins_feature
(
  cid character varying(30) NOT NULL,
  nf_id character varying(17),
  layer_id character varying(50),
  mnent_nm character varying(100),
  updt_bsns_nm character varying(100),
  updt_bsns_yy character varying(4),
  updt_bsns_se character varying(6),
  obchg_dt timestamp without time zone,
  rsreg_dt timestamp without time zone,
  obchg_se character varying(6),
  ins_user_id character varying(20),
  ins_user_nm character varying(10),
  ins_str_dt timestamp without time zone,
  ins_end_dt timestamp without time zone,
  loins_se character varying(6) DEFAULT 'IVS003'::character varying,
  tiins_se character varying(6) DEFAULT 'IVS003'::character varying,
  thins_se character varying(6) DEFAULT 'IVS003'::character varying,
  inins_se character varying(6) DEFAULT 'IVS003'::character varying,
  lcins_se character varying(6) DEFAULT 'IVS003'::character varying,
  judge_se character varying(6) DEFAULT 'IVS001'::character varying,
  judge_dt timestamp without time zone,
  judge_user_id character varying(20),
  judge_user_nm character varying(10),
  ins_group_id character varying(40),
  updt_bsns_nm_sub character varying(200),
  error_nm character varying,
  error_dc character varying,
  CONSTRAINT "PK_ins_feature" PRIMARY KEY (cid)
);

COMMENT ON TABLE ins_feature IS '검사객체';
COMMENT ON COLUMN ins_feature.cid IS '변동정보ID';
COMMENT ON COLUMN ins_feature.nf_id IS '고유식별자ID';
COMMENT ON COLUMN ins_feature.layer_id IS '레이어ID';
COMMENT ON COLUMN ins_feature.mnent_nm IS '사업자명';
COMMENT ON COLUMN ins_feature.updt_bsns_nm IS '갱신사업명';
COMMENT ON COLUMN ins_feature.updt_bsns_yy IS '갱신사업년도';
COMMENT ON COLUMN ins_feature.updt_bsns_se IS '갱신사업구분';
COMMENT ON COLUMN ins_feature.obchg_dt IS '객체변동일자';
COMMENT ON COLUMN ins_feature.rsreg_dt IS '성과등록일자';
COMMENT ON COLUMN ins_feature.obchg_se IS '변동구분';
COMMENT ON COLUMN ins_feature.ins_user_id IS '검사자ID';
COMMENT ON COLUMN ins_feature.ins_user_nm IS '검사자명';
COMMENT ON COLUMN ins_feature.ins_str_dt IS '검사시작일자';
COMMENT ON COLUMN ins_feature.ins_end_dt IS '검사종료일자';
COMMENT ON COLUMN ins_feature.loins_se IS '논리일관성검사구분';
COMMENT ON COLUMN ins_feature.tiins_se IS '시간적품질검사구분';
COMMENT ON COLUMN ins_feature.thins_se IS '주제정확성검사구분';
COMMENT ON COLUMN ins_feature.inins_se IS '정보완전성검사구분';
COMMENT ON COLUMN ins_feature.lcins_se IS '위치정확성검사구분';
COMMENT ON COLUMN ins_feature.judge_se IS '판정결과';
COMMENT ON COLUMN ins_feature.judge_dt IS '판정일시';
COMMENT ON COLUMN ins_feature.judge_user_id IS '판정자ID';
COMMENT ON COLUMN ins_feature.judge_user_nm IS '판정자명';
COMMENT ON COLUMN ins_feature.ins_group_id IS '검사그룹';
COMMENT ON COLUMN ins_feature.updt_bsns_nm_sub IS '갱신사업건명';
COMMENT ON COLUMN ins_feature.error_nm IS '오류명칭';
COMMENT ON COLUMN ins_feature.error_dc IS '오류사유';

COMMENT ON CONSTRAINT "PK_ins_feature" ON ins_feature IS '검사객체 기본키';


CREATE TABLE res_feature
(
  cid character varying(30) NOT NULL,
  ins_t_code character varying(20) NOT NULL,
  obchg_se character varying(6),
  layer_id character varying(50),
  res_code character varying(6),
  CONSTRAINT "PK_res_feature" PRIMARY KEY (cid, ins_t_code)
);

COMMENT ON TABLE res_feature IS '객체검사결과 ';
COMMENT ON COLUMN res_feature.cid IS '변동정보ID';
COMMENT ON COLUMN res_feature.ins_t_code IS '검사유형코드';
COMMENT ON COLUMN res_feature.obchg_se IS '변동구분';
COMMENT ON COLUMN res_feature.layer_id IS '레이어ID';
COMMENT ON COLUMN res_feature.res_code IS '검사결과코드';

COMMENT ON CONSTRAINT "PK_res_feature" ON res_feature IS '객체검사결과  기본키';


CREATE TABLE res_feature_dlc
(
  seq_no serial ,
  cid character varying(30) NOT NULL,
  ins_t_code character varying(20) NOT NULL,
  ref_cid character varying,
  ref_nf_id character varying,
  ref_layer_id character varying(50),
  col_id character varying(30),
  col_val character varying(100),
  img character varying,
  img_tn character varying,
  min_x numeric(10,2),
  min_y numeric(10,2),
  max_x numeric(10,2),
  max_y numeric(10,2),
  img_nm character varying(50),
  res_code character varying(6),
  error_dc character varying,
  CONSTRAINT "PK_res_feature_log" PRIMARY KEY (seq_no)
);

COMMENT ON TABLE res_feature_dlc IS '검사오류내역_논리일관성';
COMMENT ON COLUMN res_feature_dlc.seq_no IS '순번';
COMMENT ON COLUMN res_feature_dlc.cid IS '변동정보ID';
COMMENT ON COLUMN res_feature_dlc.ins_t_code IS '검사유형코드';
COMMENT ON COLUMN res_feature_dlc.ref_cid IS '참조CID';
COMMENT ON COLUMN res_feature_dlc.ref_nf_id IS '참조NFID';
COMMENT ON COLUMN res_feature_dlc.ref_layer_id IS '참조레이어ID';
COMMENT ON COLUMN res_feature_dlc.col_id IS '컬럼ID';
COMMENT ON COLUMN res_feature_dlc.col_val IS '컬럼값';
COMMENT ON COLUMN res_feature_dlc.img IS '이미지';
COMMENT ON COLUMN res_feature_dlc.img_tn IS '썸네일이미지';
COMMENT ON COLUMN res_feature_dlc.min_x IS 'min_x';
COMMENT ON COLUMN res_feature_dlc.min_y IS 'min_y';
COMMENT ON COLUMN res_feature_dlc.max_x IS 'max_x';
COMMENT ON COLUMN res_feature_dlc.max_y IS 'max_y';
COMMENT ON COLUMN res_feature_dlc.img_nm IS '이미지파일명';
COMMENT ON COLUMN res_feature_dlc.res_code IS '검사결과코드';
COMMENT ON COLUMN res_feature_dlc.error_dc IS '오류사유';

COMMENT ON CONSTRAINT "PK_res_feature_log" ON res_feature_dlc IS '검사오류내역_논리일관성 기본키';


# -*- coding: utf-8 -*-
import os

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic

# class SelectInspectData(QDialog, Ui_SelectInspectData):
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/DbInfo.ui'))
class DbInfoDialog(QDialog, FORM_CLASS):

    inspectWidget = None
    __oldDataDir = None

    def __init__(self, parent=None):
        super(DbInfoDialog, self).__init__(parent)
        self.setupUi(self)
        self.parent = parent

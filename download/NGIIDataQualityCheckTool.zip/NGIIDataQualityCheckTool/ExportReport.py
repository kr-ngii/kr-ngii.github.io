# -*- coding: utf-8 -*-
import os
import subprocess
import platform

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import QgsApplication

from ui.ExportReport import Ui_ExportReport
from util.DBUtil import DBUtil
from util.RestapiUtil import RestAPIUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ExportReport(QDialog, Ui_ExportReport):

    reportPath = str()

    def __init__(self, iface, parent=None):
        super(ExportReport, self).__init__(parent)
        self.setupUi(self)

        self.logger = logger

        self.iface = iface
        self.parent = parent

        self.dbUtil = DBUtil()
        self.restapiUtil = RestAPIUtil()

        self.__connectFn()

    def __connectFn(self):
        self.btnOpenReport.clicked.connect(self.openReport)

    def saveReport(self):
        self.progress.setMinimum(0)
        self.progress.setMaximum(0)

        self.reportPath = os.path.join(QgsApplication.qgisSettingsDirPath(), "qi_result",
                                  self.dbUtil.INS_SCHEMA, "QIReport.pdf")

        inspectCidList = self.dbUtil.selectReportCid()

        reportRes = self.restapiUtil.saveReport(inspectCidList, self.reportPath)
        self.progress.setMinimum(1)
        self.progress.setMaximum(10)
        self.progress.setValue(10)

        if reportRes:
            self.txtStatus.setText(u"리포트 생성 완료")
            self.btnOpenReport.setDisabled(False)

    def openReport(self):
        if os.path.exists(self.reportPath):
            if platform.system() == 'Windows':
                os.startfile('{fileDir}'.format(fileDir=self.reportPath.encode('cp949')))
            else:
                subprocess.check_call(['open', self.reportPath])

        else:
            QMessageBox.warning(self.parent, u"리포트 오류", u"리포트 파일을 찾을 수 없습니다.\n{}".format(self.reportPath))

        self.close()

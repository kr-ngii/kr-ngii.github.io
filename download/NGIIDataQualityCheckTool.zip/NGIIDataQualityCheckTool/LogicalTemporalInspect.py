# -*- coding: utf-8 -*-
import os
import io

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic

from qgis.core import *
from qgis import utils

from osgeo import ogr

from ui.LogicalTemporalInspect import Ui_LogicalTemporalInspect
from logicalInspect.LogicalInspector import LogicalInspector
# from InspectProgress import InspectProgress

import logging.handlers
logger = logging.getLogger('ngiiPlugin')

# class SelectInspectData(QDialog, Ui_SelectInspectData):
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/LogicalTemporalInspect.ui'))


# class LogicalTemporalInspect(QDockWidget, Ui_LogicalTemporalInspect):
class LogicalTemporalInspect(QDockWidget, FORM_CLASS):

    STANDARD_SCHEMA = 'qiresult'

    tmpShape = None  # type: QgsVectorLayer

    inspectSchema = None
    imgSavePath = None
    standardLayerStructure = None
    inspectStd = None

    errImgLayer = None
    crrLayer = None
    refLayerList = list()

    def __init__(self, dock, qiData):
        super(LogicalTemporalInspect, self).__init__(dock.parent)
        self.setupUi(self)

        self.__initTree()

        self.logger = logger

        self.iface = dock.iface
        self.parent = dock.parent
        self.crrWidget = dock
        self.qiData = qiData

        self.plugin = utils.plugins['NGIIDataQualityCheckTool']

        self.logicalInspector = LogicalInspector(self)
        self.inspectSchema = self.logicalInspector.getSchema()
        self.imgSavePath = self.logicalInspector.getImgSavePath()

        self.__connectFn()
        self.setDefaultProject()

    def closeEvent(self, event):
        self.iface.removeDockWidget(self.crrWidget.inspectWidget)

    def __connectFn(self):
        self.btnThematicInspect.clicked.connect(self.inspectThematic)
        self.treeResult.doubleClicked.connect(self.loadImg)
        self.treeResult.clicked.connect(self.setFeatureInfo)
        self.btnExcept.clicked.connect(self.addException)

    def inspectThematic(self):
        self.crrWidget.showThematicInspect(opener='inspect')

    def __initTree(self):
        self.treeResult.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeResult.setHeaderHidden(True)
        self.treeModel = QStandardItemModel()
        self.treeModel.setColumnCount(1)

        self.treeResult.setModel(self.treeModel)

        self.txtFeatureId.setText("")
        self.txtErrContent.setText("")
        self.labelErrImg.setText("")
        self.txtStatus.setText(u"논리일관성 검사 시작중...")
        self.progressBar.setValue(0)
        self.progressBar.setMaximum(100)

    def keyReleaseEvent(self, QKeyEvent):
        curIdx = self.treeResult.currentIndex()
        if curIdx:
            self.setFeatureInfo(curIdx)

    def closeDB(self):
        self.logicalInspector.closeDB()

    def setDefaultProject(self):
        self.iface.newProject()
        self.iface.mapCanvas().setCanvasColor(Qt.black)

    def startInspect(self):
        self.setDefaultProject()

        self.checkStandard()
        # insert cids
        tableList = self.logicalInspector.dbUtil.selectTableList(self.inspectSchema)
        for layernm in tableList:
            self.logicalInspector.dbUtil.insertCid(self.inspectSchema, layernm)

        # 이미지 폴더 백업
        # imgPath = os.path.join(self.imgSavePath, self.inspectSchema)
        # if os.path.exists(imgPath):
        #     bakCount = 1
        #     while True:
        #         imgBakPath = os.path.join(self.imgSavePath, "{}_bak_{}".format(self.inspectSchema, bakCount))
        #         if not os.path.exists(imgBakPath):
        #             os.rename(imgPath, imgBakPath)
        #             break
        #
        #         bakCount += 1

        layerList = self.logicalInspector.selectTableList(self.inspectSchema)
        layerListLen = len(layerList)

        if layerListLen <= 0:
            QMessageBox.information(self.parent, u'검사 대상 정보', u'검사할 대상이 없습니다.')

        self.progressBar.setMaximum(0)
        self.progressBar.show()

        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        self.standardLayerStructure = self.logicalInspector.selectStandardLayerStructure()
        self.inspectStd = self.logicalInspector.selectInspectStandard(self.logicalInspector.B_CODE)

        loadResult = self.__loadData(layerList)
        if not loadResult:
            QMessageBox.warning(self.parent, u'검사 대상 오류', u'검사 대상을 불러오는데 실패하였습니다.')
            self.progressBar.setMaximum(100)
            return

        self.txtStatus.setText(u"미정의 레이어 검사")
        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        loadLayerList = self.logicalInspector.dbUtil.selectTableList(self.inspectSchema)
        stdErrLayerList = list()
        stdLayerList = self.standardLayerStructure.keys()

        for loadLayer in loadLayerList:
            tableNmList = loadLayer.split("_")

            if tableNmList[-1] in ['n', 'r', 'pe', 'ge', 'pge']:
                tmpLayer = "_".join(tableNmList[:-1])
                if tmpLayer not in stdLayerList:
                    stdErrLayerList.append(loadLayer)

            else:
                if loadLayer not in stdLayerList:
                    stdErrLayerList.append(loadLayer)

        if len(stdErrLayerList) > 0:
            result = QMessageBox.question(self.iface.mainWindow(), u"경고",
                                          u"표준에 맞지 않은 레이어가 있습니다\n\n" 
                                          + '\n'.join(stdErrLayerList) + u'\n\n검사를 계속 진행하시겠습니까?', 
                                          QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
 
            if result == QMessageBox.No:
                if self.plugin.MODE != 'external':
                    self.txtStatus.setText(u"논리/시간 검사가 중단되었습니다.")
                else:
                    self.txtStatus.setText(u"논리일관성 검사가 중단되었습니다.")

                self.progressBar.hide()
                return 

        # create err_index table
        self.logicalInspector.createErrIndexTable(self.inspectSchema)

        # 개념일관성 검사
        conceptualResult = self.logicalInspector.inspectConceptual(self.inspectSchema, self.txtStatus, layerList,
                                                                   self.standardLayerStructure, self.inspectStd)

        if len(conceptualResult) != 0:

            resColStd = u'[표준 칼럼 구성 미준수]\n'
            resColNull = u'[필수 칼럼의 속성 없음]\n'
            resGeomType = u'[도형타입 불일치]\n'
            resColType = u'[칼럼타입 불일치]\n'

            resColStdCount = 0
            resColNullCount = 0
            resGeomTypeCount = 0
            resColTypeCount = 0

            for res in conceptualResult:
                insCode = res['inspectCode']
                layerId = res['layer_id']
                layerNm = self.standardLayerStructure[layerId]['layer_nm'].decode("UTF-8")

                # 레이어의 컬럼 표준 미준수
                if insCode == 'LCCCSR02':
                    colList = res['col_list']

                    resColStd += u'\n레이어명 : {}\n' \
                                 u'오류칼럼 : {}'.format(layerNm, ', '.join(colList).upper())

                    resColStd += '\n'

                    resColStdCount += 1

                # 필수 컬럼의 속성 없음
                if insCode == 'LCCCSR03':
                    colList = res['col_list']
                    cidList = res['cid_list']

                    resColNull += u'\n레이어명 : {}\n' \
                                  u'필수칼럼 : {}\n' \
                                  u'오류 객체 수 : {}\n\n'.format(layerNm, colList.upper(), len(cidList))

                    cidStr = u'오류 객체:\n'
                    cidStr += '\n'.join(cidList) + '\n\n'

                    resColNull += cidStr

                    resColNullCount += 1

                # 도형타입 불일치
                if insCode == 'LCCCSR04':
                    resGeomType += '\n'
                    resGeomType += layerNm
                    resGeomType += '\n'

                    resGeomTypeCount += 1

                # 컬럼타입 불일치
                if insCode == 'LCCCSR05':
                    colList = res['col_list']

                    resColType += u'\n레이어명 : {}\n' \
                                  u'오류칼럼 : {}'.format(layerNm, ', '.join(colList).upper())

                    resColType += '\n'

                    resColTypeCount += 1

            result = list()

            if resColStdCount != 0:
                result.append(resColStd)

            if resColNullCount != 0:
                result.append(resColNull)

            if resGeomTypeCount != 0:
                result.append(resGeomType)

            if resColTypeCount != 0:
                result.append(resColType)

            if self.plugin.MODE != 'external':
                self.txtStatus.setText(u"논리/시간 검사완료.")
            else:
                self.txtStatus.setText(u"논리일관성 검사완료.")
            self.progressBar.hide()
            QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

            errTxt = os.path.join(self.imgSavePath, 'qi_result.txt')
            if not os.path.exists(os.path.dirname(errTxt)):
                os.mkdir(os.path.dirname(errTxt))

            with io.open(errTxt, 'w', encoding='utf8') as f:
                f.write('\n'.join(result))
            
            import platform
            if platform.system() == 'Windows':
                errTxt = '/' + errTxt.replace("\\","/")

            QMessageBox.warning(self.iface.mainWindow(), u"경고",
                                u"논리일관성 검사 중 <br>"
                                u"개념일관성 검사에서 오류가 검출되었습니다.<br>"
                                u"수정 후 다시 검사해주시기 바랍니다.<br><br>"
                                u"<a href='file://" + errTxt + "'>"
                                u"오류 확인 하기</a>")

            return

        # 도메인일관성, 위상일관성 검사
        self.logicalInspector.inspectData(self.txtStatus, self.inspectSchema, layerList,
                                          self.standardLayerStructure, self.inspectStd)

        self.logicalInspector.updateException(self.inspectSchema)

        shpPath = os.path.join(self.imgSavePath, 'err_index.shp')
        self.logicalInspector.exportErrIndex(self.inspectSchema, shpPath)

        gpkgPath = os.path.join(self.imgSavePath, 'qi_' + os.path.basename(self.qiData) + ".gpkg")
        self.logicalInspector.exportResGpkg(self.inspectSchema, gpkgPath)

        self.logicalInspector.completeInspect(None)

        self.logicalInspector.closeDB()

        self.progressBar.setMaximum(100)
        self.progressBar.hide()

        self.treeResult.scrollToTop()
        self.logger.info(u"Complete to inspect logic consistency")

        if self.plugin.MODE != 'external':
            self.txtStatus.setText(u"논리/시간 검사완료.")
            QMessageBox.information(self.iface.mainWindow(), u"검사완료", u"논리일관성/시간적품질 검사가 완료되었습니다.")
        else:
            self.txtStatus.setText(u"논리일관성 검사완료.")
            QMessageBox.information(self.iface.mainWindow(), u"검사완료", u"논리일관성 검사가 완료되었습니다.")

    def checkStandard(self):
        # update standard
        dbSchemaList = self.logicalInspector.dbUtil.selectSchemaList()
        if self.STANDARD_SCHEMA in dbSchemaList:
            self.logicalInspector.dropStdTables(self.STANDARD_SCHEMA)

        createRes = self.logicalInspector.createStdTable()

        return createRes

    def __loadData(self, layerList):
        result = False

        pointLayer = list()
        linestringLayer = list()
        polygonLayer = list()

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()  # type: QStringList

        try:
            self.txtStatus.setText(u"검사 대상 가져오는 중 ... ")

            layerGroupList = self.standardLayerStructure['layerGroup']
            dbInfo = self.logicalInspector.getDbInfo()
            groupRoot = QgsProject.instance().layerTreeRoot()

            for layerGroup in layerGroupList:
                self.iface.legendInterface().addGroup(layerGroup.decode("UTF-8"))

            stdLayerNmList = self.standardLayerStructure.keys()
            for layerNm in layerList:
                if layerNm not in stdLayerNmList:
                    continue

                uri = QgsDataSourceURI()
                uri.setConnection(dbInfo["host"], dbInfo["port"], dbInfo["dbname"],
                                  dbInfo["user"], dbInfo["password"])
                uri.setDataSource(self.inspectSchema, layerNm, "wkb_geometry", "", "id")
                ngdLayer = QgsVectorLayer(uri.uri(), layerNm, "postgres")

                self.logicalInspector.imgUtil.setDefaultSymbol(ngdLayer)

                group = groupRoot.findGroup(self.standardLayerStructure[layerNm]['layer_package'].decode("UTF-8"))

                if group:
                    QgsMapLayerRegistry.instance().addMapLayer(ngdLayer, False)

                    group.addLayer(ngdLayer)

                    legend = self.iface.legendInterface()
                    legend.setLayerVisible(ngdLayer, False)

                geometryType = ngdLayer.geometryType()
                ngdLayerId = ngdLayer.id()

                if geometryType == 0:
                    pointLayer.append(ngdLayerId)
                    # layerOrder.insert(0, ngdLayer.id())
                elif geometryType == 1:
                    linestringLayer.append(ngdLayerId)
                else:
                    polygonLayer.append(ngdLayerId)
                    # layerOrder.append(ngdLayer.id())

            groupList = groupRoot.children()
            for group in groupList:
                loadedLayerList = group.children()

                for layer in loadedLayerList:
                    layer.setExpanded(False)

            result = True

        except Exception as e:
            self.logger.warning(e)

        layerOrder += pointLayer
        layerOrder += linestringLayer
        layerOrder += polygonLayer

        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)
        self.iface.layerTreeCanvasBridge().setHasCustomLayerOrder(True)

        return result

    # 결과 tree 생성
    def addTree(self, inspectionNm, layerNm, inspectCode, cid, imgPath, tnImgPath, insResDetail, errInfo):
        if inspectionNm == 'logic':
            inspectionNm = u'논리일관성'
            bCode = 'DLC'
        else:
            inspectionNm = u'시간정확도'
            bCode = 'DTQ'

        mCodeList = self.inspectStd.keys()
        for mCode in mCodeList:
            if inspectCode in self.inspectStd[mCode].keys():
                inspectNm = self.inspectStd[mCode][inspectCode]["t_code_nm"].decode("UTF-8")

        rootNodeRes = self.treeModel.findItems(inspectionNm)

        if len(rootNodeRes) > 0:
            rootNode = rootNodeRes[0]
        else:
            rootNode = QStandardItem(inspectionNm)
            rootNode.setEditable(False)
            rootNode.setSelectable(False)

            self.treeModel.appendRow([rootNode])

        rootIdx = self.treeModel.indexFromItem(rootNode)
        self.treeResult.expand(rootIdx)

        rootNodeRows = rootNode.rowCount()
        layerNode = None

        layerNmKo = self.standardLayerStructure[layerNm]["layer_nm"].decode("UTF-8")

        for idx in range(0, rootNodeRows):
            tmpNode = rootNode.child(idx)
            if tmpNode.text() == layerNmKo:
                layerNode = tmpNode
                break

        if not layerNode:
            layerNode = QStandardItem(layerNmKo)
            layerNode.setEditable(False)
            layerNode.setSelectable(False)

            rootNode.appendRow([layerNode])

        layerIdx = self.treeModel.indexFromItem(layerNode)
        self.treeResult.expand(layerIdx)

        layerNodeRows = layerNode.rowCount()
        inspectCodeNode = None

        for idx in range(0, layerNodeRows):
            tmpNode = layerNode.child(idx)
            if tmpNode.text() == inspectNm:
                inspectCodeNode = tmpNode
                break

        if not inspectCodeNode:
            inspectCodeNode = QStandardItem(inspectNm)
            inspectCodeNode.setEditable(False)
            inspectCodeNode.setSelectable(False)

            layerNode.appendRow([inspectCodeNode])

        inspectCodeNodeRows = inspectCodeNode.rowCount()
        cidNodeList = list()

        for idx in range(0, inspectCodeNodeRows):
            tmpNode = inspectCodeNode.child(idx)
            if tmpNode.text() == cid or tmpNode.text().startswith("{}_".format(cid)):
                cidNodeList.append(tmpNode)

        if len(cidNodeList) > 0:
            cid = "{cid}_{idx}".format(cid=cid, idx=len(cidNodeList))

        featureErrReason = ''
        if cid in errInfo.keys():
            errorDcStr = errInfo[cid]['err_reason']
            errorDcList = errorDcStr.split("[AND]")

            errCode = errorDcList[0]
            errReason = errorDcList[1]

            errCodeList = errCode.split(',')
            errReasonList = errReason.split('|')

            for i in range(0, len(errCodeList)):
                if inspectNm == errCodeList[i]:
                    featureErrReason = errReasonList[i]

        cidNode = QStandardItem(cid)
        cidNode.setEditable(False)

        exceptionColor = QBrush()

        if featureErrReason != '':
            exceptionColor.setColor(Qt.black)

        else:
            exceptionColor.setColor(Qt.red)

        cidNode.setData(exceptionColor, Qt.ForegroundRole)

        featureInfo = {
            "layer": layerNm,
            "refLayer": insResDetail["refLayerId"],
            "featureId": cid,
            "imagePath": imgPath,
            "tnImagePath": tnImgPath,
            "inspectCode": inspectCode,
            "inspectNm": inspectNm,
            "colId": insResDetail["colId"],
            "colVal": insResDetail["colVal"],
            "errReason": featureErrReason
        }
        cidNode.setData(featureInfo)

        inspectCodeNode.appendRow([cidNode])

        self.__writeXml(imgPath)

        self.treeResult.scrollToBottom()

    def addShapeIdx(self, layer, inspectCode, imgPath, imgExtent):
        if not self.tmpShape:
            self.tmpShape = QgsVectorLayer("Polygon?crs=epsg:5179&field=layer_nm:string&field=err_nm:string"
                                           "&field=err_cd:string&field=img_nm:string&index=yes", "index", "memory")

        layerProvider = self.tmpShape.dataProvider()

        feat = QgsFeature(self.tmpShape.pendingFields())
        feat.setGeometry(QgsGeometry().fromRect(QgsRectangle(imgExtent.xMinimum(), imgExtent.yMinimum(),
                                                             imgExtent.xMaximum(), imgExtent.yMaximum())))
        feat.setAttribute('layer_nm', layer)

        errNm = ''
        mCodeList = self.inspectStd.keys()
        for mCode in mCodeList:
            if inspectCode in self.inspectStd[mCode].keys():
                errNm = self.inspectStd[mCode][inspectCode]["t_code_nm"].decode("UTF-8")

        feat.setAttribute('err_nm', errNm)
        feat.setAttribute('err_cd', inspectCode)
        feat.setAttribute('img_nm', os.path.basename(imgPath))

        layerProvider.addFeatures([feat])

    def loadImg(self, index):

        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        if self.errImgLayer:
            QgsMapLayerRegistry.instance().removeMapLayer(self.errImgLayer)

        featureInfo = selData.data()

        imgPath = featureInfo["imagePath"]
        # self.__writeXml(imgPath)

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()
        self.errImgLayer = QgsRasterLayer(imgPath, os.path.splitext(os.path.basename(imgPath))[0])
        # 이미지를 반투명하에 캔버스에 추가
        self.errImgLayer.renderer().setOpacity(0.5)

        QgsMapLayerRegistry.instance().addMapLayer(self.errImgLayer, False)

        groupRoot = QgsProject.instance().layerTreeRoot()
        groupRoot.insertLayer(0, self.errImgLayer)

        layerOrder.insert(0, self.errImgLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        legend = self.iface.legendInterface()
        layer = QgsMapLayerRegistry.instance().mapLayersByName(featureInfo["layer"])[0]

        if not self.crrLayer:
            self.crrLayer = layer
            legend.setLayerVisible(layer, True)

        else:
            if self.crrLayer.name() != layer.name():
                legend.setLayerVisible(self.crrLayer, False)
                legend.setLayerVisible(layer, True)

                self.crrLayer = layer

        while len(self.refLayerList) != 0:
            refLayer = self.refLayerList.pop()
            if refLayer.name() == self.crrLayer.name():
                continue

            legend.setLayerVisible(refLayer, False)

        refLayerStr = featureInfo["refLayer"]
        if refLayerStr:
            refLayerList = refLayerStr.split(",")

            for refLayerNm in refLayerList:
                if refLayerNm == self.crrLayer.name():
                    continue

                refLayer = QgsMapLayerRegistry.instance().mapLayersByName(refLayerNm)[0]
                legend.setLayerVisible(refLayer, True)
                self.refLayerList.append(refLayer)

        imgExtent = self.errImgLayer.extent()
        crrCrs = self.iface.mapCanvas().mapRenderer().destinationCrs().authid()

        if crrCrs != 'EPSG:5179':
            extentGeom = QgsGeometry.fromRect(imgExtent)
            sourceCrs = QgsCoordinateReferenceSystem("EPSG:5179")
            destCrs = QgsCoordinateReferenceSystem(crrCrs)
            tr = QgsCoordinateTransform(sourceCrs, destCrs)
            extentGeom.transform(tr)
            imgExtent = extentGeom.boundingBox()

        self.iface.mapCanvas().setExtent(imgExtent)
        self.iface.mapCanvas().refresh()

    @staticmethod
    def __writeXml(imgPath):
        baseNm = os.path.splitext(imgPath)[0]
        worldFile = "{}.pgw".format(baseNm)
        xmlFile = "{}.png.aux.xml".format(baseNm)

        if os.path.exists(xmlFile):
            return

        xmlTemplate = """
            <PAMDataset>
              <SRS>PROJCS["Korea 2000 / Unified CS",GEOGCS["Korea 2000",DATUM["Geocentric_datum_of_Korea",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],TOWGS84[0,0,0,0,0,0,0],AUTHORITY["EPSG","6737"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4737"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",38],PARAMETER["central_meridian",127.5],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",1000000],PARAMETER["false_northing",2000000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AUTHORITY["EPSG","5179"]]</SRS>
              <GeoTransform> {}, {}, {}, {}, {}, {} </GeoTransform>
              <Metadata domain="IMAGE_STRUCTURE">
                <MDI key="INTERLEAVE">PIXEL</MDI>
              </Metadata>
              <Metadata>
                <MDI key="AREA_OR_POINT">Area</MDI>
              </Metadata>
            </PAMDataset>
        """
        with open(worldFile, 'rb') as f:
            data = f.readlines()

        with open(xmlFile, 'wb') as f:
            f.write(xmlTemplate.format(data[4], data[0], data[1], data[5], data[2], data[3]))

    def setFeatureInfo(self, index):
        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        featureInfo = selData.data()

        self.txtFeatureId.setText(selData.text())
        self.txtErrContent.setText(featureInfo["inspectNm"])
        self.txtErrCol.setText(featureInfo["colId"])
        self.txtException.setText(featureInfo["errReason"])

        if isinstance(featureInfo["colVal"], int) or isinstance(featureInfo["colVal"], float):
            self.txtErrVal.setText(str(featureInfo["colVal"]))
        else:
            self.txtErrVal.setText(featureInfo["colVal"])

        errImg = QPixmap(featureInfo["tnImagePath"])
        errImgWidth = errImg.width()
        errImgHeight = errImg.height()

        labelWidth = self.labelErrImg.width()
        labelHeight = self.labelErrImg.height()

        if errImgWidth >= errImgHeight:
            resizeImg = errImg.scaledToWidth(labelWidth)
            if resizeImg.height() > labelHeight:
                resizeImg = resizeImg.scaledToHeight(labelHeight)
        else:
            resizeImg = errImg.scaledToHeight(labelHeight)
            if resizeImg.width() > labelWidth:
                resizeImg = resizeImg.scaledToWidth(labelWidth)

        self.labelErrImg.setPixmap(resizeImg)

    def addException(self):
        curIdx = self.treeResult.currentIndex()

        selData = self.treeModel.itemFromIndex(curIdx)  # type: QStandardItem

        if not selData or not selData.isSelectable():
            return

        erReason, ok = QInputDialog.getText(self, u'예외 처리', u'예외 사유를 기록해주시기 바랍니다.')

        if ok:
            if not erReason or erReason == '':
                QMessageBox.information(self.parent, u"예외 사유 오류", u"예외 사유를 입력해야합니다.")
                self.addException()
                return

            featureInfo = selData.data()

            self.updateErReason(featureInfo, erReason)

            exceptionColor = QBrush()
            # exceptionColor.setColor(Qt.red)
            exceptionColor.setColor(Qt.black)
            selData.setData(exceptionColor, Qt.ForegroundRole)

            featureInfo["errReason"] = erReason
            selData.setData(featureInfo)

            self.txtException.setText(erReason)

            exceptionInfo = {
                "cid": featureInfo["featureId"],
                "insTCode": featureInfo["inspectCode"],
                "imgNm": os.path.basename(featureInfo["imagePath"]),
                "bCode": "DLC",
                "erReason": erReason,
                "resCode": "IVS010"
            }
            self.logicalInspector.updateResCode(exceptionInfo)

    def updateErReason(self, featureInfo, erReason):
        layerNm = featureInfo["layer"]
        cid = featureInfo["featureId"]
        inspectCode = featureInfo["inspectCode"]
        inspectNm = featureInfo["inspectNm"]
        imgNm = os.path.basename(featureInfo["imagePath"])

        # 오류 인덱스 파일에 예외사유 기록
        os.environ['SHAPE_ENCODING'] = "utf-8"
        shpPath = os.path.join(self.imgSavePath, 'err_index.shp')
        shp = ogr.Open(shpPath, update=True)
        shpLayer = shp.GetLayer()

        filterStr = "img_nm = '" + imgNm + "' and err_cd = '" + inspectCode +"'"

        shpLayer.SetAttributeFilter(filterStr.encode("UTF-8"))

        shpFeature = shpLayer.GetNextFeature()
        shpFeature.SetField('error_dc', erReason.encode("UTF-8"))

        shpLayer.SetFeature(shpFeature)

        shp.Destroy()

        del os.environ['SHAPE_ENCODING']

        # GPKG에 예외사유 기록
        gpkgPath = os.path.join(self.imgSavePath, 'qi_' + os.path.basename(self.qiData) + ".gpkg")

        gpkg = ogr.Open(gpkgPath, update=True)
        gpkgLayer = gpkg.GetLayerByName(str(layerNm))
        gpkgLayer.SetAttributeFilter("cid = '{}'".format(cid))

        # gpkg.StartTransaction()

        feature = gpkgLayer.GetNextFeature()

        exceptionInfoStr = feature.GetField("error_dc").decode("UTF-8")

        errorNm = str()
        errorDc = str()

        if exceptionInfoStr is not None or exceptionInfoStr != '':
            exceptionInfoList = exceptionInfoStr.split("[AND]")
            errorNm = exceptionInfoList[0]
            errorDc = exceptionInfoList[1]

        errorNmList = list()
        if errorNm != '':
            errorNmList = errorNm.split(',')

        errorDcList = list()
        if errorDc != '':
            errorDcList = errorDc.split('|')

        if len(errorDcList) == 0:
            for i in range(0, len(errorNmList)):
                if inspectNm == errorNmList[i]:
                    errorDcList.append(erReason)
                else:
                    errorDcList.append('')

        else:
            for i in range(0, len(errorNmList)):
                if inspectNm == errorNmList[i]:
                    errorDcList[i] = erReason

        errorDc = '|'.join(errorDcList)

        feature.SetField('error_dc', '[AND]'.join([errorNm, errorDc]))
        gpkgLayer.SetFeature(feature)

        gpkg.Destroy()

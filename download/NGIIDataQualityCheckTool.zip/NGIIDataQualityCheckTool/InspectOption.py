# -*- coding: utf-8 -*-
import os

from PyQt4.QtGui import *
from PyQt4 import uic

FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/InspectOption.ui'))
class InspectOptionDialog(QDialog, FORM_CLASS):

    def __init__(self, parent=None):
        super(InspectOptionDialog, self).__init__(parent)
        self.setupUi(self)
        self.parent = parent
        # self.__connectFn()

    # def __connectFn(self):
    #     self.btn_inspectOption.clicked.connect(self.btnClick)

    def btnClick(self):
        pass
        # if self.chk_nfid.isChecked:
        #     print("NFID CHK")
        # if self.chk_cneterline.isChecked:
        #     print("CNETERLINE")
        # if self.chk_ctrln.isChecked:
        #     print("CTRLN")
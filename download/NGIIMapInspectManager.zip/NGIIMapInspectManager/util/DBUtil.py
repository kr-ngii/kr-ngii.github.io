# -*- coding: utf-8 -*-
import subprocess
import os
from collections import OrderedDict
from psycopg2.extensions import connection
import ConfigParser
import platform

import psycopg2
from psycopg2.sql import SQL, Identifier

import threading
import time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

import logging
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking
class CmdThread(threading.Thread):
    def __init__(self, commandList):
        self.commandList = commandList
        threading.Thread.__init__(self)

    def run(self):
        if platform.system() == 'Windows':
            subprocess.check_call(self.commandList, creationflags=0x08000000)
        else:
            subprocess.check_call(self.commandList, stderr=subprocess.STDOUT)
        return


def threadExecuteCmd(commandList):
    trd = CmdThread(commandList)
    trd.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class DBUtil:
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "properties", "connection.ini")
    SQL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sql", "sql.ini")

    STANDARD_SCHEMA = 'qiresult'
    INSEPCT_SCHEMA = 'ngii_inspect'

    __dbHost = 'localhost'
    __dbPort = '5432'
    __dbNm = 'postgres'
    __dbUser = 'postgres'
    __dbPassword = 'postgres'

    sqlStatement = None

    conn = None  # type: connection

    def __init__(self):
        self.logger = logger
        self.__loadProperties()
        self.__loadSql()

        self.connectPg()

    def __loadProperties(self):
        self.properties = ConfigParser.RawConfigParser()
        self.properties.read(self.PROPERTIES_FILE)

        # Database
        self.__dbHost = self.properties.get("database", "host")
        self.__dbPort = self.properties.get("database", "port")
        self.__dbNm = self.properties.get("database", "dbname")
        self.__dbUser = self.properties.get("database", "user")
        self.__dbPassword = self.properties.get("database", "password")

    def __loadSql(self):
        self.sqlStatement = ConfigParser.RawConfigParser()
        self.sqlStatement.read(self.SQL_FILE)

    def __createObjectChangeCol(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                createSql = self.sqlStatement.get("SQL", "createObjectChangeCol")
                self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(createSql).format(schema=Identifier(schema), table=Identifier(table)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"칼럼을 추가하는 데 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def integratedData(self, schema):
        createRes, createMsg = self.__createStandardTable(schema)

        if not createRes:
            return createRes, createMsg

        insertRes, insertMsg = self.__insertBaseData(schema)

        if not insertRes:
            return insertRes, insertMsg

        return True, None

    def __createStandardTable(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                stdTableNm = table.split('_base')[0]

                if stdTableNm in tableList:
                    continue

                seqNm = '{}.{}_ogc_fid_seq'.format(schema, stdTableNm)
                gistNm = '{}_wkb_geometry_geom_idx'.format(stdTableNm)
                createSql = self.sqlStatement.get("SQL", "createStandardTable")
                self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                    std_table=Identifier(stdTableNm),
                                                                    table=Identifier(table),
                                                                    seq_nm=SQL(seqNm),
                                                                    gist_nm=SQL(gistNm)),
                                              {"seq_nm": seqNm}))
                cur.execute(SQL(createSql).format(schema=Identifier(schema), std_table=Identifier(stdTableNm),
                                                  table=Identifier(table), seq_nm=SQL(seqNm),
                                                  gist_nm=SQL(gistNm)),
                            {"seq_nm": seqNm})

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"표준 테이블을 만드는 중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def __insertBaseData(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                if not table.endswith('_base'):
                    continue

                tableStrList = table.split('_')
                stdTableNm = "_".join(tableStrList[:-1])

                featureCount = self.selectFeatureCount(schema, table)
                if featureCount > 0:
                    insDataInfo = self.selectInsData(schema, stdTableNm)
                    idList = insDataInfo['id_list']
                    if idList:
                        idList.remove('')

                    idFilter = ''

                    if idList and len(idList) > 0:
                        idFilter = 'WHERE nf_id NOT IN (\'{nf_id_list}\')'.format(nf_id_list="','".join(idList))

                    colList = self.selectColList(schema, stdTableNm)

                    if 'ogc_fid' in colList:
                        colList.remove("ogc_fid")
                    colList.remove("obchg_se")

                    colListSql = [SQL(col) for col in colList]
                    selColListSql = list()
                    for col in colList:
                        if col.endswith("_dt"):
                            selColListSql.append(SQL("{}::timestamp".format(col)))
                        else:
                            selColListSql.append(SQL(col))

                    insertSql = self.sqlStatement.get("SQL", "insertBaseData")
                    self.logger.debug(cur.mogrify(SQL(insertSql).format(schema=Identifier(schema),
                                                                        std_table=Identifier(stdTableNm),
                                                                        table=Identifier(table),
                                                                        col_list=SQL(',').join(colListSql),
                                                                        sel_col_list=SQL(',').join(selColListSql),
                                                                        id_filter=SQL(idFilter))))
                    cur.execute(SQL(insertSql).format(schema=Identifier(schema),
                                                      std_table=Identifier(stdTableNm),
                                                      table=Identifier(table),
                                                      col_list=SQL(',').join(colListSql),
                                                      sel_col_list=SQL(',').join(selColListSql),
                                                      id_filter=SQL(idFilter)))

                else:
                    dropSql = self.sqlStatement.get("SQL", "dropTable")
                    self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema),
                                                                      table=Identifier(stdTableNm))))
                    cur.execute(SQL(dropSql).format(schema=Identifier(schema), table=Identifier(stdTableNm)))

                dropSql = self.sqlStatement.get("SQL", "dropTable")
                self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema),
                                                                  table=Identifier(table))))
                cur.execute(SQL(dropSql).format(schema=Identifier(schema), table=Identifier(table)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"데이터를 통합하는 과정에서 오류가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def getDbInfo(self):
        return {
            "host": self.__dbHost,
            "port": self.__dbPort,
            "dbname": self.__dbNm,
            "user": self.__dbUser,
            "password": self.__dbPassword,
        }

    def getCursor(self):
        try:
            cur = self.conn.cursor()
        except psycopg2.InterfaceError:
            if not self.connectPg:
                return None
            cur = self.conn.cursor()

        return cur

    def connectPg(self):
        try:
            if self.conn:
                self.conn.close()

            self.conn = psycopg2.connect(host=self.__dbHost, port=int(self.__dbPort), database=self.__dbNm,
                                         user=self.__dbUser, password=self.__dbPassword)

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return False

        return True

    def reloadProperties(self):
        self.__loadProperties()

    def selectInspectStandard(self, bCode):
        inspectList = OrderedDict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectInspectStandard")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"b_code": bCode}))
            cur.execute(SQL(selectSql), {"b_code": bCode})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tmpData = {
                    "t_code_nm": sqlResult[2].encode("UTF-8"),
                    "ins_target_code": sqlResult[3],
                    "std_val": sqlResult[4]
                }

                if sqlResult[0] in inspectList.keys():
                    inspectList[sqlResult[0]][sqlResult[1]] = tmpData
                else:
                    inspectList[sqlResult[0]] = OrderedDict()
                    inspectList[sqlResult[0]][sqlResult[1]] = tmpData

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return inspectList

    def selectStandardLayerStructure(self):
        layerInfo = OrderedDict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectStandardLayerStructure")
            self.logger.debug(cur.mogrify(SQL(selectSql)))
            cur.execute(SQL(selectSql))

            sqlResults = cur.fetchall()
            layerGroup = set()
            for sqlResult in sqlResults:
                layerGroup.add(sqlResult[1].encode("UTF-8"))
                layerInfo[sqlResult[0].lower()] = {
                    "layer_package": sqlResult[1].encode("UTF-8"),
                    "layer_nm": sqlResult[2].encode("UTF-8"),
                    "col_list": sqlResult[3]
                }

            layerInfo["layerGroup"] = list(layerGroup)

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return layerInfo

    def selectSchemaList(self):
        schemaList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectSchemaList")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"user": self.__dbUser}))
            cur.execute(SQL(selectSql), {"user": self.__dbUser})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                schemaList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return schemaList

    def selectCids(self, schema, table):
        cidList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectCids")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))

            sqlResults = cur.fetchall()

            cidList = [sqlResult[0] for sqlResult in sqlResults]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return cidList

    def selectNfIdList(self, schema, table):
        nfIdList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectNfIdList")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))

            sqlResults = cur.fetchall()

            nfIdList = [sqlResult[0] for sqlResult in sqlResults]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return nfIdList

    def selectColList(self, schema, table):
        colList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectColList")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema_nm": schema, "table_nm": table}))
            cur.execute(SQL(selectSql), {"schema_nm": schema, "table_nm": table})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                colList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return colList

    def selectColType(self, schema, table, colNm):
        colType = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectColType")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema_nm": schema, "table_nm": table, "col_nm": colNm}))
            cur.execute(SQL(selectSql), {"schema_nm": schema, "table_nm": table, "col_nm": colNm})

            sqlResult = cur.fetchone()

            colType = sqlResult[0]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return colType

    def createSchema(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            createSql = self.sqlStatement.get("SQL", "createSchema")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema))))
            cur.execute(SQL(createSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"스키마를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def dropSchema(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            dropSql = self.sqlStatement.get("SQL", "dropSchema")
            self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema))))
            cur.execute(SQL(dropSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"스키마를 삭제하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def dropTable(self, schema, table):
        result = False

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            dropSql = self.sqlStatement.get("SQL", "dropTable")
            self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema),
                                                              table=Identifier(table))))
            cur.execute(SQL(dropSql).format(schema=Identifier(schema), table=Identifier(table)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)

            self.conn.rollback()

        if cur:
            cur.close()

        return result

    def createErrIndexTable(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            createSql = self.sqlStatement.get("SQL", "createErrIndexTable")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema))))
            cur.execute(SQL(createSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"오류 인덱스 테이블을 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def insertErrIndex(self, schema, table, cid, err_cd, img_nm, extent):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        errInfo = {
            "layerNm": table,
            "cid": cid,
            "errCd": err_cd,
            "imgNm": img_nm,
            "geom": "POLYGON(({0} {1}, {0} {3}, {2} {3}, {2} {1}, {0} {1}))".format(
                str(extent.xMinimum()),
                str(extent.yMinimum()),
                str(extent.xMaximum()),
                str(extent.yMaximum())
            )
        }

        try:
            insertSql = self.sqlStatement.get("SQL", "insertErrIndex")
            self.logger.debug(cur.mogrify(SQL(insertSql).format(schema=Identifier(schema)), errInfo))
            cur.execute(SQL(insertSql).format(schema=Identifier(schema)), errInfo)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def exportErrIndex(self, schema, shp):
        self.logger.info("Start to Export SHP in database.")
        result = False

        pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password} ' \
                        'active_schema={schema} tables=err_index'\
            .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                    user=self.__dbUser, password=self.__dbPassword, schema=schema)

        commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '--config', 'SHAPE_ENCODING', 'UTF-8',
                       '-f', 'Esri Shapefile', shp, pgConnectInfo]

        try:
            self.logger.debug("Command : " + ' '.join(commandList))
            threadExecuteCmd(commandList)

            self.logger.info("Export completely.")

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return result, u'SHP를 DB에 넣는 도중 문제가 발생하였습니다.'

        self.logger.info("End to Export SHP in database.")

        result = True

        return result, None

    def selectTableList(self, schema):
        tableList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectTableList")
            self.logger.debug(cur.mogrify(selectSql, {"schema": schema}))
            cur.execute(selectSql, {"schema": schema})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tableList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return tableList

    def selectPointTableList(self, schema):
        tableList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectPointTableList")
            self.logger.debug(cur.mogrify(selectSql, {"schema": schema}))
            cur.execute(selectSql, {"schema": schema})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tableList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return tableList

    def selectFeatureCount(self, schema, table):
        count = -1

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectFeatureCount")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))
            sqlResult = cur.fetchone()

            count = int(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return count

    def selectInsData(self, schema, table):

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectInsData")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))
            sqlResult = cur.fetchone()

            insData = {
                "id_list": sqlResult[0],
                "min_x": sqlResult[1],
                "min_y": sqlResult[2],
                "max_x": sqlResult[3],
                "max_y": sqlResult[4]
            }

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return

        if cur:
            cur.close()

        return insData

    def selectTmsInsData(self, schema, table):

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectTmsInsData")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))
            sqlResult = cur.fetchone()

            insData = {
                "id_list": sqlResult[0],
                "min_x": sqlResult[1],
                "min_y": sqlResult[2],
                "max_x": sqlResult[3],
                "max_y": sqlResult[4],
                "obchg_dt": sqlResult[5]
            }

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return

        if cur:
            cur.close()

        return insData

    def vacuumSchema(self, schema, tables=None):
        result = False

        if not tables:
            tableList = self.selectTableList(schema)

            if len(tableList) <= 0:
                return result, '{schema} is empty'.format(schema=schema)
        else:
            tableList = tables

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            isolationLevel = self.conn.isolation_level
            self.conn.set_isolation_level(0)

            for table in tableList:
                vacuumSql = self.sqlStatement.get("SQL", "vacuumSchema")
                self.logger.debug(cur.mogrify(SQL(vacuumSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(vacuumSql).format(schema=Identifier(schema), table=Identifier(table)))
            self.conn.set_isolation_level(isolationLevel)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            self.conn.rollback()

            return result, u'VACUUM을 실행하는 도중 문제가 발생하였습니다.'

        else:
            self.conn.commit()

        if cur:
            cur.close()

        return result, ''

    def createCid(self, schema, table):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        createSql = """
            UPDATE {schema}.{table} SET change_info_id = 'qi_id_' || LPAD(nextval('qiresult.cid_tmp_seq')::text, 10, '0')
            WHERE change_info_id IS NULL OR change_info_id = '';
        """

        if 'change_info_id' not in self.selectColList(schema, table):
            createSql = """
                ALTER TABLE {schema}.{table} ADD COLUMN change_info_id character varying(40);
            """ + createSql
        
        try:
            cur.execute(createSql.format(schema=schema, table=table))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"change_info_id 를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def selectStandardCreateDate(self):
        standardCreateDate = dict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectStandardCreateDate")
            self.logger.debug(cur.mogrify(SQL(selectSql)))
            cur.execute(SQL(selectSql))

            sqlResult = cur.fetchone()

            standardCreateDate = {
                "com_code": sqlResult[0],
                "ins_standard": sqlResult[1],
                "std_layer": sqlResult[2],
                "std_struct": sqlResult[3],
                "std_codezip": sqlResult[4]
            }

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return standardCreateDate

    def deleteComCode(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteComCode")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertComCode(self, comCodeDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertComCode")
            for comCode in comCodeDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), comCode))
                cur.execute(SQL(insertSql), comCode)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteStandard(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteStandard")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertStandard(self, standardDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertStandard")
            for standard in standardDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), standard))
                cur.execute(SQL(insertSql), standard)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteLayer(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteLayer")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertLayer(self, LayerDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertLayer")
            for Layer in LayerDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), Layer))
                cur.execute(SQL(insertSql), Layer)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteLayerStruct(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteLayerStruct")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertLayerStruct(self, layerStructDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertLayerStruct")
            for layerStruct in layerStructDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), layerStruct))
                cur.execute(SQL(insertSql), layerStruct)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteCodezip(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteCodezip")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertCodezip(self, codezipList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertCodezip")
            for codezip in codezipList:
                self.logger.debug(cur.mogrify(SQL(insertSql), codezip))
                cur.execute(SQL(insertSql), codezip)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def selectErrInfo(self, schema, table):
        errInfo = dict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectErrInfo")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema),
                                              table=Identifier(table)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                errInfo[sqlResult[0]] = {
                    "err_code": sqlResult[1],
                    "err_reason": sqlResult[2]
                }

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        return errInfo
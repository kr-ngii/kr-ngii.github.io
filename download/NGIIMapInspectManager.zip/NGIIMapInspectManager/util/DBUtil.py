# -*- coding: utf-8 -*-
import subprocess
import os
import glob
import platform
from collections import OrderedDict
from psycopg2.extensions import connection
import ConfigParser

import psycopg2
from psycopg2.sql import SQL, Identifier

import threading, time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

import logging
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking
class CmdThread(threading.Thread):
    def __init__(self, commandList):
        self.commandList = commandList
        threading.Thread.__init__(self)

    def run(self):
        if platform.system() == 'Windows':
            subprocess.check_call(self.commandList, stderr=subprocess.STDOUT, creationflags=0x08000000)
        else:
            subprocess.check_call(self.commandList, stderr=subprocess.STDOUT)
        return

def threadExecuteCmd(commandList):
    trd = CmdThread(commandList)
    trd.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class DBUtil:
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "properties", "connection.ini")
    SQL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sql", "sql.ini")

    INS_SCHEMA = 'ngii_inspect'

    __dbHost = 'localhost'
    __dbPort = '5432'
    __dbNm = 'postgres'
    __dbUser = 'postgres'
    __dbPassword = 'postgres'

    sqlStatement = None

    conn = None  # type: connection

    def __init__(self):
        self.logger = logger
        self.__loadProperties()
        self.__loadSql()

        self.connectPg()

    def __loadProperties(self):
        self.properties = ConfigParser.RawConfigParser()
        self.properties.read(self.PROPERTIES_FILE)

        # Database
        self.__dbHost = self.properties.get("database", "host")
        self.__dbPort = self.properties.get("database", "port")
        self.__dbNm = self.properties.get("database", "dbname")
        self.__dbUser = self.properties.get("database", "user")
        self.__dbPassword = self.properties.get("database", "password")

    def __loadSql(self):
        self.sqlStatement = ConfigParser.RawConfigParser()
        self.sqlStatement.read(self.SQL_FILE)

    def checkInspectData(self, inspectData, inspectProgress):

        if self.INS_SCHEMA in self.selectSchemaList():
            self.dropSchema(self.INS_SCHEMA)

        if os.path.exists(inspectData):
            if os.path.isfile(inspectData):
                if not inspectData.endswith('gpkg'):
                    return False, u"검사대상은 GeoPackage 파일을 선택해야합니다."
                dataKind = 'file'
            elif os.path.isdir(inspectData):
                if len(glob.glob(os.path.join(inspectData, "*.shp"))) == 0:
                    return False, u"폴더 안에 SHP이 존재하지 않습니다.\n다른 폴더를 선택해주세요."
                dataKind = 'dir'
            else:
                return False, u"검사대상에 문제가 있습니다."

        else:
            return False, u"검사대상에 문제가 있습니다."

        if dataKind == 'file':
            inspectProgress.setInfo(u"검사를 위해 GeoPackage를 가져오는 중 ... ")
            inspectResult, msg = self.__insertGpkg(inspectData)
            if not inspectResult:
                return False, msg
        elif dataKind == 'dir':
            inspectProgress.setInfo(u"검사를 위해 Shapefile을 가져오는 중 ... ")
            inspectResult, msg = self.__insertShp(inspectData)
            if not inspectResult:
                return False, msg

        return True, msg

    def __insertShp(self, inspectData):
        self.logger.info("Start to insert SHP in database.")
        result = False

        createResult, errMsg = self.createSchema(self.INS_SCHEMA)
        if not createResult:
            return result, errMsg

        pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password}' \
            .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                    user=self.__dbUser, password=self.__dbPassword)

        for shp in glob.glob(os.path.join(inspectData, "*.shp")):
            self.logger.debug(shp)
            commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '--config', 'SHAPE_ENCODING', 'CP949',
                           '--config', 'GDAL_FILENAME_IS_UTF8', 'NO', '-f', 'PostgreSQL',
                           pgConnectInfo, shp, '-nlt', 'PROMOTE_TO_MULTI', '-lco', 'PRECISION=NO',
                           '-lco', 'SCHEMA={schema}'.format(schema=self.INS_SCHEMA), '-dim', 'XY']

            try:
                # self.logger.debug("Command : {cmd}".format(cmd=' '.join(commandList)))
                threadExecuteCmd(commandList)

                self.logger.info("Insert completely.")

            except Exception as e:
                self.logger.warning(e, exc_info=True)
                return result, u'SHP를 DB에 넣는 도중 문제가 발생하였습니다.'

        # cid 생성
        self.createCid(self.INS_SCHEMA)

        # add column obchg_se
        # self.__createObjectChangeCol(schema)

        # integrated table
        # self.__createStandardTable(schema)
        # self.__insertChangeData(schema)

        vacuumResult, errMsg = self.vacuumSchema(self.INS_SCHEMA)
        if not vacuumResult:
            return result, errMsg

        self.logger.info("End to insert SHP in database.")

        result = True

        return result, self.INS_SCHEMA

    def __insertGpkg(self, schema, inspectData):
        self.logger.info("Start to insert GeoPackage in database.")
        result = False

        createResult, errMsg = self.createSchema(schema)
        if not createResult:
            return result, errMsg

        pgConnectInfo = 'PG:host={host} port={port} dbname={dbname} user={user} password={password}'\
            .format(host=self.__dbHost, port=self.__dbPort, dbname=self.__dbNm,
                    user=self.__dbUser, password=self.__dbPassword)

        commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '--config', 'SHAPE_ENCODING', 'UTF-8', '-f', 'PostgreSQL',
                       pgConnectInfo, inspectData, '-nlt', 'PROMOTE_TO_MULTI',
                       '-lco', 'SCHEMA={schema}'.format(schema=schema)]

        try:
            self.logger.debug("Command : {cmd}".format(cmd=' '.join(commandList)))
            # subprocess.check_call(commandList)
            threadExecuteCmd(commandList)

            self.logger.info("Insert completely.")

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return result, u'GPKG를 DB에 넣는 도중 문제가 발생하였습니다.'

        # TODO: 삭제
        # cid 생성
        # self.createCid(schema)

        # add column obchg_se
        # self.__createObjectChangeCol(schema)

        # integrated table
        # self.__createStandardTable(schema)
        # self.__insertChangeData(schema)

        vacuumResult, errMsg = self.vacuumSchema(schema)
        if not vacuumResult:
            return result, errMsg

        self.logger.info("End to insert GeoPackage in database.")

        result = True

        return result, schema

    def __createObjectChangeCol(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                createSql = self.sqlStatement.get("SQL", "createObjectChangeCol")
                self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(createSql).format(schema=Identifier(schema), table=Identifier(table)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"칼럼을 추가하는 데 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def __createStandardTable(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                tableStrList = table.split('_')
                chageType = tableStrList[-1]

                if chageType in ['n', 'r', 'pe', 'ge', 'pge']:
                    tableNm = "_".join(tableStrList[:-1])
                    seqNm = '{}_fid_seq'.format(tableNm)
                    createSql = self.sqlStatement.get("SQL", "createStandardTable")
                    self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema),
                                                                        std_table=Identifier(tableNm),
                                                                        table=Identifier(table),
                                                                        seq_nm=Identifier(seqNm)),
                                                  {"seq_nm": seqNm}))
                    cur.execute(SQL(createSql).format(schema=Identifier(schema), std_table=Identifier(tableNm),
                                                      table=Identifier(table), seq_nm=Identifier(seqNm)),
                                {"seq_nm": seqNm})

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"표준 테이블을 만드는 중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def __insertChangeData(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        try:
            for table in tableList:
                tableStrList = table.split('_')
                changeType = tableStrList[-1]

                if changeType in ['n', 'r', 'pe', 'ge', 'pge']:
                    tableNm = "_".join(tableStrList[:-1])
                    colList = self.selectColList(schema, tableNm)

                    if 'fid' in colList:
                        colList.remove("fid")
                    colList.remove("obchg_se")

                    colListSql = [SQL(col) for col in colList]
                    insertSql = self.sqlStatement.get("SQL", "insertChangeData")
                    self.logger.debug(cur.mogrify(SQL(insertSql).format(schema=Identifier(schema),
                                                                        std_table=Identifier(tableNm),
                                                                        table=Identifier(table),
                                                                        col_list=SQL(',').join(colListSql)),
                                      {"mod": changeType}))
                    cur.execute(SQL(insertSql).format(schema=Identifier(schema),
                                                      std_table=Identifier(tableNm),
                                                      table=Identifier(table),
                                                      col_list=SQL(',').join(colListSql)),
                                {"mod": changeType})

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"데이터를 통합하는 과정에서 오류가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def getDbInfo(self):
        return {
            "host": self.__dbHost,
            "port": self.__dbPort,
            "dbname": self.__dbNm,
            "user": self.__dbUser,
            "password": self.__dbPassword,
        }

    def getCursor(self):
        try:
            cur = self.conn.cursor()
        except psycopg2.InterfaceError:
            if not self.connectPg:
                return None
            cur = self.conn.cursor()

        return cur

    def connectPg(self):
        try:
            if self.conn:
                self.conn.close()

            self.conn = psycopg2.connect(host=self.__dbHost, port=int(self.__dbPort), database=self.__dbNm,
                                         user=self.__dbUser, password=self.__dbPassword)

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return False

        return True

    def reloadProperties(self):
        self.__loadProperties()

    def selectInspectStandard(self, bCode):
        inspectList = OrderedDict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectInspectStandard")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"b_code": bCode}))
            cur.execute(SQL(selectSql), {"b_code": bCode})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tmpData = {
                    "t_code_nm": sqlResult[2].encode("UTF-8"),
                    "ins_target_code": sqlResult[3],
                    "std_val": sqlResult[4]
                }

                if sqlResult[0] in inspectList.keys():
                    inspectList[sqlResult[0]][sqlResult[1]] = tmpData
                else:
                    inspectList[sqlResult[0]] = OrderedDict()
                    inspectList[sqlResult[0]][sqlResult[1]] = tmpData

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return inspectList

    def selectStandardLayerStructure(self):
        layerInfo = OrderedDict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectStandardLayerStructure")
            self.logger.debug(cur.mogrify(SQL(selectSql)))
            cur.execute(SQL(selectSql))

            sqlResults = cur.fetchall()
            layerGroup = set()
            for sqlResult in sqlResults:
                layerGroup.add(sqlResult[1].encode("UTF-8"))
                layerInfo[sqlResult[0].lower()] = {
                    "layer_package": sqlResult[1].encode("UTF-8"),
                    "layer_nm": sqlResult[2].encode("UTF-8"),
                    "col_list": sqlResult[3]
                }

            layerInfo["layerGroup"] = list(layerGroup)

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return layerInfo

    def selectSchemaList(self):
        schemaList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectSchemaList")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"user": self.__dbUser}))
            cur.execute(SQL(selectSql), {"user": self.__dbUser})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                schemaList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return schemaList

    def selectCids(self, schema, table):
        cidList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectCids")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))

            sqlResults = cur.fetchall()

            cidList = [sqlResult[0] for sqlResult in sqlResults]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return cidList

    def selectColList(self, schema, table):
        colList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectColList")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema_nm": schema, "table_nm": table}))
            cur.execute(SQL(selectSql), {"schema_nm": schema, "table_nm": table})

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                colList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return colList

    def selectColType(self, schema, table, colNm):
        colType = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectColType")
            self.logger.debug(cur.mogrify(SQL(selectSql), {"schema_nm": schema, "table_nm": table, "col_nm": colNm}))
            cur.execute(SQL(selectSql), {"schema_nm": schema, "table_nm": table, "col_nm": colNm})

            sqlResult = cur.fetchone()

            colType = sqlResult[0]

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return colType

    def createSchema(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            createSql = self.sqlStatement.get("SQL", "createSchema")
            self.logger.debug(cur.mogrify(SQL(createSql).format(schema=Identifier(schema))))
            cur.execute(SQL(createSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"스키마를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def dropSchema(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            dropSql = self.sqlStatement.get("SQL", "dropSchema")
            self.logger.debug(cur.mogrify(SQL(dropSql).format(schema=Identifier(schema))))
            cur.execute(SQL(dropSql).format(schema=Identifier(schema)))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"스키마를 삭제하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def selectTableList(self, schema):
        tableList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectTableList")
            self.logger.debug(cur.mogrify(selectSql, {"schema": schema}))
            cur.execute(selectSql, {"schema": schema})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tableList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return tableList

    def selectPointTableList(self, schema):
        tableList = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectPointTableList")
            self.logger.debug(cur.mogrify(selectSql, {"schema": schema}))
            cur.execute(selectSql, {"schema": schema})
            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                tableList.append(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return tableList

    def selectFeatureCount(self, schema, table):
        count = -1

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectFeatureCount")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            cur.execute(SQL(selectSql).format(schema=Identifier(schema), table=Identifier(table)))
            sqlResult = cur.fetchone()

            count = int(sqlResult[0])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return count

    def vacuumSchema(self, schema, tables=None):
        result = False

        if not tables:
            tableList = self.selectTableList(schema)

            if len(tableList) <= 0:
                return result, '{schema} is empty'.format(schema=schema)
        else:
            tableList = tables

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            isolationLevel = self.conn.isolation_level
            self.conn.set_isolation_level(0)

            for table in tableList:
                vacuumSql = self.sqlStatement.get("SQL", "vacuumSchema")
                self.logger.debug(cur.mogrify(SQL(vacuumSql).format(schema=Identifier(schema),
                                                                    table=Identifier(table))))
                cur.execute(SQL(vacuumSql).format(schema=Identifier(schema), table=Identifier(table)))
            self.conn.set_isolation_level(isolationLevel)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            self.conn.rollback()

            return result, u'VACUUM을 실행하는 도중 문제가 발생하였습니다.'

        else:
            self.conn.commit()

        if cur:
            cur.close()

        return result, ''

    def createCid(self, schema):
        result = False
        errMsg = None

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        tableList = self.selectTableList(schema)

        createSql = """
            ALTER TABLE {schema}.{table} ADD COLUMN cid character varying(40);
            UPDATE {schema}.{table} SET cid = '{schema}_{table}_' || ogc_fid;
        """
        
        try:
            for table in tableList:
                cur.execute(createSql.format(schema=schema, table=table))

            self.conn.commit()

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = u"CID를 생성하는 도중 문제가 발생하였습니다."

            self.conn.rollback()

        if cur:
            cur.close()

        return result, errMsg

    def selectStandardCreateDate(self):
        standardCreateDate = dict()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectStandardCreateDate")
            self.logger.debug(cur.mogrify(SQL(selectSql)))
            cur.execute(SQL(selectSql))

            sqlResult = cur.fetchone()

            standardCreateDate = {
                "com_code": sqlResult[0],
                "ins_standard": sqlResult[1],
                "std_layer": sqlResult[2],
                "std_struct": sqlResult[3],
                "std_codezip": sqlResult[4]
            }

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return standardCreateDate

    def deleteComCode(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteComCode")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertComCode(self, comCodeDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertComCode")
            for comCode in comCodeDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), comCode))
                cur.execute(SQL(insertSql), comCode)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteStandard(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteStandard")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertStandard(self, standardDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertStandard")
            for standard in standardDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), standard))
                cur.execute(SQL(insertSql), standard)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteLayer(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteLayer")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertLayer(self, LayerDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertLayer")
            for Layer in LayerDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), Layer))
                cur.execute(SQL(insertSql), Layer)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def deleteLayerStruct(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteLayerStruct")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertLayerStruct(self, layerStructDictList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertLayerStruct")
            for layerStruct in layerStructDictList:
                self.logger.debug(cur.mogrify(SQL(insertSql), layerStruct))
                cur.execute(SQL(insertSql), layerStruct)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg


    def deleteCodezip(self):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            deleteSql = self.sqlStatement.get("SQL", "deleteCodezip")
            self.logger.debug(cur.mogrify(SQL(deleteSql)))
            cur.execute(SQL(deleteSql))

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

    def insertCodezip(self, codezipList):
        result = False
        errMsg = ''

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            insertSql = self.sqlStatement.get("SQL", "insertCodezip")
            for codezip in codezipList:
                self.logger.debug(cur.mogrify(SQL(insertSql), codezip))
                cur.execute(SQL(insertSql), codezip)

            result = True

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

            self.conn.rollback()

        else:
            self.conn.commit()

        return result, errMsg

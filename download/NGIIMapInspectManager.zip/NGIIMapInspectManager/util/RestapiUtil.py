# -*- coding: utf-8 -*-
import json
import urllib2
import os
import ConfigParser
import subprocess
import logging.handlers
import threading
from  threading import Thread
import time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking
class CmdThread(Thread):
    __response = None

    def __init__(self, request):
        self.request = request
        Thread.__init__(self)

    def run(self):
        self.__response = urllib2.urlopen(self.request)

    def join(self, timeout=None):
        Thread.join(self, timeout)
        return self.__response


def threadExecuteRestapi(request):
    trd = CmdThread(request)
    trd.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)

    return trd.join()

class RestAPIUtil:
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "properties", "connection.ini")

    __dbHost = 'localhost'
    __dbPort = '5432'
    __dbNm = 'ngii'
    __dbUser = 'ngii'
    __dbPassword = 'gaiangii'

    # TODO 삭제
    __gsHost = 'localhost'
    __gsPort = '8080'
    __gsWorkspace = 'gs_workspace'

    __server_url = "http://seoul.gaia3d.com:8989/kqiweb/"
    __geoserver_url = "http://seoul.gaia3d.com:8989/geoserver/"

    __conn = None

    def __init__(self):
        self.logger = logger

        self.__loadProperties()

    def __loadProperties(self):
        self.properties = ConfigParser.RawConfigParser()
        self.properties.read(self.PROPERTIES_FILE)

        # Database
        self.__dbHost = self.properties.get("database", "host")
        self.__dbPort = self.properties.get("database", "port")
        self.__dbNm = self.properties.get("database", "dbname")
        self.__dbUser = self.properties.get("database", "user")
        self.__dbPassword = self.properties.get("database", "password")

        # GeoServer
        self.__gsHost = self.properties.get("geoserver", "host")
        self.__gsPort = self.properties.get("geoserver", "port")
        self.__gsWorkspace = self.properties.get("geoserver", "workspace")

        port = ""
        if self.__gsPort:
            port = ":{}".format(self.__gsPort)

        self.__geoserver_url = "http://{url}{port}/geoserver/".format(url=self.__gsHost, port=port)
        self.__server_url = "http://{url}{port}/kqiweb/".format(url=self.__gsHost, port=port)

    def saveResult(self, data):
        self.logger.debug("Save inspect result.")
        result = False
        resultSaveUrl = self.__server_url + "kgi/insert_result.do"

        try:
            request = urllib2.Request(resultSaveUrl, json.dumps(data), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

    def updateResCode(self, data):
        self.logger.debug("update inspect result.")
        result = False
        resultSaveUrl = self.__server_url + "kgi/updateFeatureResult.do"

        try:
            request = urllib2.Request(resultSaveUrl, json.dumps({"data": data}), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

    def completeInspect(self, bCode, insGroupId):
        self.logger.debug("Complete Inspect.")
        result = False
        resultSaveUrl = self.__server_url + "kgi/update_result.do"

        data = {
            "bCode": bCode,
            "insGroupId": insGroupId
        }

        try:
            request = urllib2.Request(resultSaveUrl, json.dumps(data), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

    # TODO: 통합 UI로 기능 이전
    def saveFeatureInfo(self, data):
        self.logger.debug("Insert inspect data.")
        result = False
        featureInfoSaveUrl = self.__server_url + "kgi/insert_feature.do"

        try:
            request = urllib2.Request(featureInfoSaveUrl, json.dumps(data), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(featureInfoSaveUrl)
            self.logger.warning(e)

        return result

    def getCodeList(self, createDate):
        self.logger.debug("get common code list.")
        result = list()
        codeListUrl = self.__server_url + "product/codeList.do"

        try:
            request = urllib2.Request(codeListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(codeListUrl)
            self.logger.warning(e)

        return result

    def getStandardList(self, createDate):
        self.logger.debug("Insert inspect data.")
        result = list()
        standartListUrl = self.__server_url + "product/standardList.do"

        try:
            request = urllib2.Request(standartListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(standartListUrl)
            self.logger.warning(e)

        return result

    def getLayerList(self, createDate):
        self.logger.debug("Insert inspect data.")
        result = list()
        layerListUrl = self.__server_url + "product/layerList.do"

        try:
            request = urllib2.Request(layerListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(layerListUrl)
            self.logger.warning(e)

        return result

    def getLayerStructList(self, createDate):
        self.logger.debug("Insert inspect data.")
        result = list()
        LayerStructListUrl = self.__server_url + "product/structList.do"

        try:
            request = urllib2.Request(LayerStructListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(LayerStructListUrl)
            self.logger.warning(e)

        return result

    def getCodezipList(self, createDate):
        self.logger.debug("Insert inspect data.")
        result = list()
        codeZipListUrl = self.__server_url + "product/codezipList.do"

        try:
            request = urllib2.Request(codeZipListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(codeZipListUrl)
            self.logger.warning(e)

        return result

    def getNgdData(self, schema, layer, layerExtent):
        self.logger.info("Insert NGD data using WFS")
        errMsg = ''

        pgConnectInfo = 'PG:host={host} user={user} password={password} dbname={dbname}' \
            .format(host=self.__dbHost, user=self.__dbUser, password=self.__dbPassword, dbname=self.__dbNm)

        wfsInfo = 'WFS:http://{host}:{port}/geoserver/wfs?service=WFS&request=GetFeature&version=1.1.0' \
                   '&typeName={workspace}:{layer}&srsName=EPSG:5179&bbox={extent},EPSG:5179'\
            .format(host=self.__gsHost,
                    port=self.__gsPort,
                    workspace=self.__gsWorkspace,
                    layer=layer,
                    extent=','.join(layerExtent))

        commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '-f', 'PostgreSQL',
                       pgConnectInfo, wfsInfo, '-lco', 'SCHEMA={schema}'.format(schema=schema),
                       '-nln', '{layer}_integrated'.format(layer=layer)]

        try:
            self.logger.debug("Command : {cmd}".format(cmd=' '.join(commandList)))
            subprocess.check_call(commandList)

            self.logger.info("Insert completely.")

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            errMsg = str(e)

        return errMsg

    def saveReport(self, data, filePath):
        self.logger.debug("SaveReport result.")
        result = False
        resultSaveUrl = self.__server_url + "report/saveReport.do"
        list = {
            "cid": data,
            "std": True,
            "filePath": filePath
        }
        try:
            request = urllib2.Request(resultSaveUrl, json.dumps(list), {'Content-Type': 'application/json'})
            response = threadExecuteRestapi(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

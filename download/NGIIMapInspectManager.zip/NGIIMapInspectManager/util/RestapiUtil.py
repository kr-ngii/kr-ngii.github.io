# -*- coding: utf-8 -*-
import json
import urllib2
import os
import ConfigParser
import subprocess
import codecs
import platform
import threading
import time

from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking
class CmdThread(threading.Thread):
    def __init__(self, commandList):
        self.commandList = commandList
        threading.Thread.__init__(self)

    def run(self):
        if platform.system() == 'Windows':
            subprocess.check_call(self.commandList, creationflags=0x08000000)
        else:
            subprocess.check_call(self.commandList, stderr=subprocess.STDOUT)
        return


def threadExecuteCmd(commandList):
    trd = CmdThread(commandList)
    trd.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class RestAPIUtil:
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "properties", "connection.ini")
    JSON_PATH = jsonPath = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "feature_info")

    __dbHost = 'localhost'
    __dbPort = '5432'
    __dbNm = 'ngii'
    __dbUser = 'ngii'
    __dbPassword = 'gaiangii'

    __pgConnectInfo = None

    __gsHost = 'localhost'
    __gsPort = '8080'
    __gsWorkspace = 'gs_workspace'

    __server_url = "http://seoul.gaia3d.com:8989/kqiweb/"
    __geoserver_url = "http://seoul.gaia3d.com:8989/geoserver/"
    WORKSPACE = 'nga'
    # __geoserver_url = "http://mndns.iptime.org:9080/geoserver/"
    # WORKSPACE = 'nga'

    def __init__(self):
        self.logger = logger

        self.__loadProperties()

        if not os.path.exists(self.JSON_PATH):
            os.mkdir(self.JSON_PATH)

    def __loadProperties(self):
        self.properties = ConfigParser.RawConfigParser()
        self.properties.read(self.PROPERTIES_FILE)

        # Database
        self.__dbHost = self.properties.get("database", "host")
        self.__dbPort = self.properties.get("database", "port")
        self.__dbNm = self.properties.get("database", "dbname")
        self.__dbUser = self.properties.get("database", "user")
        self.__dbPassword = self.properties.get("database", "password")

        self.__pgConnectInfo = 'PG:host={host} user={user} password={password} dbname={dbname}'\
            .format(host=self.__dbHost, user=self.__dbUser, password=self.__dbPassword, dbname=self.__dbNm)

        # GeoServer
        self.__gsHost = self.properties.get("geoserver", "host")
        self.__gsPort = self.properties.get("geoserver", "port")
        self.__gsWorkspace = self.properties.get("geoserver", "workspace")

        port = ""
        if self.__gsPort:
            port = ":{}".format(self.__gsPort)

        # self.__geoserver_url = "http://{url}{port}/geoserver/".format(url=self.__gsHost, port=port)
        self.__server_url = "http://{url}{port}/kqiweb/".format(url=self.__gsHost, port=port)

    def saveResult(self, data):
        self.logger.info("Save inspect result.")

        result = False
        resultSaveUrl = self.__server_url + "kgi/insert_result.do"

        try:
            request = urllib2.Request(resultSaveUrl, json.dumps(data), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

    def updateResCode(self, data):
        self.logger.info("update inspect result.")
        result = False
        resultSaveUrl = self.__server_url + "kgi/updateFeatureResult.do"

        try:
            request = urllib2.Request(resultSaveUrl, json.dumps({"data": [data]}), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

    def completeInspect(self, bCode, insGroupId):
        self.logger.info("Complete Inspect.")
        result = False
        resultSaveUrl = self.__server_url + "kgi/update_result.do"

        data = {
            "bCode": bCode,
            "insGroupId": insGroupId
        }

        try:
            request = urllib2.Request(resultSaveUrl, json.dumps(data), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())
                return result

            result = True
        except Exception as e:
            self.logger.warning(resultSaveUrl)
            self.logger.warning(e)

        return result

    def getCodeList(self, createDate):
        self.logger.info("get common code list.")
        result = list()
        codeListUrl = self.__server_url + "product/codeList.do"

        try:
            request = urllib2.Request(codeListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(codeListUrl)
            self.logger.warning(e)

        return result

    def getStandardList(self, createDate):
        self.logger.info("Insert inspect data.")
        result = list()
        standartListUrl = self.__server_url + "product/standardList.do"

        try:
            request = urllib2.Request(standartListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(standartListUrl)
            self.logger.warning(e)

        return result

    def getLayerList(self, createDate):
        self.logger.info("Insert inspect data.")
        result = list()
        layerListUrl = self.__server_url + "product/layerList.do"

        try:
            request = urllib2.Request(layerListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(layerListUrl)
            self.logger.warning(e)

        return result

    def getLayerStructList(self, createDate):
        self.logger.info("Insert inspect data.")
        result = list()
        LayerStructListUrl = self.__server_url + "product/structList.do"

        try:
            request = urllib2.Request(LayerStructListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(LayerStructListUrl)
            self.logger.warning(e)

        return result

    def getCodezipList(self, createDate):
        self.logger.info("Insert inspect data.")
        result = list()
        codeZipListUrl = self.__server_url + "product/codezipList.do"

        try:
            request = urllib2.Request(codeZipListUrl, data="")
            response = urllib2.urlopen(request)

            res_code = response.getcode()
            if res_code != 200:
                self.logger.warning(response.info())

            data = json.loads(response.read())
            result = data["message"]

        except Exception as e:
            self.logger.warning(codeZipListUrl)
            self.logger.warning(e)

        return result

    def getInspectFeatureByCid(self, schema, dataDict, stdStruct):
        self.logger.info("Insert inspect features data using WFS")

        layerList = dataDict.keys()

        for layer in layerList:
            filterXml = '<?xml version="1.0" encoding="utf-8"?>' \
                        '<wfs:GetFeature service="WFS" version="1.1.0" outputFormat="application/json" ' \
                        'xmlns:wfs="http://www.opengis.net/wfs" ' \
                        'xmlns:ogc="http://www.opengis.net/ogc">' \
                        '<wfs:Query typeName="{workspace}:{layer}_change">' \
                        '<ogc:Filter>' \
                        '<ogc:Or>' \
                        '{conditionXml}' \
                        '</ogc:Or>' \
                        '</ogc:Filter>' \
                        '</wfs:Query>' \
                        '</wfs:GetFeature>'

            columnXml = '<wfs:PropertyName>change_info_id</wfs:PropertyName>' \
                        '<wfs:PropertyName>object_gt</wfs:PropertyName>' \
                        '<wfs:PropertyName>obchg_se</wfs:PropertyName>' \
                        '<wfs:PropertyName>obchg_dt</wfs:PropertyName>' \
                        '<wfs:PropertyName>rsreg_dt</wfs:PropertyName>' \
                        '<wfs:PropertyName>error_dc</wfs:PropertyName>' \
                        '<wfs:PropertyName>bsnm_error_dc</wfs:PropertyName>'

            struct = stdStruct[layer]
            colList = struct['col_list']
            wfsCol = ['change_info_id', 'obchg_se', 'obchg_dt', 'rsreg_dt', 'error_dc', 'bsnm_error_dc']
            for colNm in colList:
                wfsCol.append(colNm.lower())
                columnXml += '<wfs:PropertyName>{colNm}</wfs:PropertyName>'.format(colNm=colNm.lower())

            cidList = dataDict[layer]
            conditionXml = str()

            for cid in cidList:
                conditionXml += '<ogc:PropertyIsEqualTo matchCase="true">' \
                            '<ogc:PropertyName>change_info_id</ogc:PropertyName>' \
                            '<ogc:Literal>{cid}</ogc:Literal>' \
                            '</ogc:PropertyIsEqualTo>'.format(cid=cid)

            jsonFilePath = os.path.join(self.JSON_PATH, "{}.json".format(layer))

            if os.path.exists(jsonFilePath):
                os.remove(jsonFilePath)

            try:
                xmlData = filterXml.format(workspace=self.WORKSPACE, layer=layer ,conditionXml=conditionXml)

                # wfsUrl = self.__server_url + "kgi/wfs.do"
                wfsUrl = self.__geoserver_url + "wfs"
                request = urllib2.Request(wfsUrl, xmlData, {'Content-Type': 'application/xml'})
                response = urllib2.urlopen(request)

                resData = response.read()

                with codecs.open(os.path.join(jsonFilePath), 'wb', encoding='utf-8') as json_file:
                    json.dump(json.loads(resData), json_file, ensure_ascii=False, indent=4)

                if os.path.exists(jsonFilePath):
                    commandList = ['ogr2ogr', '-a_srs', 'EPSG:5179', '-select', ','.join(wfsCol),'-f', 'PostgreSQL',
                                   self.__pgConnectInfo, jsonFilePath, '-lco', 'SCHEMA={schema}'.format(schema=schema),
                                   '-lco', 'PRECISION=NO', '-nln', layer, '-nlt', 'PROMOTE_TO_MULTI']
                    self.logger.debug("Command : {cmd}".format(cmd=' '.join(commandList)))
                    threadExecuteCmd(commandList)

                    self.logger.info("Insert completely.")

            except Exception as e:
                self.logger.warning(e, exc_info=True)
                return False

        return True

    def getInspectFeatureByBbox(self, schema, layer, insData, stdStruct, nfIdList):
        self.logger.info("Insert {} inspect features data using WFS".format(layer))

        filterXml = '<?xml version="1.0" encoding="utf-8"?>' \
                    '<wfs:GetFeature service="WFS" version="1.1.0" outputFormat="application/json" ' \
                    'xmlns:wfs="http://www.opengis.net/wfs" ' \
                    'xmlns:ogc="http://www.opengis.net/ogc" ' \
                    'xmlns:gml="http://www.opengis.net/gml">' \
                    '<wfs:Query typeName="{workspace}:{layer}">' \
                    '{column}' \
                    '<ogc:Filter>' \
                    '<ogc:And>' \
                    '<ogc:BBOX>' \
                    '<ogc:PropertyName>object_gt</ogc:PropertyName>' \
                    '<gml:Envelope srsDimension="2" srsName="urn:x-ogc:def:crs:EPSG:5179">' \
                    '<gml:lowerCorner>{minY} {minX}</gml:lowerCorner>' \
                    '<gml:upperCorner>{maxY} {maxX}</gml:upperCorner>' \
                    '</gml:Envelope>' \
                    '</ogc:BBOX>' \
                    '{nfIdFilter}' \
                    '</ogc:And>' \
                    '</ogc:Filter>' \
                    '</wfs:Query>' \
                    '</wfs:GetFeature>'

        columnXml = '<wfs:PropertyName>object_gt</wfs:PropertyName>' \
                    '<wfs:PropertyName>obchg_se</wfs:PropertyName>' \
                    '<wfs:PropertyName>obchg_dt</wfs:PropertyName>' \
                    '<wfs:PropertyName>rsreg_dt</wfs:PropertyName>' \
                    '<wfs:PropertyName>error_dc</wfs:PropertyName>' \
                    '<wfs:PropertyName>bsnm_error_dc</wfs:PropertyName>'

        struct = stdStruct[layer]
        colList = struct['col_list']
        for colNm in colList:
            columnXml += '<wfs:PropertyName>{colNm}</wfs:PropertyName>'.format(colNm=colNm.lower())

        nfIdFilter = str()
        for nfId in nfIdList:
            nfIdFilter += '<ogc:PropertyIsNotEqualTo matchCase="true">' \
                            '<ogc:PropertyName>nf_id</ogc:PropertyName>' \
                            '<ogc:Literal>{nfId}</ogc:Literal>' \
                            '</ogc:PropertyIsNotEqualTo>'.format(nfId=nfId)

        jsonFilePath = os.path.join(self.JSON_PATH, "{}_base.json".format(layer))

        if os.path.exists(jsonFilePath):
            os.remove(jsonFilePath)

        try:
            # wfsUrl = self.__server_url + "kgi/wfs.do"
            xmlData = filterXml.format(workspace=self.WORKSPACE, layer=layer, column=columnXml,
                                       minX=insData['min_x'], minY=insData['min_y'],
                                       maxX=insData['max_x'], maxY=insData['max_y'],
                                       nfIdFilter=nfIdFilter)
            wfsUrl = self.__geoserver_url + "wfs"
            request = urllib2.Request(wfsUrl, xmlData, {'Content-Type': 'application/xml'})
            response = urllib2.urlopen(request)

            resData = response.read()

            with codecs.open(os.path.join(jsonFilePath), 'wb', encoding='utf-8') as json_file:
                json.dump(json.loads(resData), json_file, ensure_ascii=False, indent=4)

            if os.path.exists(jsonFilePath):
                commandList = ['ogr2ogr', '-update', '-append','-a_srs', 'EPSG:5179', '-f', 'PostgreSQL',
                               self.__pgConnectInfo + ' active_schema={schema}'.format(schema=schema), jsonFilePath,
                               '-lco', 'PRECISION=NO', '-nln', '{layer}_base'.format(layer=layer),
                               '-nlt', 'PROMOTE_TO_MULTI']
                self.logger.debug("Command : {cmd}".format(cmd=' '.join(commandList)))
                threadExecuteCmd(commandList)

                self.logger.info("Insert {} completely.".format(layer))

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return False

        return True

    def getInspectFeatureTms(self, schema, layer, insData, stdStruct):
        self.logger.info("Insert {} inspect features data using WFS".format(layer))

        filterXml = '<?xml version="1.0" encoding="utf-8"?>' \
                    '<wfs:GetFeature service="WFS" version="1.1.0" outputFormat="application/json" ' \
                    'xmlns:wfs="http://www.opengis.net/wfs" ' \
                    'xmlns:ogc="http://www.opengis.net/ogc" ' \
                    'xmlns:gml="http://www.opengis.net/gml">' \
                    '<wfs:Query typeName="{workspace}:{layer}_tmsres">' \
                    '{column}' \
                    '<ogc:Filter>' \
                    '<ogc:And>' \
                    '<ogc:BBOX>' \
                    '<ogc:PropertyName>object_gt</ogc:PropertyName>' \
                    '<gml:Envelope srsDimension="2" srsName="urn:x-ogc:def:crs:EPSG:5179">' \
                    '<gml:lowerCorner>{minY} {minX}</gml:lowerCorner>' \
                    '<gml:upperCorner>{maxY} {maxX}</gml:upperCorner>' \
                    '</gml:Envelope>' \
                    '</ogc:BBOX>' \
                    '<ogc:PropertyIsGreaterThanOrEqualTo>' \
                    '<ogc:PropertyName>obchg_dt</ogc:PropertyName>' \
                    '<ogc:Function name="dateParse">' \
                    '<ogc:Literal>yyyy-MM-dd</ogc:Literal>' \
                    '<ogc:Literal>{obchg_dt}</ogc:Literal>' \
                    '</ogc:Function>' \
                    '</ogc:PropertyIsGreaterThanOrEqualTo>' \
                    '</ogc:And>' \
                    '</ogc:Filter>' \
                    '</wfs:Query>' \
                    '</wfs:GetFeature>'

        columnXml = '<wfs:PropertyName>object_gt</wfs:PropertyName>' \
                    '<wfs:PropertyName>obchg_se</wfs:PropertyName>' \
                    '<wfs:PropertyName>obchg_dt</wfs:PropertyName>' \
                    '<wfs:PropertyName>rsreg_dt</wfs:PropertyName>'

        struct = stdStruct[layer]
        colList = struct['col_list']
        for colNm in colList:
            columnXml += '<wfs:PropertyName>{colNm}</wfs:PropertyName>'.format(colNm=colNm.lower())

        jsonFilePath = os.path.join(self.JSON_PATH, "{}_tmsres.json".format(layer))

        if os.path.exists(jsonFilePath):
            os.remove(jsonFilePath)

        try:
            xmlData = filterXml.format(workspace=self.WORKSPACE, layer=layer, column=columnXml,
                                       minX=insData['min_x'], minY=insData['min_y'],
                                       maxX=insData['max_x'], maxY=insData['max_y'],
                                       obchg_dt=insData['obchg_dt'])
            # wfsUrl = self.__server_url + "kgi/wfs.do"
            wfsUrl = self.__geoserver_url + "wfs"
            request = urllib2.Request(wfsUrl, xmlData, {'Content-Type': 'application/xml'})
            response = urllib2.urlopen(request)

            resData = response.read()

            with codecs.open(os.path.join(jsonFilePath), 'wb', encoding='utf-8') as json_file:
                json.dump(json.loads(resData), json_file, ensure_ascii=False, indent=4)

            if os.path.exists(jsonFilePath):
                commandList = ['ogr2ogr', '-update', '-append','-a_srs', 'EPSG:5179', '-f', 'PostgreSQL',
                               self.__pgConnectInfo + ' active_schema={schema}'.format(schema=schema), jsonFilePath,
                               '-lco', 'PRECISION=NO', '-nln', '{layer}_tmsres'.format(layer=layer),
                               '-nlt', 'PROMOTE_TO_MULTI']
                self.logger.debug("Command : {cmd}".format(cmd=' '.join(commandList)))
                threadExecuteCmd(commandList)

                self.logger.info("Insert {} completely.".format(layer))

        except Exception as e:
            self.logger.warning(e, exc_info=True)
            return False

        return True

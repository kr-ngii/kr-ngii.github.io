# -*- coding: utf-8 -*-
import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import os, io
import threading, time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking query
class DBThread(threading.Thread):
    def __init__(self, cursor, query, param):
        self.cursor = cursor
        self.query = query
        self.param = param
        threading.Thread.__init__(self)

    def run(self):
        if self.param is None:
            self.cursor.execute(self.query)
        else:
            self.cursor.execute(self.query, self.param)

        return


def threadExecuteSql(cursor, sql, param=None):
    dbt = DBThread(cursor, sql, param)
    dbt.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


def initDatbase(host, port, dbname, user, password):
    postgres_postgres_conn_str = u"host='{}' port='{}' dbname ='postgres' user='{}' password='{}'".format(host, port, user, password)
    postgres_ngii_conn_str = u"host='{}' port='{}' dbname ='{}' user='{}' password='{}'".format(host, port, dbname, user, password)

    sql_espg_file = os.path.join(os.path.dirname(__file__), '../sql/postgis_korea_epsg_towgs84.sql')
    sql_init_file = os.path.join(os.path.dirname(__file__), '../sql/standard_insert.sql')

    # Read SQL files
    try:
        with io.open(sql_espg_file, 'r', encoding='utf8') as f:
            sql_espg = f.read()
        with io.open(sql_init_file, 'r', encoding='utf8') as f:
            sql_init = f.read()
    except:
        return "SQL File read error"

    try:
        # Make the ngii login role and database
        try:
            conn = psycopg2.connect(postgres_postgres_conn_str)
            conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        except:
            return u"error database connection: {}".format(postgres_postgres_conn_str)

        curs = conn.cursor()
        curs.execute(u"SELECT datname FROM pg_database WHERE datname = '{}'".format(dbname))
        results = curs.fetchall()
        if len(results) != 1:
            sql = u"CREATE DATABASE {} WITH ENCODING='UTF8' TEMPLATE=template0 LC_COLLATE='C' LC_CTYPE='C' CONNECTION LIMIT=-1".format(dbname)
            logger.debug(sql)
            curs.execute(sql)
        conn.close()

        # Setup extension and EPSG
        try:
            conn = psycopg2.connect(postgres_ngii_conn_str)
            conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        except:
            return u"error database connection: {}".format(postgres_ngii_conn_str)

        curs = conn.cursor()
        curs.execute("SELECT extname FROM pg_extension WHERE extname = 'postgis'")
        results = curs.fetchall()
        if len(results) != 1:
            sql = u"CREATE EXTENSION postgis"
            logger.debug(sql)
            # curs.execute(sql)
            threadExecuteSql(curs, sql)
            curs.execute(sql_espg)

        curs.execute("select schema_name from information_schema.schemata where schema_name = 'qiresult'")

        results = curs.fetchall()

        if len(results) != 1:
            # curs.execute(sql_init)
            threadExecuteSql(curs, sql_init)

        conn.close()
    except Exception as e:
        return e

    return None

# -*- coding: utf-8 -*-
import os

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic

from qgis.core import *

from ui.LogicalTemporalInspect import Ui_LogicalTemporalInspect
from logicalInspect.LogicalInspector import LogicalInspector
# from InspectProgress import InspectProgress

import logging.handlers
logger = logging.getLogger('ngiiPlugin')

# class SelectInspectData(QDialog, Ui_SelectInspectData):
FORM_CLASS, _ = uic.loadUiType(os.path.join(os.path.dirname(__file__), 'ui/LogicalTemporalInspect.ui'))


# class LogicalTemporalInspect(QDockWidget, Ui_LogicalTemporalInspect):
class LogicalTemporalInspect(QDockWidget, FORM_CLASS):

    STANDARD_SCHEMA = 'qiresult'

    tmpShape = None  # type: QgsVectorLayer

    inspectSchema = None
    standardLayerStructure = None
    inspectStd = None

    errImgLayer = None
    crrLayer = None
    refLayerList = list()

    def __init__(self, dock, inspectorNm):
        super(LogicalTemporalInspect, self).__init__(dock.parent)
        self.setupUi(self)

        self.__initTree()

        self.logger = logger

        self.iface = dock.iface
        self.parent = dock.parent
        self.crrWidget = dock
        self.inspectorNm = inspectorNm

        self.logicalInspector = LogicalInspector(self)
        self.inspectSchema = self.logicalInspector.dbUtil.INS_SCHEMA

        self.__connectFn()
        self.setDefaultProject()

        self.btnStartInspect.hide()

    def closeEvent(self, event):
        self.iface.removeDockWidget(self.crrWidget.inspectWidget)

    def __connectFn(self):
        # self.btnStartInspect.clicked.connect(self.startInspect)
        self.btnThematicInspect.clicked.connect(self.crrWidget.showThematicInspect)
        self.treeResult.doubleClicked.connect(self.loadImg)
        self.treeResult.clicked.connect(self.setFeatureInfo)

    def __initTree(self):
        self.treeResult.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeResult.setHeaderHidden(True)
        self.treeModel = QStandardItemModel()
        self.treeModel.setColumnCount(1)
        # self.treeModel.setHorizontalHeaderLabels([u"검사 결과"])

        self.treeResult.setModel(self.treeModel)

        self.txtFeatureId.setText("")
        self.txtErrContent.setText("")
        self.labelErrImg.setText("")
        # self.txtPassGb.setText("")
        # self.txtPassGb.setTitle("")
        self.txtStatus.setText(u"논리일관성 검사 시작중...")
        self.progressBar.setValue(0)
        self.progressBar.setMaximum(100)

    def closeDB(self):
        self.logicalInspector.dbUtil.closeDB()

    def setDefaultProject(self):
        self.iface.newProject()
        self.iface.mapCanvas().setCanvasColor(Qt.black)

    def startInspect(self):
        self.setDefaultProject()

        # self.checkStandard()

        # 이미지 폴더 백업
        imgPath = os.path.join(self.logicalInspector.imgUtil.IMG_SAVE_PATH, self.inspectSchema)
        if os.path.exists(imgPath):
            bakCount = 1
            while True:
                imgBakPath = os.path.join(self.logicalInspector.imgUtil.IMG_SAVE_PATH,
                                          "{}_bak_{}".format(self.inspectSchema, bakCount))
                if not os.path.exists(imgBakPath):
                    os.rename(imgPath, imgBakPath)
                    break

                bakCount += 1

        layerList = self.logicalInspector.dbUtil.selectTableList(self.inspectSchema)
        layerListLen = len(layerList)

        if layerListLen <= 0:
            QMessageBox.information(self.parent, u'검사 대상 정보', u'검사할 대상이 없습니다.')

        self.progressBar.setMaximum(0)
        self.progressBar.show()

        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        self.standardLayerStructure = self.logicalInspector.dbUtil.selectStandardLayerStructure()
        self.inspectStd = self.logicalInspector.dbUtil.selectInspectStandard(self.logicalInspector.B_CODE)

        loadResult = self.__loadData(layerList)
        if not loadResult:
            QMessageBox.warning(self.parent, u'검사 대상 오류', u'검사 대상을 불러오는데 실패하였습니다.')
            self.progressBar.setMaximum(100)
            return

        self.logicalInspector.inspectData(self.progressBar, self.txtStatus, self.inspectorNm, self.inspectSchema,
                                          layerList, self.standardLayerStructure, self.inspectStd)

        if self.tmpShape:
            shpPath = os.path.join(self.logicalInspector.imgUtil.IMG_SAVE_PATH, self.inspectSchema, 'err_index.shp')
            QgsVectorFileWriter.writeAsVectorFormat(self.tmpShape, shpPath, "utf-8", None, "ESRI Shapefile")
            del self.tmpShape
            self.tmpShape = None

        # self.inspectProgress.setFinish()
        # self.inspectProgress.btnOk.setDisabled(False)
        self.progressBar.setMaximum(100)
        self.progressBar.hide()

        self.btnStartInspect.setEnabled(False)

        self.treeResult.scrollToTop()
        self.logger.info(u"Complete to inspect logic consistency")

        self.txtStatus.setText(u"논리/시간 검사완료.")
        QMessageBox.information(self.iface.mainWindow(), u"검사완료", u"논리일관성/시간적품질 검사가 완료되었습니다.")

    def checkStandard(self):
        # check schema
        self.logger.debug("Check to exist schema")
        result = False
        dbSchemaList = self.logicalInspector.dbUtil.selectSchemaList()
        if self.STANDARD_SCHEMA not in dbSchemaList:
            self.logicalInspector.dbUtil.createSchema(self.STANDARD_SCHEMA)

        # check table
        tableList = self.logicalInspector.dbUtil.selectTableList(self.STANDARD_SCHEMA)
        if self.STANDARD_SCHEMA not in tableList:
            pass

        # check data
        createDateDict = self.logicalInspector.dbUtil.selectStandardCreateDate()

        # TODO: 오류 발생 시 처리 추가
        comCodeDictList = self.logicalInspector.restapiUtil.getCodeList(createDateDict["com_code"])
        if len(comCodeDictList) > 0:
            deleteResult, deleteErrMsg = self.logicalInspector.dbUtil.deleteComCode()

            if deleteResult:
                insertResult, insertErrMsg = self.logicalInspector.dbUtil.insertComCode(comCodeDictList)
            else:
                return result

        standardDictList = self.logicalInspector.restapiUtil.getStandardList(createDateDict["ins_standard"])
        if len(standardDictList) > 0:
            deleteResult, deleteErrMsg = self.logicalInspector.dbUtil.deleteStandard()

            if deleteResult:
                insertResult, insertErrMsg = self.logicalInspector.dbUtil.insertStandard(standardDictList)
            else:
                return result

        layerDictList = self.logicalInspector.restapiUtil.getLayerList(createDateDict["std_layer"])
        if len(layerDictList) > 0:
            deleteResult, deleteErrMsg = self.logicalInspector.dbUtil.deleteLayer()

            if deleteResult:
                insertResult, insertErrMsg = self.logicalInspector.dbUtil.insertLayer(layerDictList)
            else:
                return result

        layerStructDictList = self.logicalInspector.restapiUtil.getLayerStructList(createDateDict["std_layer"])
        if len(layerStructDictList) > 0:
            deleteResult, deleteErrMsg = self.logicalInspector.dbUtil.deleteLayerStruct()

            if deleteResult:
                insertResult, insertErrMsg = self.logicalInspector.dbUtil.insertLayerStruct(layerStructDictList)
            else:
                return result

        codezipList = self.logicalInspector.restapiUtil.getCodezipList(createDateDict["std_layer"])
        if len(codezipList) > 0:
            deleteResult, deleteErrMsg = self.logicalInspector.dbUtil.deleteCodezip()

            if deleteResult:
                insertResult, insertErrMsg = self.logicalInspector.dbUtil.insertCodezip(codezipList)
            else:
                return result

    @staticmethod
    def convertStr(keys):
        result = dict()

        for val in keys:
            tmp_str = ''
            for s in val:
                if s.isupper():
                    tmp_str += '_'
                    tmp_str += s.lower()
                else:
                    tmp_str += s

            result[tmp_str] = val

        return result

    def __loadData(self, layerList):
        result = False

        pointLayer = list()
        linestringLayer = list()
        polygonLayer = list()

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()  # type: QStringList

        try:
            # self.inspectProgress.setInfo(u"검사 대상 가져오는 중 ... ", countSkip=True)
            self.txtStatus.setText(u"검사 대상 가져오는 중 ... ")

            layerGroupList = self.standardLayerStructure['layerGroup']
            dbInfo = self.logicalInspector.dbUtil.getDbInfo()
            groupRoot = QgsProject.instance().layerTreeRoot()

            for layerGroup in layerGroupList:
                self.iface.legendInterface().addGroup(layerGroup.decode("UTF-8"))

            stdLayerNmList = self.standardLayerStructure.keys()
            for layerNm in layerList:
                if layerNm not in stdLayerNmList:
                    continue

                uri = QgsDataSourceURI()
                uri.setConnection(dbInfo["host"], dbInfo["port"], dbInfo["dbname"],
                                  dbInfo["user"], dbInfo["password"])
                uri.setDataSource(self.inspectSchema, layerNm, "wkb_geometry", "", "id")
                ngdLayer = QgsVectorLayer(uri.uri(), layerNm, "postgres")

                self.logicalInspector.imgUtil.setDefaultSymbol(ngdLayer)

                group = groupRoot.findGroup(self.standardLayerStructure[layerNm]['layer_package'].decode("UTF-8"))

                if group:
                    QgsMapLayerRegistry.instance().addMapLayer(ngdLayer, False)

                    group.addLayer(ngdLayer)

                    legend = self.iface.legendInterface()
                    legend.setLayerVisible(ngdLayer, False)

                geometryType = ngdLayer.geometryType()
                ngdLayerId = ngdLayer.id()

                if geometryType == 0:
                    pointLayer.append(ngdLayerId)
                    # layerOrder.insert(0, ngdLayer.id())
                elif geometryType == 1:
                    linestringLayer.append(ngdLayerId)
                else:
                    polygonLayer.append(ngdLayerId)
                    # layerOrder.append(ngdLayer.id())

            groupList = groupRoot.children()
            for group in groupList:
                loadedLayerList = group.children()

                for layer in loadedLayerList:
                    layer.setExpanded(False)

            result = True

        except Exception as e:
            self.logger.debug(e)

        layerOrder += pointLayer
        layerOrder += linestringLayer
        layerOrder += polygonLayer

        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)
        self.iface.layerTreeCanvasBridge().setHasCustomLayerOrder(True)

        return result

    # 결과 tree 생성
    def addTree(self, inspectionNm, layerNm, inspectCode, cid, imgPath, inspectResult, refLayer=None):
        if inspectionNm == 'logic':
            inspectionNm = u'논리일관성'
        else:
            inspectionNm = u'시간정확도'

        mCodeList = self.inspectStd.keys()
        for mCode in mCodeList:
            if inspectCode in self.inspectStd[mCode].keys():
                inspectCode = self.inspectStd[mCode][inspectCode]["t_code_nm"].decode("UTF-8")

        rootNodeRes = self.treeModel.findItems(inspectionNm)

        if len(rootNodeRes) > 0:
            rootNode = rootNodeRes[0]
        else:
            rootNode = QStandardItem(inspectionNm)
            rootNode.setEditable(False)
            rootNode.setSelectable(False)

            self.treeModel.appendRow([rootNode])

        rootIdx = self.treeModel.indexFromItem(rootNode)
        self.treeResult.expand(rootIdx)

        rootNodeRows = rootNode.rowCount()
        layerNode = None

        layerNmKo = self.standardLayerStructure[layerNm]["layer_nm"].decode("UTF-8")

        for idx in range(0, rootNodeRows):
            tmpNode = rootNode.child(idx)
            if tmpNode.text() == layerNmKo:
                layerNode = tmpNode
                break

        if not layerNode:
            layerNode = QStandardItem(layerNmKo)
            layerNode.setEditable(False)
            layerNode.setSelectable(False)

            rootNode.appendRow([layerNode])

        layerIdx = self.treeModel.indexFromItem(layerNode)
        self.treeResult.expand(layerIdx)

        layerNodeRows = layerNode.rowCount()
        inspectCodeNode = None

        for idx in range(0, layerNodeRows):
            tmpNode = layerNode.child(idx)
            if tmpNode.text() == inspectCode:
                inspectCodeNode = tmpNode
                break

        if not inspectCodeNode:
            inspectCodeNode = QStandardItem(inspectCode)
            inspectCodeNode.setEditable(False)
            inspectCodeNode.setSelectable(False)

            layerNode.appendRow([inspectCodeNode])

        inspectCodeNodeRows = inspectCodeNode.rowCount()
        cidNodeList = list()

        for idx in range(0, inspectCodeNodeRows):
            tmpNode = inspectCodeNode.child(idx)
            if tmpNode.text() == cid or tmpNode.text().startswith("{}_".format(cid)):
                cidNodeList.append(tmpNode)

        if len(cidNodeList) > 0:
            cid = "{cid}_{idx}".format(cid=cid, idx=len(cidNodeList))

        cidNode = QStandardItem(cid)
        cidNode.setEditable(False)

        rasterInfo = {
            "layer": layerNm,
            "refLayer": refLayer,
            "feature_id": cid,
            "image_path": imgPath,
            "inspect_code": inspectCode,
            "passGb": inspectResult
        }
        cidNode.setData(rasterInfo)

        inspectCodeNode.appendRow([cidNode])

        self.__writeXml(imgPath)

        self.treeResult.scrollToBottom()

    def addShapeIdx(self, layer, inspectCode, imgPath, imgExtent):
        if not self.tmpShape:
            self.tmpShape = QgsVectorLayer("Polygon?crs=epsg:5179&field=layer_nm:string&field=err_nm:string"
                                           "&field=err_cd:string&field=img_nm:string&index=yes", "index", "memory")

        layerProvider = self.tmpShape.dataProvider()

        feat = QgsFeature(self.tmpShape.pendingFields())
        feat.setGeometry(QgsGeometry().fromRect(QgsRectangle(float(imgExtent[0]), float(imgExtent[1]),
                                                             float(imgExtent[2]), float(imgExtent[3]))))
        feat.setAttribute('layer_nm', layer)

        errNm = ''
        mCodeList = self.inspectStd.keys()
        for mCode in mCodeList:
            if inspectCode in self.inspectStd[mCode].keys():
                errNm = self.inspectStd[mCode][inspectCode]["t_code_nm"].decode("UTF-8")

        feat.setAttribute('err_nm', errNm)
        feat.setAttribute('err_cd', inspectCode)
        feat.setAttribute('img_nm', os.path.basename(imgPath))

        layerProvider.addFeatures([feat])

    def loadImg(self, index):

        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        if self.errImgLayer:
            QgsMapLayerRegistry.instance().removeMapLayer(self.errImgLayer)

        rasterInfo = selData.data()

        imgPath = rasterInfo["image_path"]
        # self.__writeXml(imgPath)

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()
        self.errImgLayer = QgsRasterLayer(imgPath, os.path.splitext(os.path.basename(imgPath))[0])
        # 이미지를 반투명하에 캔버스에 추가
        self.errImgLayer.renderer().setOpacity(0.5)

        QgsMapLayerRegistry.instance().addMapLayer(self.errImgLayer, False)

        groupRoot = QgsProject.instance().layerTreeRoot()
        groupRoot.insertLayer(0, self.errImgLayer)

        layerOrder.insert(0, self.errImgLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        legend = self.iface.legendInterface()
        layer = QgsMapLayerRegistry.instance().mapLayersByName(rasterInfo["layer"])[0]

        if not self.crrLayer:
            self.crrLayer = layer
            legend.setLayerVisible(layer, True)

        else:
            if self.crrLayer.name() != layer.name():
                legend.setLayerVisible(self.crrLayer, False)
                legend.setLayerVisible(layer, True)

                self.crrLayer = layer

        while len(self.refLayerList) != 0:
            refLayer = self.refLayerList.pop()
            if refLayer.name() == self.crrLayer.name():
                continue

            legend.setLayerVisible(refLayer, False)

        refLayerStr = rasterInfo["refLayer"]
        if refLayerStr:
            refLayerList = refLayerStr.split(",")

            for refLayerNm in refLayerList:
                if refLayerNm == self.crrLayer.name():
                    continue

                refLayer = QgsMapLayerRegistry.instance().mapLayersByName(refLayerNm)[0]
                legend.setLayerVisible(refLayer, True)
                self.refLayerList.append(refLayer)

        imgExtent = self.errImgLayer.extent()
        crrCrs = self.iface.mapCanvas().mapRenderer().destinationCrs().authid()

        if crrCrs != 'EPSG:5179':
            extentGeom = QgsGeometry.fromRect(imgExtent)
            sourceCrs = QgsCoordinateReferenceSystem("EPSG:5179")
            destCrs = QgsCoordinateReferenceSystem(crrCrs)
            tr = QgsCoordinateTransform(sourceCrs, destCrs)
            extentGeom.transform(tr)
            imgExtent = extentGeom.boundingBox()

        self.iface.mapCanvas().setExtent(imgExtent)
        self.iface.mapCanvas().refresh()

    @staticmethod
    def __writeXml(imgPath):
        baseNm = os.path.splitext(imgPath)[0]
        worldFile = "{}.pgw".format(baseNm)
        xmlFile = "{}.png.aux.xml".format(baseNm)

        if os.path.exists(xmlFile):
            return

        xmlTemplate = """
            <PAMDataset>
              <SRS>PROJCS["Korea 2000 / Unified CS",GEOGCS["Korea 2000",DATUM["Geocentric_datum_of_Korea",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],TOWGS84[0,0,0,0,0,0,0],AUTHORITY["EPSG","6737"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4737"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",38],PARAMETER["central_meridian",127.5],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",1000000],PARAMETER["false_northing",2000000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AUTHORITY["EPSG","5179"]]</SRS>
              <GeoTransform> {}, {}, {}, {}, {}, {} </GeoTransform>
              <Metadata domain="IMAGE_STRUCTURE">
                <MDI key="INTERLEAVE">PIXEL</MDI>
              </Metadata>
              <Metadata>
                <MDI key="AREA_OR_POINT">Area</MDI>
              </Metadata>
            </PAMDataset>
        """
        with open(worldFile, 'rb') as f:
            data = f.readlines()

        with open(xmlFile, 'wb') as f:
            f.write(xmlTemplate.format(data[4], data[0], data[1], data[5], data[2], data[3]))

    def setFeatureInfo(self, index):
        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        rasterInfo = selData.data()

        self.txtFeatureId.setText(selData.text())
        self.txtErrContent.setText(rasterInfo["inspect_code"])
        # self.txtPassGb.setText(rasterInfo["passGb"])
        # self.txtPassGb.setTitle(rasterInfo["passGb"])

        errImg = QPixmap(rasterInfo["image_path"])
        errImgWidth = errImg.width()
        errImgHeight = errImg.height()

        labelWidth = self.labelErrImg.width()
        labelHeight = self.labelErrImg.height()

        if errImgWidth >= errImgHeight:
            resizeImg = errImg.scaledToWidth(labelWidth)
            if resizeImg.height() > labelHeight:
                resizeImg = resizeImg.scaledToHeight(labelHeight)
        else:
            resizeImg = errImg.scaledToHeight(labelHeight)
            if resizeImg.width() > labelWidth:
                resizeImg = resizeImg.scaledToWidth(labelWidth)

        self.labelErrImg.setPixmap(resizeImg)

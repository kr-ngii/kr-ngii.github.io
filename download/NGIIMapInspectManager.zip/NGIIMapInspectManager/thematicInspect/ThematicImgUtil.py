# -*- coding: utf-8 -*-
import os
from qgis.core import *

from ..util.ImgUtil import ImgUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ThematicImgUtil(ImgUtil):

    def __init__(self, dock):
        ImgUtil.__init__(self, dock.iface, dock)
        self.logger = logger

    def saveImg(self, schema, layer, inspect_code, id):
        expr = '"nf_id"=\'{id}\''.format(id=id)
        sel_feature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

        feature_geometry = [i.geometry() for i in sel_feature]

        if len(feature_geometry) <= 0:
            self.logger.debug("{inspect_code} not selected cid : {cid}".format(inspect_code=inspect_code,
                                                                               cid=id))
            return False, None

        bbox = feature_geometry[0].boundingBox()
        self.iface.mapCanvas().setExtent(bbox)
        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        crrScale = self.iface.mapCanvas().scale()

        if crrScale < 500:
            self.iface.mapCanvas().zoomScale(500.0)
        else:
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)

        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        imgPath = os.path.join(self.IMG_SAVE_PATH, schema, layer.name(), inspect_code, 'err_{id}.png'.format(id=id))
        self.makePath(os.path.dirname(imgPath))
        self.iface.mapCanvas().saveAsImage(imgPath)
        imgExtent = self.iface.mapCanvas().extent()
        imgExtentStr = [
            str(round(imgExtent.xMinimum(), 2)),
            str(round(imgExtent.yMinimum(), 2)),
            str(round(imgExtent.xMaximum(), 2)),
            str(round(imgExtent.yMaximum(), 2))
        ]

        return True, {
            "imgPath": imgPath,
            "imgExtent": ', '.join(imgExtentStr)
        }

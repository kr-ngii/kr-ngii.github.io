# -*- coding: utf-8 -*-
import os
from qgis.core import *

from ..util.ImgUtil import ImgUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ThematicImgUtil(ImgUtil):

    def __init__(self, dock):
        ImgUtil.__init__(self, dock.iface, dock)
        self.logger = logger

    def saveImg(self, schema, layer, inspectCode, cid):
        imgData = dict()

        expr = '"change_info_id"=\'{cid}\''.format(cid=cid)
        sel_feature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

        feature_geometry = [i.geometry() for i in sel_feature]

        if len(feature_geometry) <= 0:
            self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
            return False, None

        bbox = feature_geometry[0].boundingBox()
        self.iface.mapCanvas().setExtent(bbox)
        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        crrScale = self.iface.mapCanvas().scale()

        if crrScale < 500:
            self.iface.mapCanvas().zoomScale(500.0)
        else:
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)

        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        imgPath = os.path.join(self.IMG_SAVE_PATH, schema, layer.name(), inspectCode,
                               'err_{cid}.png'.format(cid=cid))
        self.makePath(os.path.dirname(imgPath))
        self.iface.mapCanvas().saveAsImage(imgPath)

        tnImgPath = os.path.join(self.IMG_SAVE_PATH, schema, layer.name(), inspectCode,
                                 'err_{cid}_tn.png'.format(cid=cid))
        thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

        if not thumbnailResult:
            return False, None

        imgData["imgPath"] = imgPath
        imgData["imgTnPath"] = tnImgPath
        imgData["imgExtent"] = self.iface.mapCanvas().extent()

        return True, imgData

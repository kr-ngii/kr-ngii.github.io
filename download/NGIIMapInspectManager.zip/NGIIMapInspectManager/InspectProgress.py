# -*- coding: utf-8 -*-

from PyQt4 import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *

from ui.InspectProgress import Ui_progress

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class InspectProgress(QDialog, Ui_progress):

    subProgressCount = 0

    def __init__(self, iface, inspectNm, parent=None):
        super(InspectProgress, self).__init__(parent)
        self.setupUi(self)

        self.logger = logger

        self.iface = iface
        self.parent = parent
        self.inspectNm = inspectNm

        self.labelInspectInfo.setText(self.inspectNm)

        self.__connectFn()

    def __connectFn(self):
        self.btnOk.clicked.connect(self.close)

    def setInfo(self, infoTxt):
        self.labelInspectInfo.setText("%s" % (infoTxt))
        self.progressInspect.setValue(100)
        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

    def setFinish(self):
        self.labelInspectInfo.setText(u"완료")
        self.progressInspect.setValue(100)
        QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

    def setSize(self, value):
        self.progressInspect.setMaximum(value)
        self.progressInspect.setMinimum(value)
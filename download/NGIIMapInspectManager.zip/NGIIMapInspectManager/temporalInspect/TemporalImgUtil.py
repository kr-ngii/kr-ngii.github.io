# -*- coding: utf-8 -*-
import os
from qgis.core import *

from ..util.ImgUtil import ImgUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class TemporalImgUtil(ImgUtil):

    def __init__(self, dock, dbUtil):
        ImgUtil.__init__(self, dock.iface, dock)
        self.logger = logger
        self.dbUtil = dbUtil

    def saveImg(self, schemaNm, layerNm, inspectCode, detailRes):
        layer = QgsMapLayerRegistry.instance().mapLayersByName(layerNm)[0]
        legend = self.iface.legendInterface()

        legend.setLayerVisible(layer, True)
        self.iface.mapCanvas().setExtent(layer.extent())
        self.iface.mapCanvas().zoomScale(1000.0)
        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        exprStr = '"change_info_id"=\'{cid}\''

        for res in detailRes:
            cid = res["cid"]

            expr = exprStr.format(cid=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            geomType = layer.wkbType()

            bbox = featureGeometry[0].boundingBox()
            if geomType == QGis.WKBMultiPoint or geomType == QGis.WKBPoint:
                centerPoint = bbox.center()
                self.iface.mapCanvas().setCenter(centerPoint)
                self.iface.mapCanvas().zoomScale(500.0)
            else:
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)

            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                   'err_{cid}.png'.format(cid=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            tnImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                     'err_{cid}_tn.png'.format(cid=cid))
            thumbnailResult = self.createThumbnail(imgPath, tnImgPath)

            if not thumbnailResult:
                return False, None

            resIdx = detailRes.index(res)

            detailRes[resIdx]["details"][0]["imgNm"] = os.path.basename(imgPath)

            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            with open(tnImgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["imgTn"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()

            detailRes[resIdx]["details"][0]["minX"] = round(imgExtent.xMinimum(), 2)
            detailRes[resIdx]["details"][0]["minY"] = round(imgExtent.yMinimum(), 2)
            detailRes[resIdx]["details"][0]["maxX"] = round(imgExtent.xMaximum(), 2)
            detailRes[resIdx]["details"][0]["maxY"] = round(imgExtent.yMaximum(), 2)

            self.dock.addTree('temporal', layer.name(), inspectCode, cid, imgPath, tnImgPath, res["details"][0], dict())
            self.dbUtil.insertErrIndex(schemaNm, layer.name(), res["cid"], inspectCode, os.path.basename(imgPath),
                                       imgExtent)

        self.setDefaultSymbol(layer)
        legend.setLayerVisible(layer, False)

        self.forceRefresh()

        return detailRes

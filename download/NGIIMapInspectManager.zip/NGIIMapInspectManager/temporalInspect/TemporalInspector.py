# -*- coding: utf-8 -*-
import os

from TemporalDBUtil import TemporalDBUtil
from TemporalImgUtil import TemporalImgUtil
from TemporalRestapiUtil import TemporalRestapiUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class TemporalInspector:
    B_CODE = "DTQ"  # 시간정확성

    M_CODE = "JTQ"

    S_CODE = {
        "validity": "TQTQTV01",  # 시간유효성
        "accuracy": "TQTQTM01",  # 시간측정정확도
        "consistency": "TQTQTC01",  # 시간일관성
    }

    txtStatus = None
    schemaNm = None
    standardLayerStructure = None
    insGroupId = str()

    def __init__(self, dock):
        self.logger = logger

        self.dbUtil = TemporalDBUtil()
        self.imgUtil = TemporalImgUtil(dock, self.dbUtil)
        self.restapiUtil = TemporalRestapiUtil()

        self.schemaNm = self.dbUtil.INSEPCT_SCHEMA

    def getInspectStandard(self):
        return self.dbUtil.selectInspectStandard(self.B_CODE)

    def completeInspect(self, insGroupId):
        return self.restapiUtil.completeInspect(self.B_CODE, insGroupId)

    def inspectData(self, txtStatus, layerList, insGroupId, standardLayerStructure, inspectStd):
        self.standardLayerStructure = standardLayerStructure  # type: dict
        self.insGroupId = insGroupId

        self.txtStatus = txtStatus

        inspectCodeList = inspectStd[self.M_CODE].keys()

        try:
            for layer in layerList:

                if layer not in self.standardLayerStructure.keys():
                    continue

                self.txtStatus.setText(u"{} 검사 시작".format(layer))

                # 시간유효성 검사
                inspectCode = self.S_CODE['validity']
                self.__inspectValidity(layer, inspectCode, inspectStd[self.M_CODE][inspectCode])

                # 시간측정정확성 검사
                inspectCode = self.S_CODE['accuracy']
                self.__inspectAccuracy(layer, inspectCode, inspectStd[self.M_CODE][inspectCode])

                # 시강일관성 검사
                inspectCode = self.S_CODE['consistency']
                self.__inspectConsistency(layer, inspectCode, inspectStd[self.M_CODE][inspectCode])

        except Exception as e:
            self.logger.warning(e, exc_info=True)

    def __inspectValidity(self, layer, inspectCode, inspectInfo):
        # 관리시스템
        codeNm = inspectInfo["t_code_nm"]

        self.txtStatus.setText(u"[{}]개념일관성/{}검사".format(layer, codeNm.decode("UTF-8")))

        self.saveResult(layer, inspectCode, list())

    def __inspectAccuracy(self, layer, inspectCode, inspectInfo):
        codeNm = inspectInfo["t_code_nm"]

        self.txtStatus.setText(u"[{}]개념일관성/{}검사".format(layer, codeNm.decode("UTF-8")))

        resTemporalAccuracy = self.dbUtil.selectTemporalAccuracy(self.schemaNm, layer)

        if len(resTemporalAccuracy) > 0:
            resTemporalAccuracy = self.imgUtil.saveImg(self.schemaNm, layer, inspectCode, resTemporalAccuracy)

        self.saveResult(layer, inspectCode, resTemporalAccuracy)

    def __inspectConsistency(self, layer, inspectCode, inspectInfo):
        codeNm = inspectInfo["t_code_nm"]

        self.txtStatus.setText(u"[{}]개념일관성/{}검사".format(layer, codeNm.decode("UTF-8")))

        # 변동 이력 조회 : 범위, 변동기준일
        insData = self.dbUtil.selectTmsInsData(self.schemaNm, layer)
        self.restapiUtil.getInspectFeatureTms(self.schemaNm, layer, insData, self.standardLayerStructure)

        tmsresTable = "{}_tmsres".format(layer)
        tmsresCount = self.dbUtil.selectFeatureCount(self.schemaNm, tmsresTable)

        resTemporalConsistency = list()

        if tmsresCount != 0:
            resTemporalConsistency = self.dbUtil.selectTemporalConsistency(self.schemaNm, layer, tmsresTable)

            if len(resTemporalConsistency) > 0:
                resTemporalAccuracy = self.imgUtil.saveImg(self.schemaNm, layer, inspectCode, resTemporalConsistency)

        self.saveResult(layer, inspectCode, resTemporalConsistency)

    def saveResult(self, table, inspectCode, res):
        insResult = {
            "result": [{
                "bCode": self.B_CODE,
                "insGroupId": self.insGroupId,
                "layerId": table.upper(),
                "insTCode": inspectCode,
                "errFeatureList": res
            }]
        }

        self.restapiUtil.saveResult(insResult)
# -*- coding: utf-8 -*-
import psycopg2
from psycopg2.sql import SQL, Identifier
import threading
import time
from qgis.core import QgsApplication
from PyQt4.QtCore import QEventLoop

from ..util.DBUtil import DBUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


# CLASS for multitasking query
class DBThread(threading.Thread):
    def __init__(self, cursor, query, param):
        self.cursor = cursor
        self.query = query
        self.param = param
        threading.Thread.__init__(self)

    def run(self):
        if self.param is None:
            self.cursor.execute(self.query)
        else:
            self.cursor.execute(self.query, self.param)

        return


def threadExecuteSql(cursor, sql, param=None):
    dbt = DBThread(cursor, sql, param)
    dbt.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class TemporalDBUtil(DBUtil):

    def __init__(self):
        DBUtil.__init__(self)
        self.logger = logger

    def closeDB(self):
        self.conn.close()

    def selectTemporalAccuracy(self, schema, table):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectTemporalAccuracy")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refNfId": "",
                                "refObchgDt": sqlResult[1],
                                "refObchgSe": sqlResult[2],
                                "resCode": "IVS004"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult

    def selectTemporalConsistency(self, schema, table, tmsresTable):
        selectResult = list()

        cur = self.getCursor()
        if not cur:
            raise psycopg2.DatabaseError

        try:
            selectSql = self.sqlStatement.get("SQL", "selectTemporalConsistency")
            self.logger.debug(cur.mogrify(SQL(selectSql).format(schema=Identifier(schema),
                                                                table=Identifier(table),
                                                                tmsresTable=Identifier(tmsresTable))))
            threadExecuteSql(cur, SQL(selectSql).format(schema=Identifier(schema),
                                                        table=Identifier(table),
                                                        tmsresTable=Identifier(tmsresTable)))

            sqlResults = cur.fetchall()

            for sqlResult in sqlResults:
                selectResult.append(
                    {
                        "cid": sqlResult[0],
                        "details": [
                            {
                                "refNfId": sqlResult[1],
                                "refObchgDt": sqlResult[2],
                                "refObchgSe": sqlResult[3],
                                "resCode": "IVS004"
                            }
                        ]
                    }
                )

        except Exception as e:
            self.logger.warning(e, exc_info=True)

        if cur:
            cur.close()

        return selectResult
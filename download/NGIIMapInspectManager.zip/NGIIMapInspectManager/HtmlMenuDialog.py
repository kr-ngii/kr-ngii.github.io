# -*- coding: utf-8 -*-
"""
/***************************************************************************
 HtmlMenuDialog
                                 A QGIS plugin
 Html Menu Test
                             -------------------
        begin                : 2018-02-21
        git sha              : $Format:%H$
        copyright            : (C) 2018 by BJ Jang / Gaia3D
        email                : jangbi882@gaia3d.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
import time
import json
import urllib2
import subprocess
import ConfigParser
import codecs
import threading
from  threading import Thread
import time

import logging.handlers
logger = logging.getLogger('ngiiPlugin')

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtWebKit import QWebView, QWebPage
from PyQt4 import QtGui, uic

from qgis import utils
from qgis.core import QgsApplication

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui', 'htmlMenuDialog.ui'))


# CLASS for multitasking
class CmdThread(Thread):
    __response = None

    def __init__(self, request):
        self.request = request
        Thread.__init__(self)

    def run(self):
        self.__response = urllib2.urlopen(self.request)

    def join(self, timeout=None):
        Thread.join(self, timeout)
        return self.__response

def threadExecuteRestapi(request):
    trd = CmdThread(request)
    trd.start()

    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)

    return trd.join()

class HtmlMenuDialog(QtGui.QDialog, FORM_CLASS):
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".", "properties", "connection.ini")
    GEOSTORY_DATA_CHECKER = os.path.join("C:\\NGII", "DataQualityCheck")
    INFCHECKER_PATH = "InfChecker"
    INFCHECKER_NAME = "Digital_Ortho_Inspection"
    LOCCHECKER_PATH = "LocChecker"
    LOCCHECKER_NAME = "Digital_Ortho_VRS"


    startUrl = None

    __apiHost = 'localhost'
    __apiPort = '8080'
    __server_url = "http://seoul.gaia3d.com:8989/kqiweb/"

    def __init__(self, iface, parent=None):
        super(HtmlMenuDialog, self).__init__(parent)

        self.iface = iface
        self.logger = logger

        self.setupUi(self)

        self._loadProperties()

        # 웹 브라우저 이벤트 발생하게 설정
        # https://stackoverflow.com/questions/5383032/qwebkit-linkclicked-signal-never-fires
        self.webView.page().setLinkDelegationPolicy(QWebPage.DelegateAllLinks)
        self.webView.history().setMaximumItemCount(0)
        self._connect_action()

    def _loadProperties(self):
        self.properties = ConfigParser.RawConfigParser()
        self.properties.read(self.PROPERTIES_FILE)

        # Api Server
        self.__apiHost = self.properties.get("geoserver", "host")
        self.__apiPort = self.properties.get("geoserver", "port")

        port = ""
        if self.__apiPort:
            port = ":{}".format(self.__apiPort)

        self.__server_url = "http://{url}{port}/kqiweb/".format(url=self.__apiHost, port=port)

    def _connect_action(self):
        self.connect(self.webView, SIGNAL("loadFinished(bool)"), self._on_loadFinish)
        self.connect(self.webView, SIGNAL("linkClicked(QUrl)"), self._on_linkClicked)

    def _on_loadFinish(self, result):
        if result:
            url = self.webView.url().toString()
            frame = self.webView.page().mainFrame()
            serviceUrl = self.__server_url
            frame.evaluateJavaScript('setServiceUrl("{serviceUrl}")'.format(serviceUrl=serviceUrl))

            if "login.html" in url:
                # 저장된 아이디 표시
                saveId = self.getName("ngiiSaveId")
                if saveId:
                    frame.evaluateJavaScript('loadId("{saveId}")'.format(saveId=saveId))

            elif "inspection.html" in url:
                # 로그인 사용자 표시
                sessId = self.getName("ngiiSessionId")
                frame.evaluateJavaScript('displayUserNm("{sessId}")'.format(sessId=sessId))

    def _on_linkClicked(self, qurl):
        pathUrl = qurl.toString()

        # idx 반환. 없으면 -1
        # url[3:] : 3부터 마지막까지
        # sharpPtr = url.find("#")

        if "#login" in pathUrl:
            self.login(pathUrl)

        elif "#logout" in pathUrl:
            self.logout(pathUrl)

        elif "#inspection" in pathUrl:
            self.execInspection(pathUrl)

        elif "#saveReport" in pathUrl:
            self.saveReport()

        elif "#excel" in pathUrl:
            self.excel()

    def setUrl(self, url):
        if url.startswith("http"):
            self.webView.load(QUrl(url))
        else:
            self.webView.load(QUrl.fromLocalFile(url))
        # self.editUrl.setText(url)

    def alert(self, text):
        msg = QMessageBox()
        msg.setWindowTitle(u"알림메시지")
        msg.setText(text)
        msg.exec_()

    def isValidSession(self):
        resUserInfo = ""
        sessId = self.getName("ngiiSessionId")
        
        if sessId:
            url = self.__server_url + "user/selectUserInfo.do"

            try:
                req = urllib2.Request(url, json.dumps({'sessId': sessId}), {'Content-Type': 'application/json'})
                response = urllib2.urlopen(req)

                resData = response.read()
                resJson = json.loads(resData)
                
                # 세션 정보 조회 시 오류
                if resJson["code"] != 200:
                    self.logger.warning(resJson["message"])
                    return False

                # 이미 종료된 세션이면
                if resJson['message'] is None or resJson['message'] == '':
                    self.setName("ngiiSessionId", "")

                # 세션이 유지되어 있으면
                else :
                    userInfo = resJson['message']

                    # checkUserIp
                    userIp = userInfo['userIp']
                    if userIp:
                        resUserInfo = userInfo

            except Exception as e:
                self.alert('error {e}'.format(e=e))

        return resUserInfo

    def getName(self, name):
        s = QSettings()
        val = s.value(name)
        return val

    def setName(self, name, val):
        s = QSettings()
        s.setValue(name, val)

    def login(self, pathUrl):
        frame = self.webView.page().mainFrame()
        resUserInfo = frame.evaluateJavaScript('login()')

        # 아이디 저장이 체크되어 있으면
        self.setName("ngiiSaveId", frame.evaluateJavaScript('saveId()'))

        # 세션 아이디가 있으면
        if resUserInfo:
            resSessionId = resUserInfo["sessionId"]
            resUserId = resUserInfo["userId"]

            # 세션 저장
            self.setName("ngiiSessionId", resSessionId)
            
            # 신규 객체 가져오기
            self.newFeatures(resUserId)
            # 로그인 성공
            self.movePage(pathUrl, "inspection.html")

    def logout(self, pathUrl):
        currSessId = self.getName("ngiiSessionId")

        frame = self.webView.page().mainFrame()
        resSessionId = frame.evaluateJavaScript('logout("{currSessId}")'.format(currSessId=currSessId))

        if not resSessionId:
            self.setName("ngiiSessionId", resSessionId)
            self.movePage(pathUrl, "login.html")

    def newFeatures(self, userId):
        params = dict()
        params["userId"] = userId
        url = self.__server_url + "kgi/insertNewFeatureInfo.do"
        frame = self.webView.page().mainFrame()

        try:
            frame.evaluateJavaScript('$("#progress").show();')
            req = urllib2.Request(url, json.dumps(params), {'Content-Type': 'application/json'})
            response = threadExecuteRestapi(req)

            resData = response.read()
            resJson = json.loads(resData)

            if resJson["code"] != "Success":
                self.logger.warning(resJson["message"])
                return False

        except Exception as e:
            self.alert('error {e}'.format(e=e))

        finally:
            frame.evaluateJavaScript('$("#progress").hide();')

    def movePage(self, pathUrl, fileNm):
        url = os.path.join(os.path.dirname(__file__), u"src/html/", fileNm)
        url = "file:///" + url.replace("\\", "/")
        # TODO : url 변경하는 부분 수정필요

        self.webView.load(QUrl(url))
        self.webView.show()

    def execInspection(self, pathUrl):
        # 검사종류 분기
        q = pathUrl.find("=")
        p = pathUrl[q + 1:]

        # 사용자 정보 확인
        userInfo = self.isValidSession()

        # 세션이 없으면 함수 종료
        if userInfo == "":
            return False

        # 검사 그룹 생성
        curTime = time.strftime("%Y%m%d%H%M%S")
        insGroupId = userInfo["userId"] + curTime

        # 검사대상 cid 목록
        frame = self.webView.page().mainFrame()
        insDataInfo = frame.evaluateJavaScript('getInsTargetList()')
        insDataInfo["insGroupId"] = insGroupId

        # 업데이트 할 컬럼명
        colName = ""
        if p == "LOG":
            colName = "loins_se"
        elif p == "THE":
            colName = "thins_se"
        elif p == "INF":
            colName = "inins_se"
        elif p == "LOC":
            colName = "lcins_se"
        
        # 검사 정보 업데이트
        insParams = {}
        insParams["cids"] = insDataInfo["features"]
        insParams["insUserId"] = userInfo["userId"]
        insParams["insUserNm"] = userInfo["userNm"]
        insParams["insGroupId"] = insGroupId
        insParams["colName"] = colName

        # TODO : 업데이트 기능 임시 주석
        self.updateNewFeatureInfo(insParams)

        if p == "LOG":
            # 플러그인 실행
            plugin = utils.plugins['NGIIMapInspectManager']
            plugin.showLogicalTemporalInspect(insDataInfo)

        elif p == "THE":
            plugin = utils.plugins['NGIIMapInspectManager']
            plugin.showThematicInspect(insDataInfo)

        elif p == "INF":
            self.writeCidList(self.INFCHECKER_PATH, insDataInfo)

            # 프로그램 실행
            self.execExeProgram(self.INFCHECKER_PATH, self.INFCHECKER_NAME)

        elif p == "LOC":
            self.writeCidList(self.LOCCHECKER_PATH, insDataInfo)

            # 프로그램 실행
            self.execExeProgram(self.LOCCHECKER_PATH, self.LOCCHECKER_NAME)

    def updateNewFeatureInfo(self, params):

        url = self.__server_url + "kgi/updateNewFeatureInfo.do"

        try:
            req = urllib2.Request(url, json.dumps(params), {'Content-Type': 'application/json'})
            response = urllib2.urlopen(req)

            resData = response.read()
            resJson = json.loads(resData)

            if resJson["code"] != 200:
                self.logger.warning(resJson["message"])
                return False

        except Exception as e:
            self.alert('error {e}'.format(e=e))

    def writeCidList(self, folder_name, res):
        # 파일명 정의
        t = time.strftime("%Y%m%d%H%M%S")
        fileName = 'ngii_{t}.txt'.format(t=t)

        # 파일 경로
        saveDir = os.path.join(self.GEOSTORY_DATA_CHECKER, folder_name)

        filePath = os.path.join(saveDir, fileName)
        fixedFile = os.path.join(saveDir, 'ngii_fixed.txt')

        # 검사목록 파일에 쓰기
        with codecs.open(os.path.join(filePath), 'wb', encoding='utf-8') as json_file:
                json.dump(res, json_file, ensure_ascii=False, indent=4)

        # 파일명도 쓰기
        n = open(fixedFile, 'w+t')
        n.write(fileName)
        n.close()

        # 생성된 파일을 삭제해야하나?

    def execExeProgram(self, subPath, exeName):
        fileDir = os.path.join(self.GEOSTORY_DATA_CHECKER, subPath , '{exeName}.exe'.format(exeName=exeName))
        if os.path.isfile(fileDir):
            os.startfile('{fileDir}'.format(fileDir=fileDir.encode('cp949')))
        else:
            self.alert(u'{fileDir}\n경로의 파일을 찾을 수 없습니다.'.format(fileDir=fileDir))

    def saveReport(self):
        # 세션ID
        sessId = self.getName("ngiiSessionId")

        # 리포트 목록 받아오기
        frame = self.webView.page().mainFrame()
        params = frame.evaluateJavaScript('saveReportList("{sessId}")'.format(sessId=sessId))
        frame.evaluateJavaScript('$("#progressBar").show();')

        url = self.__server_url + "report/saveReport.do"

        try:
            req = urllib2.Request(url, json.dumps(params), {'Content-Type': 'application/json'})
            res = threadExecuteRestapi(req)

            # 현재 시간 설정
            curTime= time.strftime("%Y%m%d%H%M%S")

            # 파일명 정의
            pdfPath = os.path.join(os.path.expanduser("~"), 'Downloads'
                                   , u'품질검사보고서_{curTime}.pdf'.format(curTime=curTime))

            blockSz = 1024
            with open(pdfPath, 'wb') as downloadFile:
                while True:
                    resBuffer = res.read(blockSz)
                    if not resBuffer:
                        break

                    downloadFile.write(resBuffer)

            # 리포트를 실행
            if os.path.isfile(pdfPath):
                subprocess.call('start {pdfPath}'.format(pdfPath=pdfPath.encode('cp949')), shell=True)
            else:
                self.alert(u'{pdfPath}\n경로의 파일을 찾을 수 없습니다.'.format(pdfPath=pdfPath))

        except Exception as e:
            self.alert('error {e}'.format(e=e))

        finally:
            frame.evaluateJavaScript('$("#progressBar").hide();')

    def excel(self):
        frame = self.webView.page().mainFrame()
        params = frame.evaluateJavaScript('excelTitle()')
        
        url = self.__server_url + "stats/excel.do"

        try:
            req = urllib2.Request(url, json.dumps(params), {'Content-Type': 'application/json'})
            res = urllib2.urlopen(req)

            # 현재 시간 설정
            curTime = time.strftime("%Y%m%d%H%M%S")

            # 파일명 정의
            excelTitle = params["title"]
            excelPath = os.path.join(os.path.expanduser("~"), 'Downloads'
                                   , u'{excelTitle}_{curTime}.xlsx'.format(excelTitle=excelTitle, curTime=curTime))

            blockSz = 1024
            with open(excelPath, 'wb') as downloadFile:
                while True:
                    resBuffer = res.read(blockSz)
                    if not resBuffer:
                        break

                    downloadFile.write(resBuffer)

            # 생성된 파일을 실행
            if os.path.isfile(excelPath):
                subprocess.call('start {excelPath}'.format(excelPath=excelPath.encode('cp949')), shell=True)
            else:
                self.alert(u'{excelPath}\n경로의 파일을 찾을 수 없습니다.'.format(excelPath=excelPath))

        except Exception as e:
            self.alert('error {e}'.format(e=e))

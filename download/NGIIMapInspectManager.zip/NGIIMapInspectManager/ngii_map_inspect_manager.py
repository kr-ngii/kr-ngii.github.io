# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NGIIMapInspectManager
                                 A QGIS plugin
 This inspect map in NGII
                              -------------------
        begin                : 2017-11-01
        git sha              : $Format:%H$
        copyright            : (C) 2017 by NGII
        email                : jskim@gaia3d.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *

import ConfigParser

import platform
if platform.system() != 'Windows':
    ext_lib_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib')
    sys.path.insert(0, ext_lib_path)

from DbInfoDialog import DbInfoDialog
from HtmlMenuDialog import HtmlMenuDialog
from LogicalTemporalInspect import LogicalTemporalInspect
from ThematicInspect import ThematicInspect

from initEnv import pg_init

# logging  ------------------------------------------------------------------------
import logging
import logging.handlers


log_folder = os.path.join(os.path.dirname(__file__), 'log')
if not os.path.exists(log_folder):
    os.mkdir(log_folder)

logger = logging.getLogger('ngiiPlugin')

formatter = logging.Formatter('[%(levelname)s|%(filename)s:%(lineno)s] %(asctime)s > %(message)s')

fileMaxByte = 1024 * 1024 * 500  # 500MB
log_filename = os.path.join(log_folder, 'ngii_plugin.log')
fileHandler = logging.handlers.RotatingFileHandler(log_filename, maxBytes=fileMaxByte, backupCount=5)
streamHandler = logging.StreamHandler()

fileHandler.setFormatter(formatter)
streamHandler.setFormatter(formatter)

logger.addHandler(fileHandler)
logger.addHandler(streamHandler)

logger.setLevel(logging.DEBUG)
# logging  ------------------------------------------------------------------------


class NGIIMapInspectManager:

    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "properties", "connection.ini")

    logger = None
    
    pluginName = u'NGIIMapInspectManager'
    mainMenuTitle = u"NGII"

    mainMenu = None
    menuBar = None

    mainWidget = None
    InspectWidget = None

    menuActions = []
    toolbarActions = []

    def __init__(self, iface):
        self.logger = logger
        # Save reference to the QGIS interface
        self.iface = iface  # type: QgsInterface

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'NGIIMapInspectManager_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.mainMenuTitle
        
        self.toolbar = self.iface.addToolBar(u'NGIIMapInspectManager')
        self.toolbar.setObjectName(u'NGIIMapInspectManager')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('NGIIMapInspectManager', message)

    def initGui(self):
        # # 메뉴 객체 생성
        # self.mainMenu = QMenu(self.iface.mainWindow())
        # self.mainMenu.setTitle(self.mainMenuTitle)
        #
        # # 메뉴 등록하기
        # menuBar = self.iface.mainWindow().menuBar()
        # menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.mainMenu)

        # # 하위 메뉴 생성
        # self.menuIcons = ['htmlMenu.png', 'icon.png']
        # self.menuTexts = [u'통합메뉴', u'국토기본정보 품질검사']
        # self.menuActions = [self.showHtmlMenu, self.showLogicalTemporalInspect]

        menuIcons = ['icon.png']
        menuTexts = [u'국토기본정보 품질검사']
        menuActions = [self.showHtmlMenu]

        assert (len(menuIcons) == len(menuTexts))
        assert (len(menuTexts) == len(menuActions))

        self.addNgiiMenu(menuIcons, menuTexts, menuActions)

    def addNgiiMenu(self, menuIcons, menuTexts, menuActions):
        # https://gis.stackexchange.com/questions/227876/finding-name-of-qgis-toolbar-in-python
        qgisMenuBar = self.iface.mainWindow().menuBar()

        # 이미 NGII 메뉴 있는지 찾아보기
        ngiiMenu = None
        for action in qgisMenuBar.actions():
            if action.text() == self.mainMenuTitle:
                ngiiMenu = action.menu()
                break

        # 없음 만들고 있음 그냥 사용
        if ngiiMenu is None:
            self.mainMenu = QMenu(self.iface.mainWindow())
            self.mainMenu.setTitle(self.mainMenuTitle)
            qgisMenuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.mainMenu)
        else:
            self.mainMenu = ngiiMenu

        # 이미 NGII 툴바 있는지 찾아보기
        ngiiToolbar = None
        for toolbar in self.iface.mainWindow().findChildren(QToolBar):
            # if toolbar.objectName() == self.mainMenuTitle:
            if toolbar.windowTitle() == self.mainMenuTitle:
                ngiiToolbar = toolbar
                break

        # 없음 만들고 있음 그냥 사용
        if ngiiToolbar is None:
            self.toolbar = self.iface.addToolBar(self.mainMenuTitle)
            self.toolbar.setObjectName(self.mainMenuTitle)
        else:
            self.toolbar = ngiiToolbar

        # 세부 메뉴, 버튼 추가
        self.menuActions = []
        self.toolbarActions = []
        for i in range(0, len(menuTexts)):
            icon = QIcon(os.path.join(os.path.dirname(__file__), 'icons', menuIcons[i]))
            text = menuTexts[i]
            action = QAction(icon, text, self.iface.mainWindow())
            self.mainMenu.addAction(action)
            action.triggered.connect(menuActions[i])
            button = self.toolbar.addAction(icon, text, menuActions[i])

            self.menuActions.append(action)
            self.toolbarActions.append(button)

    def removeNgiiMenu(self):
        if self.toolbar is not None:
            # 내가 등록한 툴바 아이템 제거
            for action in self.toolbarActions:
                self.toolbar.removeAction(action)
            # 더이상 항목이 없으면 부모 제거
            if len(self.toolbar.actions()) == 0:
                self.toolbar.deleteLater()

        if self.mainMenu is not None:
            for action in self.menuActions:
                self.mainMenu.removeAction(action)
            print len(self.mainMenu.actions())
            if len(self.mainMenu.actions()) == 0:
                self.mainMenu.deleteLater()

    def showHtmlMenu(self):

        if platform.system() == 'Windows':
            from _winreg import *

            conReg = ConnectRegistry(None, HKEY_LOCAL_MACHINE)
            # check PostgreSQL
            try:
                postgresqlKey = "SOFTWARE\PostgreSQL"
                OpenKey(conReg, postgresqlKey)

            except:
                QMessageBox.warning(self.iface.mainWindow(), u"경고",
                                    u"PostgreSQL이 설치되어 있지 않습니다.<br>"
                                    u"아래 링크에서 9.6.x 버전 설치 파일을 받아 설치해주시기 바랍니다.<br><br>"
                                    u"<a href='https://www.enterprisedb.com/downloads/postgres-postgresql-downloads'>"
                                    u"PostgreSQL 다운로드</a>")
                return

            # check PostGIS
            try:
                postgisKey = "SOFTWARE\PostGIS"
                OpenKey(conReg, postgisKey)

            except:
                QMessageBox.warning(self.iface.mainWindow(), u"경고",
                                    u"PostGIS가 설치되어 있지 않습니다.<br>"
                                    u"아래 링크에서 2.4.x 버전 설치 파일을 받아 설치해주시기 바랍니다.<br><br>"
                                    u"<a href='https://winnie.postgis.net/download/windows/pg96/buildbot/'>"
                                    u"PostGIS 다운로드</a>")
                return

        if not os.path.exists(self.PROPERTIES_FILE):
            dlg = DbInfoDialog(self.iface.mainWindow())
            rc = dlg.exec_()
            if rc != QDialog.Accepted:
                QMessageBox.warning(self.iface.mainWindow(), u"경고", u"DB 접속정보가 입력되지 않아 프로그램을 계속할 수 없습니다.")
                return
            else:
                self.createIniFile(dlg)

        if not self.initDatabase():
            return

        if self.mainWidget is not None:
            self.mainWidget.webView.reload()
            self.mainWidget.show()
            return

        # 사용자 정보 확인
        self.htmlMenuDialog = HtmlMenuDialog(self)
        userInfo = self.htmlMenuDialog.isValidSession()

        if userInfo:
            # 세션 정보가 있으면 성과품 검사
            filePath = u"src/html/inspection.html"
        else:
            # 세션 정보가 없으면 login 
            filePath = u"src/html/login.html"
        
        # url = u"https://www.daum.net/"
        url = os.path.join(os.path.dirname(__file__), filePath)
        url = url.replace("\\", "/")

        self.mainWidget = HtmlMenuDialog(self.iface, self.iface.mainWindow())
        self.mainWidget.setUrl(url)
        self.mainWidget.show()

    def showLogicalTemporalInspect(self, insDataInfo):
        if self.mainWidget:
            self.mainWidget.hide()
            QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        if self.InspectWidget is not None:
            if isinstance(self.InspectWidget, QDockWidget):
                self.iface.removeDockWidget(self.InspectWidget)
            else:
                self.InspectWidget.hide()

            del self.InspectWidget
            self.InspectWidget = None

        self.InspectWidget = LogicalTemporalInspect(self.iface, self.iface.mainWindow(), insDataInfo)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.InspectWidget)

        self.InspectWidget.startInspect()

    def showThematicInspect(self, insDataInfo):
        if self.mainWidget:
            self.mainWidget.hide()
            QCoreApplication.processEvents(QEventLoop.ExcludeUserInputEvents)

        if self.InspectWidget is not None:
            if isinstance(self.InspectWidget, QDockWidget):
                self.iface.removeDockWidget(self.InspectWidget)
            else:
                self.InspectWidget.hide()

            del self.InspectWidget
            self.InspectWidget = None

        self.InspectWidget = ThematicInspect(self.iface, self.iface.mainWindow(), insDataInfo)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.InspectWidget)

        self.InspectWidget.startInspect()

    def unload(self):
        if self.InspectWidget is not None:
            if isinstance(self.InspectWidget, QDockWidget):
                self.iface.removeDockWidget(self.InspectWidget)

        if self.mainWidget is not None:
            self.mainWidget.hide()
            del self.mainWidget

        self.removeNgiiMenu()

    def createIniFile(self, dlg):
        iniExample = os.path.join(os.path.dirname(os.path.abspath(__file__)), "properties", "connection.ini.example")
        config = ConfigParser.RawConfigParser()
        try:
            config.read(iniExample)
            config.set("database", "host", dlg.edtHost.text())
            config.set("database", "port", dlg.edtPort.text())
            config.set("database", "dbname", dlg.edtDatabase.text())
            config.set("database", "user", dlg.edtUser.text())
            config.set("database", "password", dlg.edtPassword.text())
            with open(self.PROPERTIES_FILE, 'w') as fout:
                config.write(fout)
        except Exception as e:
            self.logger.warning(e)

    def initDatabase(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            properties = ConfigParser.RawConfigParser()
            properties.read(self.PROPERTIES_FILE)

            # Database
            host = properties.get("database", "host")
            port = properties.get("database", "port")
            dbname = properties.get("database", "dbname")
            user = properties.get("database", "user")
            password = properties.get("database", "password")

            rc = pg_init.initDatbase(host, port, dbname, user, password)
            if rc:
                QApplication.restoreOverrideCursor()
                QMessageBox.about(self.iface.mainWindow(), u"오류", u"DB에 접속할 수 없어 중단됩니다.\n{}".format(rc))
                if os.path.exists(self.PROPERTIES_FILE):
                    os.remove(self.PROPERTIES_FILE)
                return False
        except Exception as e:
            self.logger.warning(e)
        finally:
            QApplication.restoreOverrideCursor()

        return True

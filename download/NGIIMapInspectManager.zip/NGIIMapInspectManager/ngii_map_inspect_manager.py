# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NGIIMapInspectManager
                                 A QGIS plugin
 This inspect map in NGII
                              -------------------
        begin                : 2017-11-01
        git sha              : $Format:%H$
        copyright            : (C) 2017 by NGII
        email                : jskim@gaia3d.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *

import ConfigParser

import platform
if platform.system() != 'Windows':
    ext_lib_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib')
    sys.path.insert(0, ext_lib_path)

from SelectInspectData import SelectInspectData
from ExportReport import ExportReport
from DbInfoDialog import DbInfoDialog
from initEnv import pg_init

# logging  ------------------------------------------------------------------------
import logging
import logging.handlers

log_folder = os.path.join(os.path.dirname(__file__), 'log')
if not os.path.exists(log_folder):
    os.mkdir(log_folder)

logger = logging.getLogger('ngiiPlugin')

formatter = logging.Formatter('[%(levelname)s|%(filename)s:%(lineno)s] %(asctime)s > %(message)s')

fileMaxByte = 1024 * 1024 * 500  # 500MB
log_filename = os.path.join(log_folder, 'ngii_plugin.log')
fileHandler = logging.handlers.RotatingFileHandler(log_filename, maxBytes=fileMaxByte, backupCount=5)
streamHandler = logging.StreamHandler()

fileHandler.setFormatter(formatter)
streamHandler.setFormatter(formatter)

logger.addHandler(fileHandler)
logger.addHandler(streamHandler)

logger.setLevel(logging.DEBUG)
# logging  ------------------------------------------------------------------------


class NGIIMapInspectManager:

    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "properties", "connection.ini")

    logger = None
    
    pluginName = u'NGIIMapInspectManager'
    mainMenuTitle = u"NGII"
    menuIcons = []
    menuTexts = []
    menuActions = []

    mainMenu = None
    menuBar = None

    crrWidget = None

    def __init__(self, iface):
        self.logger = logger
        # Save reference to the QGIS interface
        self.iface = iface  # type: QgsInterface

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'NGIIMapInspectManager_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.mainMenuTitle
        
        self.toolbar = self.iface.addToolBar(u'NGIIMapInspectManager')
        self.toolbar.setObjectName(u'NGIIMapInspectManager')

        # iface.initializationCompleted.connect(self.show_inspect_main)

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('NGIIMapInspectManager', message)

    def initGui(self):
        # 메뉴 객체 생성
        self.mainMenu = QMenu(self.iface.mainWindow())
        self.mainMenu.setTitle(self.mainMenuTitle)

        # 메뉴 등록하기
        menuBar = self.iface.mainWindow().menuBar()
        menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.mainMenu)

        # 하위 메뉴 생성
        # self.menuIcons = ['logo.png', 'success.png']
        # self.menuTexts = [u'검사 대상 선택', u'레포트 출력']
        # self.menuActions = [self.showSelectInspectData, self.showExportReport]
        self.menuIcons = ['icon.png']
        self.menuTexts = [u'국토기본정보 품질검사']
        self.menuActions = [self.showSelectInspectData]

        self.toolbar = self.iface.addToolBar(self.mainMenuTitle)

        assert (len(self.menuIcons) == len(self.menuTexts))
        assert (len(self.menuTexts) == len(self.menuActions))

        for i in range(0, len(self.menuTexts)):
            icon = QIcon(os.path.join(os.path.dirname(__file__), 'icons', self.menuIcons[i]))
            text = self.menuTexts[i]
            action = QAction(icon, text, self.iface.mainWindow())
            self.mainMenu.addAction(action)
            action.triggered.connect(self.menuActions[i])
            self.toolbar.addAction(icon, text, self.menuActions[i])

    def showSelectInspectData(self):
        # Check INI file
        if not os.path.exists(self.PROPERTIES_FILE):
            dlg = DbInfoDialog(self.iface.mainWindow())
            rc = dlg.exec_()
            if rc != QDialog.Accepted:
                QMessageBox.warning(self.iface.mainWindow(), u"경고", u"DB 접속정보가 입력되지 않아 프로그램을 계속할 수 없습니다.")
                return
            else:
                self.createIniFile(dlg)

        if not self.initDatabase():
            return

        if isinstance(self.crrWidget, SelectInspectData):
            inspectWidget = self.crrWidget.inspectWidget
            if inspectWidget is not None:
                inspectWidget.hide()
                self.iface.removeDockWidget(inspectWidget)
                inspectWidget.closeDB()
                self.iface.removeDockWidget(self.crrWidget.inspectWidget)
                del self.crrWidget.inspectWidget
                self.crrWidget.inspectWidget = None

        if self.crrWidget is not None:
            if self.crrWidget.inspectWidget is not None:
                self.iface.removeDockWidget(self.crrWidget.inspectWidget)
            self.crrWidget.hide()
            del self.crrWidget
            self.crrWidget = None
        self.crrWidget = SelectInspectData(self.iface, self.iface.mainWindow())
        self.crrWidget.show()

    def showExportReport(self):
        if isinstance(self.crrWidget, SelectInspectData):
            inspectWidget = self.crrWidget.inspectWidget
            if inspectWidget is not None:
                self.iface.removeDockWidget(inspectWidget)
                inspectWidget.hide()
                inspectWidget.closeDB()
                self.iface.removeDockWidget(self.crrWidget.inspectWidget)
                del self.crrWidget.inspectWidget
                self.crrWidget.inspectWidget = None

        if self.crrWidget is not None:
            if self.crrWidget.inspectWidget is not None:
                self.iface.removeDockWidget(self.crrWidget.inspectWidget)
            self.crrWidget.hide()
            del self.crrWidget
            self.crrWidget = None
        self.crrWidget = ExportReport(self.iface, self.iface.mainWindow())
        self.crrWidget.show()

    def unload(self):
        self.mainMenu.deleteLater()
        self.toolbar.deleteLater()
        if self.crrWidget is not None:
            if self.crrWidget.inspectWidget is not None:
                self.iface.removeDockWidget(self.crrWidget.inspectWidget)
            self.crrWidget.hide()
            del self.crrWidget
            self.crrWidget = None

    def createIniFile(self, dlg):
        iniExample = os.path.join(os.path.dirname(os.path.abspath(__file__)), "properties", "connection.ini.example")
        config = ConfigParser.RawConfigParser()
        try:
            config.read(iniExample)
            config.set("database", "host", dlg.edtHost.text())
            config.set("database", "port", dlg.edtPort.text())
            config.set("database", "dbname", dlg.edtDatabase.text())
            config.set("database", "user", dlg.edtUser.text())
            config.set("database", "password", dlg.edtPassword.text())
            with open(self.PROPERTIES_FILE, 'w') as fout:
                config.write(fout)
        except Exception as e:
            print(e)

    def initDatabase(self):
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            properties = ConfigParser.RawConfigParser()
            properties.read(self.PROPERTIES_FILE)

            # Database
            host = properties.get("database", "host")
            port = properties.get("database", "port")
            dbname = properties.get("database", "dbname")
            user = properties.get("database", "user")
            password = properties.get("database", "password")

            rc = pg_init.initDatbase(host, port, dbname, user, password)
            if rc:
                QApplication.restoreOverrideCursor()
                QMessageBox.about(self.iface.mainWindow(), u"오류", u"DB에 접속할 수 없어 중단됩니다.\n{}".format(rc))
                return False
        except Exception as e:
            print(e)
        finally:
            QApplication.restoreOverrideCursor()

        return True

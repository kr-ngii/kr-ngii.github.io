# -*- coding: utf-8 -*-
import os
from qgis.core import *

from ..util.ImgUtil import ImgUtil

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class LogicalImgUtil(ImgUtil):

    def __init__(self, dock):
        ImgUtil.__init__(self, dock.iface, dock)
        self.logger = logger

    def saveImg(self, schemaNm, layerNm, inspectCode, result):
        layer = QgsMapLayerRegistry.instance().mapLayersByName(layerNm)[0]
        legend = self.iface.legendInterface()

        legend.setLayerVisible(layer, True)
        self.iface.mapCanvas().setExtent(layer.extent())
        self.iface.mapCanvas().refresh()

        self.forceRefresh()

        if inspectCode == 'LCTCSG02':
            reaultAddImg = self.saveNearVertexImg(schemaNm, layer, inspectCode, result)
        elif inspectCode in ['LCTCDO01', 'LCTCDO02']:
            reaultAddImg = self.saveDuplicatedFeaturesImg(schemaNm, layer, inspectCode, result)
        elif inspectCode == 'LCTCMC01':
            reaultAddImg = self.saveCenterlineImg(schemaNm, layer, inspectCode, result)
        elif inspectCode.startswith("LCTCBM"):
            reaultAddImg = self.saveContinuousEdgeImg(schemaNm, layer, inspectCode, result)
        elif inspectCode.startswith("LCTCMM") or inspectCode == 'LCTCEC02':
            reaultAddImg = self.saveContinuousAttrImg(schemaNm, layer, inspectCode, result)
        elif inspectCode in ['LCTCBV03', 'LCTCBV09', 'LCTCBV11', 'LCTCBV12', 'LCTCBV13', 'LCTCBV15', 'LCTCBV18']:
            reaultAddImg = self.saveIntersectsPolygonToLinestring(schemaNm, layer, inspectCode, result)
        elif inspectCode in ['LCTCBV01', 'LCTCBV04', 'LCTCBV05', 'LCTCBV07', 'LCTCBV08', 'LCTCBV14', 'LCTCBV17',
                             'LCTCBV19']:
            reaultAddImg = self.saveIntersectsPolygonToPolygon(schemaNm, layer, inspectCode, result)
        elif inspectCode.startswith("LCTCBV"):
            reaultAddImg = self.saveIntersectsImg(schemaNm, layer, inspectCode, result)
        elif inspectCode == 'LCTCEC03':
            reaultAddImg = self.saveCtrlnContinuousImg(schemaNm, layer, inspectCode, result)
        else:
            # self_intersects, single_point, micro_feature, sliver
            reaultAddImg = self.saveCommonImg(schemaNm, layer, inspectCode, result)

        self.setDefaultSymbol(layer)
        legend.setLayerVisible(layer, False)

        self.forceRefresh()

        return reaultAddImg

    def saveCommonImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''

        for res in detailRes:
            cid = res["cid"]
            passGb = res["passGb"]
            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            if inspectCode in ['LCTCSG04', 'LCTCSG05'] or layer.name() =='tn_alpt':
                centerPoint = bbox.center()
                self.iface.mapCanvas().setCenter(centerPoint)
                self.iface.mapCanvas().zoomScale(500.0)
            else:
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)

            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                    'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                            'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

            resIdx = detailRes.index(res)
            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()
            imgExtentStr = [
                str(round(imgExtent.xMinimum(), 2)),
                str(round(imgExtent.yMinimum(), 2)),
                str(round(imgExtent.xMaximum(), 2)),
                str(round(imgExtent.yMaximum(), 2))
            ]
            detailRes[resIdx]["details"][0]["imgMbr"] = ', '.join(imgExtentStr)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb)
            self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        return detailRes

    def saveNearVertexImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Point?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_point", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]

            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                cid = res["cid"]
                passGb = res["passGb"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                          cid=cid))
                    continue

                self.setErrorSymbol(tmpLayer, expr)

                bbox = featureGeometry[0].boundingBox()
                centerPoint = bbox.center()
                self.iface.mapCanvas().setCenter(centerPoint)
                self.iface.mapCanvas().zoomScale(100.0)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                                'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        return detailRes

    def saveDuplicatedFeaturesImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''

        for res in detailRes:
            cid = res["cid"]
            passGb = res["passGb"]
            resDetail = res['details']
            for detail in resDetail:
                refCid = detail['refCid']

                if inspectCode == 'river_duplicated_features':
                    expr = exprStr.format(id=cid)
                else:
                    expr = '"cid" IN (\'{cid}\', \'{refCid}\')'.format(cid=cid, refCid=refCid)

                selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(exprStr.format(id=cid))))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                      cid=cid))
                    continue

                self.setErrorSymbol(layer, expr)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)

                geomType = layer.wkbType()

                if geomType == QGis.WKBMultiPoint or geomType == QGis.WKBPoint:
                    self.iface.mapCanvas().zoomScale(750.0)

                else:
                    self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)

                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgFileNm = 'err_{cid}_{refCid}.png'.format(cid=cid, refCid=refCid.replace(',', '_'))
                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode, imgFileNm)
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgFileNm = 'err_{cid}_{refCid}_tn.png'.format(cid=cid, refCid=refCid.replace(',', '_'))
                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode, tnImgFileNm)
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                detailIdx = resDetail.index(detail)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        return detailRes

    def saveCenterlineImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''

        subLayer = None
        legend = self.iface.legendInterface()

        for res in detailRes:

            subLayerNm = res['subLayer']
            passGb = res["passGb"]
            if not subLayer:
                subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                legend.setLayerVisible(subLayer, True)

                self.forceRefresh()

            cid = res['id']
            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)
            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode, subLayerNm,
                                   'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode, subLayerNm,
                                            'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

            resIdx = detailRes.index(res)
            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["image"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()
            imgExtentStr = [
                str(round(imgExtent.xMinimum(), 2)),
                str(round(imgExtent.yMinimum(), 2)),
                str(round(imgExtent.xMaximum(), 2)),
                str(round(imgExtent.yMaximum(), 2))
            ]
            detailRes[resIdx]["imgMbr"] = ', '.join(imgExtentStr)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb)
            self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveContinuousEdgeImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''

        legend = self.iface.legendInterface()

        subLayersList = list()

        for res in detailRes:
            cid = res["cid"]
            passGb = res["passGb"]
            subLayers = res['details'][0]['refLayerNm'].split(',')

            if len(subLayersList) <= 0:
                for subLayerNm in subLayers:
                    subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                    legend.setLayerVisible(subLayer, True)

                    subLayersList.append(subLayer)

                self.forceRefresh()

            expr = exprStr.format(id=cid)
            selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

            featureGeometry = [i.geometry() for i in selFeature]

            if len(featureGeometry) <= 0:
                self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                continue

            self.setErrorSymbol(layer, expr)

            bbox = featureGeometry[0].boundingBox()
            self.iface.mapCanvas().setExtent(bbox)
            self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)
            self.iface.mapCanvas().refresh()

            self.forceRefresh()

            imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                   'err_{id}.png'.format(id=cid))
            self.makePath(os.path.dirname(imgPath))
            self.iface.mapCanvas().saveAsImage(imgPath)

            thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                            'err_{id}_tn.png'.format(id=cid))
            thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

            resIdx = detailRes.index(res)
            detailIdx = 0
            with open(imgPath, "rb") as imgFile:
                detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

            imgExtent = self.iface.mapCanvas().extent()
            imgExtentStr = [
                str(round(imgExtent.xMinimum(), 2)),
                str(round(imgExtent.yMinimum(), 2)),
                str(round(imgExtent.xMaximum(), 2)),
                str(round(imgExtent.yMaximum(), 2))
            ]
            detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

            self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, res['passGb'], res['details'][0]['refLayerNm'])
            self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        for subLayer in subLayersList:
            legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveContinuousAttrImg(self, schemaNm, layer, inspectCode, detailRes):
        for res in detailRes:
            cid = res["cid"]
            passGb = res["passGb"]
            resDetail = res['details']
            for detail in resDetail:
                refCid = detail['refCid']
                refCid = refCid.replace(',', "','")

                expr = '"cid" IN (\'{cid}\', \'{refCid}\')'.format(cid=cid, refCid=refCid)

                selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                    continue

                # self.setErrorSymbol(layer, expr, scale=self.iface.mapCanvas().scale())
                self.setErrorSymbol(layer, expr)

                centerGeom = QgsGeometry().fromWkt(detail['tmp_geom'])
                self.iface.mapCanvas().setExtent(centerGeom.boundingBox())
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgFileNm = 'err_{cid}_{refCid}.png'.format(cid=cid, refCid=refCid.replace("','", "_"))
                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode, imgFileNm)

                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                tnImgFileNm = 'err_{cid}_{refCid}_tn.png'.format(cid=cid, refCid=refCid.replace("','", "_"))
                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode, tnImgFileNm)
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                detailIdx = resDetail.index(detail)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        return detailRes

    def saveIntersectsImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        for res in detailRes:

            cid = res["cid"]
            passGb = res["passGb"]
            resDetail = res['details']

            for detail in resDetail:
                subLayerNm = detail['refLayerNm']
                if subLayerNm != layerNm:
                    if not subLayer or subLayer.name() != subLayerNm:
                        legend.setLayerVisible(subLayer, False)

                        subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                        legend.setLayerVisible(subLayer, True)
                        self.forceRefresh()
                else:
                    subLayer = None

                expr = exprStr.format(id=cid)
                selFeature = layer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                    continue

                self.setErrorSymbol(layer, expr)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)

                geomType = layer.wkbType()

                if geomType == QGis.WKBMultiPoint or geomType == QGis.WKBPoint:
                    self.iface.mapCanvas().zoomScale(750.0)
                else:
                    self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale()*1.2)

                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layerNm, inspectCode, subLayerNm,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layerNm, inspectCode, subLayerNm,
                                                'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][0]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][0]["imgMbr"] = ', '.join(imgExtentStr)

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb, subLayerNm)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveIntersectsPolygonToLinestring(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("LineString?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_linestring", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]

            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                subLayerNm = detail['refLayerNm']
                if subLayerNm != layerNm:
                    if not subLayer or subLayer.name() != subLayerNm:
                        legend.setLayerVisible(subLayer, False)

                        subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                        legend.setLayerVisible(subLayer, True)
                        self.forceRefresh()
                else:
                    subLayer = None

                cid = res["cid"]
                passGb = res["passGb"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                          cid=cid))
                    continue

                self.setErrorSymbol(tmpLayer, expr)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                                'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb, subLayerNm)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveIntersectsPolygonToPolygon(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid"=\'{id}\''
        legend = self.iface.legendInterface()

        layerNm = layer.name()
        subLayer = None

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Polygon?crs=epsg:5179&field=cid:string&index=yes",
                                  "temporary_polygon", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]

            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                subLayerNm = detail['refLayerNm']
                if subLayerNm != layerNm:
                    if not subLayer or subLayer.name() != subLayerNm:
                        legend.setLayerVisible(subLayer, False)

                        subLayer = QgsMapLayerRegistry.instance().mapLayersByName(subLayerNm)[0]
                        legend.setLayerVisible(subLayer, True)
                        self.forceRefresh()
                else:
                    subLayer = None

                cid = res["cid"]
                passGb = res["passGb"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode,
                                                                                          cid=cid))
                    continue

                self.setErrorSymbol(tmpLayer, expr)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(self.iface.mapCanvas().scale() * 1.2)
                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                                'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb, subLayerNm)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        legend.setLayerVisible(subLayer, False)

        return detailRes

    def saveCtrlnContinuousImg(self, schemaNm, layer, inspectCode, detailRes):
        exprStr = '"cid" = \'{id}\''

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()

        tmpLayer = QgsVectorLayer("Point?crs=epsg:5179&field=g_id:int&field=cid:string&index=yes",
                                  "temporary_point", "memory")
        layerProvider = tmpLayer.dataProvider()
        newFeatures = list()

        for res in detailRes:
            details = res["details"]
            cid = res["cid"]
            if len(details) == 1:
                feat = QgsFeature(tmpLayer.pendingFields())
                feat.setGeometry(QgsGeometry().fromWkt(details[0]['tmp_geom']))
                feat.setAttribute('cid', cid)

                newFeatures.append(feat)

            else:
                for detail in details:
                    feat = QgsFeature(tmpLayer.pendingFields())
                    feat.setGeometry(QgsGeometry().fromWkt(detail['tmp_geom']))
                    feat.setAttribute('cid', "{}_{}".format(cid, details.index(detail)))

                    newFeatures.append(feat)

        layerProvider.addFeatures(newFeatures)

        QgsMapLayerRegistry.instance().addMapLayer(tmpLayer)
        layerOrder.insert(0, tmpLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        for res in detailRes:
            details = res["details"]

            for detail in details:
                cid = res["cid"]
                passGb = res["passGb"]
                if len(details) > 1:
                    cid = "{}_{}".format(cid, details.index(detail))

                expr = exprStr.format(id=cid)
                selFeature = tmpLayer.getFeatures(QgsFeatureRequest(QgsExpression(expr)))

                featureGeometry = [i.geometry() for i in selFeature]

                if len(featureGeometry) <= 0:
                    self.logger.debug("{inspectCode} not selected cid : {cid}".format(inspectCode=inspectCode, cid=cid))
                    continue

                expr = exprStr.format(id=cid)

                bbox = featureGeometry[0].boundingBox()
                self.iface.mapCanvas().setExtent(bbox)
                self.iface.mapCanvas().zoomScale(750.0)

                # self.setErrorSymbol(tmpLayer, expr, self.iface.mapCanvas().scale())
                self.setErrorSymbol(tmpLayer, expr)

                self.iface.mapCanvas().refresh()

                self.forceRefresh()

                imgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                       'err_{id}.png'.format(id=cid))
                self.makePath(os.path.dirname(imgPath))
                self.iface.mapCanvas().saveAsImage(imgPath)

                thumbnailImgPath = os.path.join(self.IMG_SAVE_PATH, schemaNm, layer.name(), inspectCode,
                                                'err_{id}_tn.png'.format(id=cid))
                thumbnailResult = self.createThumbnail(imgPath, thumbnailImgPath)

                resIdx = detailRes.index(res)
                detailIdx = details.index(detail)
                with open(imgPath, "rb") as imgFile:
                    detailRes[resIdx]["details"][detailIdx]["img"] = imgFile.read().encode('base64')

                imgExtent = self.iface.mapCanvas().extent()
                imgExtentStr = [
                    str(round(imgExtent.xMinimum(), 2)),
                    str(round(imgExtent.yMinimum(), 2)),
                    str(round(imgExtent.xMaximum(), 2)),
                    str(round(imgExtent.yMaximum(), 2))
                ]
                detailRes[resIdx]["details"][detailIdx]["imgMbr"] = ', '.join(imgExtentStr)

                del detailRes[resIdx]["details"][detailIdx]["tmp_geom"]

                self.dock.addTree('logic', layer.name(), inspectCode, cid, imgPath, passGb)
                self.dock.addShapeIdx(layer.name(), inspectCode, imgPath, imgExtentStr)

        QgsMapLayerRegistry.instance().removeMapLayer(tmpLayer)

        return detailRes

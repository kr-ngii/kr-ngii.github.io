// 상단 네비게이션 클릭
$('body').on('click', function(e){
    var $target = $(e.target);
    
    // 상단 메뉴에서 텍스트를 눌렀을 경우
    if($target.hasClass("liText")){
        $target = $(e.target).parent();
    }

    if( $target.data('section')){
        handleSectionTrigger($target);
    }
});

// 화면 컨텐츠 변경
function handleSectionTrigger($target){
    clearData();
    hideAllSections();

    $target.addClass('is-selected');

    qi.search_order = '';
    qi.search_sort = '';
    
    // 컨텐츠 show
    var sectionId = $target.data('section') + '-section';
    $('#' + sectionId).addClass('is-shown');
	
    // 상단 네비게이션 on
    $(".nav li").removeClass('on');
    $target.addClass('on');

    // 테이블 헤더 위치 변경
    $('thead').css("left", "0");

    // 통계를 눌렀다면
    if($(".nav li.stat").hasClass('on')){
        $(".snb li").removeClass("on");
        $(".snb li[data-stats-target=All]").addClass("on");
        $(".dashboard").show();
        $(".sdetail").hide();
    }
}

// 표출된 데이터, 차트를 지움
function clearData(){
    // data
    $(".chkAll").prop("checked", false);

    // chart
    //var chartList = document.querySelectorAll(".graph")
    //chartList.forEach(function(v, i){
    //    echarts.dispose(chartList[i])
    //})
}

// 모든 section을 숨김
function hideAllSections(){
    var sections = $('.js-section.is-shown');
    sections.each(function(i, section){
        $(section).removeClass('is-shown');
    });
}

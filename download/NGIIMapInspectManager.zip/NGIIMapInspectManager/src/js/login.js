// 엔터키 이벤트
function enterkey() {
    if(window.event.keyCode == 13) {
        $(".login").focus().click();
    }
}

// 로그인(파이썬에서 호출)
function login(){
    var id = $("#userId").val();
    var pw = $("#userPW").val();
    var userInfo = {};

    if(id == "" || pw == ""){
        alert("아이디 또는 비밀번호를 입력해주세요.");
        return false;
    }

    if(id != "ngii" || pw != "ngii518"){
        alert("0번째 인증에 실패하였습니다.");
        return false;
    }

    var sessionId = "";
    
    $.ajax({
        url : serviceUrl + '/user/login.do'
        , data : {userId : id, userPW : pw}
        , type : 'post'
        , dataType : 'json'
        , async: false
        , success : function(res){
            if(res.code == 'Pass'){

                if(res.login.head.state == "200" && res.login.body.result == "true"){
                    sessionId = res.sessionId;
                    userInfo.userId = id;
                    userInfo.sessionId = sessionId;
                } else {
                    alert(res.login.head.message);
                    userInfo = null;
                }
            } else {
                alert("로그인 중 오류가 발생했습니다.\n관리자에게 문의해주세요.");
                userInfo = null;
            }
        }
        , error : function(a,b,msg){
            debugger
        }
    });

    return userInfo;
}

// 로그아웃(파이썬에서 호출)
function logout(sessId){
    var sessionId = sessId;

    $.ajax({
        url : serviceUrl + '/user/logout.do'
        , data : {sessId : sessionId}
        , type : 'post'
        , dataType : 'json'
        , async: false
        , success : function(res){
            if(res.message == "OK"){
                sessionId = "";
            } else {
                alert(res.code);
            }
        }
        , error : function(a,b,msg){
            debugger
        }
    });

    return sessionId;
}

// 아이디 저장(파이썬에서 호출)
function saveId(){
    var id = "";

    if($("#saveId").is(":checked")){
        id = $("#userId").val();
    }

    return id;
}

// 저장된 아이디 불러오기(파이썬에서 호출)
function loadId(saveId){
    if(saveId){
        $("#saveId").prop("checked", true);
        $("#userId").val(saveId);
    }
}

// 로그인 사용자 표시(파이썬에서 호출)
function displayUserNm(sessId){
	getUserInfo(sessId, function(userInfo){
        $("#userNm").text(userInfo.userNm);
        qi.userId = userInfo.userId;
    });
}

// 비밀번호 변경 팝업
$("#changePW").on('click', function(){
    //window.open("www.google.com")
});

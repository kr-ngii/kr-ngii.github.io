// data load
$("#statsBtnSearchDemo").on('click', function(){
    // chart
    var chartList = $(".graph")
    chartList.each(function(i){
        echarts.dispose(chartList[i])
    });
	
    var data = jsonData;
    drawChartDemo('Insp', data.data_insp);
    drawChartDemo('Appr', data.data_appr);
    drawChartDemo('Month', data.data_month);
    drawChartDemo('Cate', data.data_cate);
    drawChartDemo('Comp', data.data_comp);
    drawChartDemo('Year', data.data_year);
})

// draw graph
function drawChartDemo(type, data){
    var labelOption = {}
    var chartOption = {}

    var name = [];
    var cnt	= [];
	var cnt1 = [];
	var cnt2 = [];
	var cnt3 = [];
	
    switch(type){
    case "Insp" : 
        labelOption = {normal: {show: true, position: 'inside', formatter: '{c}'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'item'}  // , formatter: '{b}: {c} ({d}%)'
            , legend: {
                type: 'scroll',
                orient: 'vertical',
                align: 'left',
                right: 0,
                top: 20,
                bottom: 20,
                data: data
            }
            , series: [
                {
                    name: ''
                    , type: 'pie'
                    , radius: ['20%', '70%']
                    , data: data
                    , label: labelOption
                }
            ]
        };
        break;
    case "Appr" : 
        //var labelOption = {normal: {show: false, position: 'center'}, emphasis: {show: true, position: 'center', fontWeight: 'bold'}}
        labelOption = {normal: {show: true, position: 'inside', formatter: '{c}'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'item'}
            , legend: {
                type: 'scroll',
                orient: 'vertical',
                align: 'left',
                right: 0,
                top: 20,
                bottom: 20,
                data: data
            }
            , series: [
                {
                    name: ''
                    , type: 'pie'
                    , radius: ['20%', '70%']
                    , data: data
                    , label: labelOption
                }
            ]
        };
        break;
    case "Month" : 
        for(var i=0, len=data.length; i<len; i++){
            name.push(data[i].name);
            cnt.push(data[i].cnt);
        }
        
        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'axis', formatter: '{b}: {c}'}
            , xAxis: {data: name, name: 'Month', nameGap: '10', nameRotate: '270'}
            , yAxis: {name: '객체 수'}
            , legend: {
                data: name
            }
            , series: [
                {
                    name: ''
                    , type: 'line'
                    , data: cnt
                    , showAllSymbol: true
                    , label: labelOption
                }
            ]
        };
        break;
    case "Cate" :
        for(var i=0, len=data.length; i<len; i++){
            name.push(data[i].name);
            cnt.push(data[i].cnt);
        }

        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'item'}
            , xAxis: {data: name, name: '유형', nameGap: '10', nameRotate: '270'}
            , yAxis: {name: '객체 수'}
            , series: [
                {
                    name: ''
                    , type: 'bar'
                    , data: cnt
                    , showAllSymbol: true
                    , label: labelOption
                }
            ]
        };
        break;
    case "Comp" : 
        for(var i=0, len=data.length; i<len; i++){
            name.push(data[i].name);
            cnt.push(data[i].cnt);
        }

        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'item'}
            , xAxis: {data: name, name: '업체명', nameGap: '10', nameRotate: '270'}    //, nameLocation: 'center', nameGap: '30'
            , yAxis: {name: '객체 수'}
            , series: [
                {		// KOMPSAT 그래프
                    name: ''
                    , type: 'bar'
                    , data: cnt
                    , showAllSymbol: true
                    , label: labelOption
                }
            ]
            , color: ['#4374D9', '#FF007F']
        };
        break;
    case "Year" : 
        for(var i=0, len=data.length; i<len; i++){
            name.push(data[i].name);
            cnt1.push(data[i].cnt1);
            cnt2.push(data[i].cnt2);
            cnt3.push(data[i].cnt3);
        }
        
        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'axis'}
            , xAxis: {type: 'category', data: name, name: 'Year', nameGap: '10', nameRotate: '270'}
            , yAxis: {type: 'value', name: '객체 수'}
            , series: [
                {
                    name: '적합'
                    , type: 'bar'
                    , data: cnt1
                    , showAllSymbol: true
                    , label: labelOption
                },
                {
                    name: '부적합'
                    , type: 'bar'
                    , data: cnt2
                    , showAllSymbol: true
                    , label: labelOption
                },
                {
                    name: '주의'
                    , type: 'bar'
                    , data: cnt3
                    , showAllSymbol: true
                    , label: labelOption
                }
            ]
        };
        break;
    }

    // create graph
    if($("#stats" + type)[0]){
        myChart = echarts.init($("#stats" + type)[0]);
        myChart.clear();
        myChart.setOption(chartOption);
    }
}

var jsonData = {
	"data_today" : [
		{
			"name": "업체A",
			"cnt": "10"
		},
		{
			"name": "업체B",
			"cnt": "20"
		},
		{
			"name": "업체C",
			"cnt": "17"
		},
		{
			"name": "업체D",
			"cnt": "8"
		}
	],
	"data_insp" : [
		{
			"name": "검사완료",
			"value": "40"
		},
		{
			"name": "미검사",
			"value": "5"
		},
		{
			"name": "검사진행중",
			"value": "15"
		}
	],
	"data_appr" :[
		{
			"name": "승인",
			"value": "32"
		},
		{
			"name": "반려",
			"value": "3"
		},
		{
			"name": "주의",
			"value": "5"
		}
	],
	"data_year" :[
		{
			"name": "2016년",
			"cnt1": "510",
			"cnt2": "110",
			"cnt3": "70"
		},
		{
			"name": "2017년",
			"cnt1": "780",
			"cnt2": "80",
			"cnt3": "20"
		},
		{
			"name": "2018년",
			"cnt1": "70",
			"cnt2": "5",
			"cnt3": "8"
		}
	],
	"data_month" :[
		{
			"name": "1월",
			"cnt": "20"
		},
		{
			"name": "2월",
			"cnt": "20"
		},
		{
			"name": "3월",
			"cnt": "20"
		},
		{
			"name": "4월",
			"cnt": "20"
		},
		{
			"name": "5월",
			"cnt": "20"
		},
		{
			"name": "6월",
			"cnt": "80"
		},
		{
			"name": "7월",
			"cnt": "20"
		},
		{
			"name": "8월",
			"cnt": "20"
		},
		{
			"name": "9월",
			"cnt": "10"
		},
		{
			"name": "10월",
			"cnt": "20"
		},
		{
			"name": "11월",
			"cnt": "0"
		},
		{
			"name": "12월",
			"cnt": "20"
		}
	],
	"data_cate" :[
		{
			"name": "논리",
			"cnt": "47"
		},
		{
			"name": "시간",
			"cnt": "47"
		},
		{
			"name": "주제",
			"cnt": "43"
		},
		{
			"name": "정보",
			"cnt": "10"
		},
		{
			"name": "위치",
			"cnt": "7"
		}
	],
	"data_comp" :[
		{
			"name": "업체A",
			"cnt": "10"
		},
		{
			"name": "업체B",
			"cnt": "20"
		},
		{
			"name": "업체C",
			"cnt": "17"
		},
		{
			"name": "업체D",
			"cnt": "8"
		}
	],
	"data_none" :[
		{

		}
	]
}

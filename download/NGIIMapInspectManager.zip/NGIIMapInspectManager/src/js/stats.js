// data load
$("#statsBtnSearch").on('click', function(){
    if(xhr){    // 통계 ajax 요청 중단
        xhr.abort();
    }

    getStats();
});

// 통계 상세보기 클릭
$(".snb li, .more").on('click', function(){
    if(xhr){    // 통계 ajax 요청 중단
        xhr.abort();
    }

    var target = $(this).data('stats-target');
    var tab = $(".snb li[data-stats-target="+ target +"]");

    if(target == 'Errcd'){
        $("#statsSchCateErr").show();
    } else {
        $("#statsSchCateErr").hide();
    }

    // 탭 메뉴 활성화
    $(".snb li").removeClass("on");
    tab.addClass("on");

    // 그래프 영역 활성화
    if( target == "All" ){
        $(".dashboard").show();
        $(".sdetail").hide();

        // 대시보드 조회
        getDashBoardChart();
    } else {
        var title = tab.text();
        $("#statsDetailTitle").text(title);
        $(".dashboard").hide();
        $(".sdetail").show();

        // 각 그래프 조회
        searchStatsData(target);
    }
});

// 유형별 오류 현황에서 검사 종류 선택
$(".statsCateErr").on('change', function(){
    var target = $(this).data('stats-target');

    if(target == 'All'){
        searchStatsData("Errcd", "dashboard");
    } else {
        searchStatsData("Errcd");
    }
});

// 통계 조회
function getStats(){
    var target = $(".snb li.on").data('stats-target');
    if(target == "All"){
        getDashBoardChart();
    } else {
        searchStatsData(target);
    }
}

// 대시보드 조회
function getDashBoardChart(){
    // chart
    var chartList = $(".graph");
    chartList.each(function(i){
        echarts.dispose(chartList[i])
    });

    searchStatsData("Today", "dashboard");
    searchStatsData("Insp", "dashboard");
    searchStatsData("Appr", "dashboard");
    searchStatsData("Month", "dashboard");
    searchStatsData("Cate", "dashboard");
    searchStatsData("Errcd", "dashboard");
    //searchStatsData("Year", "dashboard");
}

// 데이터 조회
function searchStatsData(target, isDashboard){
    // 차트 지우기
    var chart_ = $(".graph." + target);
    echarts.dispose(chart_);

    var params = searchParams("stats");

    if(!isDashboard){
        params.type = target;
    }

    xhr = $.ajax({
        url: serviceUrl + '/stats/selectStats' + target + '.do',
        type: 'post',
        dataType: 'json',
        data: JSON.stringify(params),
        contentType: 'application/json',
        success: function(res){
            var data = res.message;

            if(isDashboard){
                if(target == "Today"){
                    // 일반 현황
                    drawTextChart(target, data.data);
                } else {
                    // 그래프 통계
                    drawSimpleChart(target, data.data);
                }
            } else {
                //drawDetailChart(target, data.detail);
                drawSimpleChart(target, data.detail);
                drawDetailTable(target, data);
            }
        },
        error: function(a,b,msg){
            debugger
        }
    });
}

// view text
function drawTextChart(type, data){
    // 오늘의 검사
    for(var i=0, len=data.length; i<len; i++){
        $("#statsCnt_" + data[i].code).text(data[i].cnt + "건");
    }
}

// draw graph
function drawSimpleChart(type, data){
    var sum = 0;
    var keys = [];
    var vals = [];
    var dataList = [];
    var labelOption = {};
    var chartOption = {};

    switch(type){
    case "Insp" : 
        sum = 0;
        keys = ["검사진행중", "결과전송완료"];
        vals = $.map(data, function(value, key) {
            return [value];
        });

        for(var i=0, len=vals.length; i<len; i++){
            var obj = {name: keys[i], value: vals[i]}
            dataList.push(obj)

            sum += vals[i]*1;
        }

        $(".totcnt.totInsp").text(sum);
        
        labelOption = {normal: {show: true, position: 'inside', formatter: '{c}'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'item'}  // , formatter: '{b}: {c} ({d}%)'
            , legend: {
                type: 'scroll',
                orient: 'vertical',
                align: 'left',
                right: 0,
                top: 20,
                bottom: 20,
                data: keys
            }
            , series: [
                {
                    name: ''
                    , type: 'pie'
                    , radius: ['20%', '70%']
                    , data: dataList
                    , label: labelOption
                }
            ]
        };
        break;
    case "Appr" : 
        sum = 0;
        keys = ["적합객체", "부적합객체", "주의객체", "예외객체"];
        vals = $.map(data, function(value, key) {
            return [value];
        });

        for(var i=0, len=vals.length; i<len; i++){
            var obj = {name: keys[i], value: vals[i]}
            dataList.push(obj)

            sum += vals[i]*1;
        }
        
        $(".totcnt.totAppr").text(sum);

        //var labelOption = {normal: {show: false, position: 'center'}, emphasis: {show: true, position: 'center', fontWeight: 'bold'}}
        labelOption = {normal: {show: true, position: 'inside', formatter: '{c}'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'item'}
            , legend: {
                type: 'scroll',
                orient: 'vertical',
                align: 'left',
                right: 0,
                top: 20,
                bottom: 20,
                data: keys
            }
            , series: [
                {
                    name: ''
                    , type: 'pie'
                    , radius: ['20%', '70%']
                    , data: dataList
                    , label: labelOption
                }
            ]
        };
        break;
    case "Month" : 
        for(var i=0, len=data.length; i<len; i++){
            keys.push(data[i].x_month);
            vals.push(data[i].cnt);
        }
        
        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'axis', axisPointer : {type : 'shadow'}}
            , legend: {
                data: ['검사완료']
            }
            , xAxis: {data: keys, name: '월', nameGap: '10', nameRotate: '270'}
            , yAxis: {name: '객체 수'}
            , series: [
                {
                    name: '검사완료'
                    , type: 'line'
                    , data: vals
                    , showAllSymbol: true
                    , label: labelOption
                }
            ]
        };
        break;
    case "Cate" : 
        var name = [];
        var pass = [];
        var fail = [];
        var warn = [];
        var excp = [];
        var allcnt = [];

        for(var i=0, len=data.length; i<len; i++){
            var t = "";
            switch(data[i].code){
            case "DLC": t = "논리"; break;
            case "DTQ": t = "시간"; break;
            case "DTA": t = "주제"; break;
            case "DCN": t = "정보"; break;
            case "DPA": t = "위치"; break;
            }
            
            name.push(t);
            pass.push(data[i].pass);
            fail.push(data[i].fail);
            warn.push(data[i].warn);
            excp.push(data[i].excp);
            allcnt.push(data[i].allcnt);
        }

        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'axis', axisPointer : {type : 'shadow'}}
            , legend: {
                data: ['전체', '적합', '부적합', '주의', '예외']
            }
            , xAxis: {data: name, name: '유형', nameGap: '10', nameRotate: '270'}
            , yAxis: {name: '객체 수'}
            , series: [
                {
                    name: '전체'
                    , type: 'bar'
                    , data: allcnt
                    , showAllSymbol: true
                    , label: labelOption
                },
                {
                    name: '적합'
                    , type: 'bar'
                    , data: pass
                    , stack: "ins"
                    , showAllSymbol: true
                    //, label: labelOption
                },
                {
                    name: '부적합'
                    , type: 'bar'
                    , data: fail
                    , stack: "ins"
                    , showAllSymbol: true
                    //, label: labelOption
                },
                {
                    name: '주의'
                    , type: 'bar'
                    , data: warn
                    , stack: "ins"
                    , showAllSymbol: true
                    //, label: labelOption
                },
                {
                    name: '예외'
                    , type: 'bar'
                    , data: excp
                    , stack: "ins"
                    , showAllSymbol: true
                    //, label: labelOption
                }
            ]
        };
        break;
    case "Errcd" : 
        sum = 0;
        labelOption = {normal: {show: true, position: 'inside', formatter: '{c}'}, emphasis: {fontWeight: 'bold'}}
        
        for(var i=0, len=data.length; i<len; i++){
            var obj = {};
            obj.name = data[i].codenm;
            obj.value = data[i].cnt;
            
            keys.push(obj.name);
            dataList.push(obj);

            sum += obj.value*1;
        }

        $(".totcnt.totErrCnt").text(sum);

        // 오류가 없는 경우 처리
        if(sum <= 0){
            keys = ["오류 현황"];
            dataList = [{name: '오류 현황', value: "0"}];
        }

        chartOption = {
            tooltip: {trigger: 'item'}
            , legend: {
                type: 'scroll',
                orient: 'vertical',
                align: 'left',
                right: 0,
                top: 20,
                bottom: 20,
                data: keys
            }
            , series: [
                {
                    name: ''
                    , type: 'pie'
                    , radius: ['20%', '70%']
                    , data: dataList
                    , label: labelOption
                }
            ]
        };
        break;
    case "Year" : 
        var bsns = [];
        var pass = [];
        var fail = [];
        var warn = [];
        var proc = [];

        $.map(data, function(value, key) {
            bsns.push(value.bsns);
            pass.push(value.pass);
            fail.push(value.fail);
            warn.push(value.warn);
            proc.push(value.proc);
        });

        labelOption = {normal: {show: true, position: 'top'}, emphasis: {fontWeight: 'bold'}}
        chartOption = {
            tooltip: {trigger: 'axis', axisPointer : {type : 'shadow'}}
            , xAxis: {data: bsns, name: '업체명', nameGap: '10', nameRotate: '270'}    //, nameLocation: 'center', nameGap: '30'
            , yAxis: {name: '객체 수'}
            , series: [
                {
                    name: '적합'
                    , type: 'bar'
                    , stack: '논리'
                    , data: pass
                    , showAllSymbol: true
                    , label: labelOption
                },
                {
                    name: '부적합'
                    , type: 'bar'
                    , stack: '논리'
                    , data: fail
                    , showAllSymbol: true
                    , label: labelOption
                },
                {
                    name: '경고'
                    , type: 'bar'
                    , stack: '주제'
                    , data: warn
                    , showAllSymbol: true
                    , label: labelOption
                },
                {
                    name: '진행중'
                    , type: 'bar'
                    , stack: '주제'
                    , data: proc
                    , showAllSymbol: true
                    , label: labelOption
                }
            ]
            //, color: ['#4374D9', '#FF007F']
        };
        break;
    }

    // 전체가 아니라면 
    if(!$(".snb li.on[data-stats-target=All]")[0]){
        type = "Detail"
    }

    // create graph
    if($("#stats" + type)[0]){
        myChart = echarts.init($("#stats" + type)[0]);
        myChart.clear();
        myChart.setOption(chartOption);
    }
}

// draw graph detail
function drawDetailChart(type, data){var sum = 0;
    
}

// 통계 상세 표
function drawDetailTable(type, data){
    var h = "";
    var c = "";
    var thead = data.header;
    var tbody = data.table;
    var key = data.key;

    // header
    for(var i=0, len=thead.length; i<len; i++){
        h += "<th>" + thead[i] + "</th>";
    }
    $("#statsTableHead").html(h);

    // contents
    if(tbody.length > 0){
        for(var i=0, len=tbody.length; i<len; i++){
            c += "<tr>";
            for(var j=0, l=key.length; j<l; j++){
                c += "<td>" + tbody[i][key[j]] + "</td>";
            }
            c += "</tr>";
        }
    } else {
        c += "<tr><td colspan='" + thead.length + "'>검색된 데이터가 없습니다.</td></tr>";
    }
    $("#statsTableBody").html(c);

    if(type == "Errcd" && tbody.length > 0){
        // 셀 병합
        applyRowspanStats($("#statsTableBody"));
    }
}

// 셀병합 rowspan
function applyRowspanStats(selector) {
    selector.each(function() {
        var values = $(this).find("tr>td:first-of-type");
        
        var run = 1;
        for (var i=values.length-1; i>-1; i--){
            if(values.eq(i).text() === values.eq(i-1).text()) {
                if(values.length != run){
                    values.eq(i).remove();
                    run++;
                } else {
                    values.eq(i).attr("rowspan", run);
                }
            } else {
                values.eq(i).attr("rowspan", run);
                run = 1;
            }
        }
    })
}

// 엑셀 제목 출력(파이썬에서 호출)
function excelTitle(){
    var params = {};
    var tabName = $(".snb li.on").text();
    
    params.type = $(".snb li.on").data("stats-target");
    params.title = tabName.replace(/(\s*)/g, "");  // 모든 공백 제거
    params.year = $("#statsSelBsnsYy option:selected").val();
    params.mnentNm = $("#statsSelBzComp option:selected").val();
    params.bCode = $('.statsCateErr.Errcd option:selected').val();
    
    return params;
}

// 상세보기 레이어 닫기
$("#btnClose").on('click', function(){
    $("#layerWrap").hide();
    searchList();
});

// 이전 다음 버튼 선택
$(".prev, .next").on('click', function(){
    var page = $("#currNum").text();
    var lastPage = $("#allNum").text();
    var num = 0;

    // 변경사항이 있다면,
    var change = $("#detailTmpl").find(".change");
    if(change.length > 0){
        if(confirm("변경사항을 저장하시겠습니까?")){
            updateFeatureResult(function(cid){

            });
        } else {
            // 그냥 넘어감
        }
    }

    // 이전 다음 버튼 클릭
    if($(this).hasClass("prev")){
        if(page != "1"){
            num = page*1 - 1;
            var cid = $("#cidList div[data-num='" + num + "']").text();
            viewDetail(cid);
            $("#currNum").text(num);
        }
    } else {
        if(page != lastPage){
            num = page*1 + 1;
            var cid = $("#cidList div[data-num='" + num + "']").text();
            viewDetail(cid);
            $("#currNum").text(num);
        } else {
            if(confirm("마지막 페이지 입니다.\n검사 결과를 전송하시겠습니까?")){
                updateManageSystem();
            }
        }
    }
});

// 검사결과 변경 이벤트(라디오)
$("#detailTmpl").on('change', '[type=radio]', function(e){
    var id = $(this).attr("id");
    var label = $(this).parent();
    var td = $(label).parent();
    var labels = $(td).find("label");
    
    // 일괄적으로 바꾸자
    labels.each(function(i, v){
        $(td).css("background-color", "white");
        $(labels[i]).find("span").css("font-weight", "normal");
        $(td).parent().removeClass("change");
    });

    // 결과가 변경됐을경우 표시
    if( !$(this).hasClass("dataRes") ){
        $(td).css("background-color", "#e6e6e6");
        $(label).find("span").css("font-weight", "bold");
        $(td).parent().addClass("change");
    }
});

// 검사결과 변경 이벤트(텍스트)
$("#detailTmpl").on('keyup', '.textarea', function(e){
    var td = $(this).parent();
    
    // 결과가 변경됐을경우 표시
    if( $(this).data("text") != $(this).val() ){
        $(td).css("background-color", "#e6e6e6");
        $(td).parent().addClass("change");
    } else {
        $(td).css("background-color", "white");
        $(td).parent().removeClass("change");
    }
});

// 원래대로
$(".rollback").on('click', function(){
    var radios = $("#detailTmpl").find("[type=radio]");
    var texts = $("#detailTmpl").find(".textarea");

    // 라디오 버튼 초기화
    radios.each(function(i, v){
        if($(v).hasClass("dataRes")){
            $(v).prop("checked", true).change();
            $(v).parent().removeClass("change");
        }
    });

    // 텍스트 박스 초기화
    texts.each(function(i, v){
        var text = $(v).data("text");
        $(v).val(text).keyup();
        $(v).parent().removeClass("change")
    });
});

// 변경사항 저장 확인
$("#updateInsResult").on('click', function(){
    var change = $("#detailTmpl").find(".change");
    
    if(change.length > 0){
        if(confirm("변경사항을 저장하시겠습니까?")){
            updateFeatureResult(function(cid){
                viewDetail(cid);
            });
        } else {
            return false;
        }
    } else {
        alert("변경사항이 없습니다.");
    }
});

// 이미지 보기 버튼
$("#detailTmpl").on('click', '.viewImg', function(){
    var img = $(this).siblings("span.dataImg").text();
    var imgMbr = $(this).siblings("span.dataImgMbr").text();
    $("#dataImg").attr("src", "data:image/jpg;base64," + img);
    $("#dataImgMbr").text(imgMbr);
});

// 상세 조회
function viewDetail(cid){
    if(xhr){    // ajax 요청 중단
        xhr.abort();
    }
    
    xhr = $.ajax({
        url: serviceUrl + '/product/prodDetail.do'
        , type: 'post'
        , data: JSON.stringify({cid: cid})
        , dataType: 'json'
        , contentType: 'application/json'
        , success: function(res){
            var list = res.message;
            $('#detailTmpl').empty();

            if(list.length <= 0){
                $("#detailTmpl").html("");
            } else {
                // add img
                for(var i=0, len=list.length; i<len; i++){
                    if(list[i].img != null && list[i].img != ""){
                        $("#dataImg").attr("src", "data:image/jpg;base64,"+list[i].img);
                        $("#dataImgMbr").text(list[i].imgMbr);
                        break;
                    }

                    if(i == len-1){ // 이미지가 없을 경우
                        $("#dataImg").attr("src", "../images/noimg.gif").attr("width","280px");
                        $("#dataImgMbr").text(list[i].imgMbr);
                    }
                }

                // add list data
                $("#dataBsnsNmSub").text(list[0].updtBsnsNm + " - " + list[0].updtBsnsNmSub);
                $("#dataBzComp").text(list[0].mnentNm);
                $("#dataLayerCode").text(list[0].layerNm+" (" + list[0].layerId + ")");
                $("#dataModType").text(list[0].obchgSeNm);
                $("#dataInsUserNm").text(list[0].insUserNm);
                $("#dataDeliveryDe").text(list[0].obchgDt);
                $("#dataBzEndDe").text(list[0].rsregDt);
                $("#dataInsStrDe").text(list[0].insStrDt);

                $('#detailTmplList').tmpl(list).appendTo('#detailTmpl');
                applyRowspan($('#detailTmpl'));
                applyRowspanSub($('#detailTmpl'));
            }

            $("#layerWrap").show();
        }
        , error: function(a,b,m){
            debugger;
        }
        , complete: function(){
            $(window).resize();
        }
    });
}

// 검사결과 변경
function updateFeatureResult(callback){
    if(xhr){    // ajax 요청 중단
        xhr.abort();
    }

    var param = {};
    var params = [];

    $("#detailTmpl").find("tr").each(function(i, tr){
        if($(tr).hasClass("change")){
            var resInfo = $(tr).children(".resInfo");
            param.cid = resInfo.data("res-cid");
            param.bCode = resInfo.data("res-bcode");
            param.insTCode = resInfo.data("res-instcode");
            param.imgNm = resInfo.data("res-imgnm");
            param.resCode = $(tr).find("[type=radio]:checked").data("res-code");
            param.errorDc = $(tr).find(".textarea").val();

            params.push(param);
        }
    });

    xhr = $.ajax({
        url: serviceUrl + '/kgi/updateFeatureResult.do'
        , type: 'post'
        , data: JSON.stringify({data: params})
        , dataType: 'json'
        , async: false
        , contentType: 'application/json'
        , success: function(res){
            if(res.code == "200" && res.message == 'INSERT OK'){
                alert("저장 되었습니다.");
                callback(params[0].cid);
            } else{
                alert("저장에 실패 하였습니다.\n관리자에게 문의해주세요.");
            }
        }
        , error: function(a,b,m){
            debugger;
        }
    });
}

// 관리시스템에 결과 전송
function updateManageSystem(){
    var allCid = $("#cidListAll div");
    var cid = [];
    allCid.each(function(i, v){
        cid.push($(v).text());
    });

    xhr = $.ajax({
        url: serviceUrl + '/kgi/updateManageSystem.do'
        , type: 'post'
        , data: JSON.stringify({cid: cid, userId: qi.userId})
        , dataType: 'json'
        , async: false
        , contentType: 'application/json'
        , success: function(res){
            if(res.code == "200" && res.message == 'OK'){
                alert("저장 되었습니다.");
                $("#layerWrap").hide();
                searchList();
            } else{
                alert("저장에 실패 하였습니다.\n관리자에게 문의해주세요.");
            }
        }
        , error: function(a,b,m){
            debugger;
        }
    });
}
// 검색 조건 - 콤보박스 조회
$(".nav li").on('click', function(e){
    var target = $(this).data('target');
    
    //chModeList(target);                 // 공통코드 조회 : 수정방법구분
    bsnsYearList(target, function(){            // 사업년도 조회
        bsnsNameList(target, function(){        // 사업명 조회
            bzCompList(target, function(){      // 업체명 조회
                $("#"+ target + "BtnSearch").click();
            });
        });
    });
    
    // 검색 조건 - 날짜 date picker
    createDatepickerLinked(target+"StrDate", target+"EndDate");
    if(!$("#"+target+"StrDate").val() && !$("#"+target+"EndDate").val()){
        initPeriodFromToday(-30, 0, target+"StrDate", target+"EndDate");
    }
});

// 검색 조건 - 날짜 조회
$(".date").keyup(function(e){
    var date = $(this).val();
    var target = $(".nav li.on").data('target');

    if(date.length >= 10){
        if(!isValidDate(date)){
            alert("입력한 날짜를 확인해주세요.");

            if($(this).attr("id") == target + "EndDate"){
                var today = getToday("-");
                $(this).val(today);
            } else {
                $(this).val("");
            }
        };
    }
});

// 검색 조건 - 파란버튼 토글
$('.term').on('click', function(e){
    // disabled 클래스가 있으면 실행 취소
    if($(e.target).hasClass("schDisabled")){
        return false;
    }

    $(this).find("button").removeClass('on');
    $(e.target).addClass('on');

    // 검사대기보기, 나의검사보기 버튼을 클릭할 경우
    if($(this).attr("id") == "inspReadSe"){
        // 검사종류 전체로 변경
        $("#inspSelCate button.schdis").removeClass("on");
        $("#inspSelCate button[value='all']").addClass("on");

        // 진행상태 검사필요로 변경
        $("#inspSelProc button[value='finish']").removeClass("on");
        $("#inspSelProc button[value='need']").addClass("on");

        if($(e.target).val() == 'IVS001'){
            $(".schdis").addClass("schDisabled");
            //$("#inspSelProc button[value='finish']").hide();
        } else {
            $(".schdis").removeClass("schDisabled");
            //$("#inspSelProc button[value='finish']").show();
        }
    }

    // 날짜 관련 파란 버튼은 input값 변경
    if($(this).hasClass("calPeriod")){
        if($(e.target).val()!="etc"){
            changeCalendarDate(e.target);
        }
    }

    // 자동 검색 클래스가 있으면, 검색 실행
    if($(this).hasClass('auto_search')){
        searchList();
    }
});

// 검색 조건 - 상세검색 버튼 토글
/* 
$(".detailSearch").on('click', function(){
    var target = $(".nav li.on").data('target');

    $("." + target + "SearchDetail").toggle();
    $(this).toggleClass("layer_on");

    if($(this).hasClass("layer_on")){
        $(this).text("상세검색 ▲");
    } else {
        $(this).text("상세검색 ▼");
    }
});
*/

// 검색 조건 - 검색 버튼 클릭
$('.search').on('click', function(e){
    qi.search_order = '';
    qi.search_sort = '';

    searchList();
});

// 검색 목록 - row를 선택하면 체크박스 이벤트
$("table.scroll").on('click', 'tbody>tr', function(e){
    if(!$(e.target).hasClass("chk")){
        var isChecked = $(this).find(".chk").is(":checked");
        $(this).find(".chk").prop("checked", !isChecked);
    }

    changeInsBtnColor(e);
    checkedObjCnt();
});

// 검색 목록 - 체크박스 전체 선택
$(".chkAll").on('click', function(e){
    var target = $(this).parents('section').data('target');
    var isChecked = $(this).is(":checked");

    $('#' + target + 'Tmpl').find('.chk').prop("checked", isChecked);

    changeInsBtnColor(e);
    checkedObjCnt();
});

// 컬럼 정렬
$("[data-order]").on('click', function(e){
    var ord = $(e.target).data('order');
    var sort = $(e.target).data('sort');

    qi.search_order = ord;
    qi.search_sort = sort == "asc" ? "desc" : "asc";

    $(e.target).data("sort", qi.search_sort);

    searchList();
});

// 화면 하단 - 검사 실행
$(".executeIns").on('click', function(e){
    var insKind = $(e.target).data('ins-cate');        // log, the, inf, loc
    var elementTd = $("#inspTmpl .chk:checked").parent();
    var insResultList = elementTd.siblings("." + insKind);
    var insName = $(e.target).data('ins-name');
    var insNoExec = 0;
    var insComplete = 0;
    var len = elementTd.length;
    var msg = ""

    if(!(len > 0)){
        alert("검사 대상을 선택해주세요.");
        return false;
    }

    // 검사 결과 확인
    $.each(insResultList, function(i, v){
        var val = $(v).data("code");
        val=='IVS003' ? insNoExec++ : insComplete++;
    });

    if(insComplete > 0){
        msg += "선택한 " + (insComplete + insNoExec) + "건의 객체 중"
        msg += "\n" + insName + " 검사 이력이 있는 객체가 " + insComplete + "건이 있습니다."
        msg += "\n\n계속 검사를 진행하시겠습니까? (이전 결과는 삭제)"
    } else {
        msg += insNoExec + "건의 " + insName + " 검사를 진행하시겠습니까?"
    }

    // 아니오 누르면 검사 실행 취소!
    if(confirm(msg)){
        return true;
    } else {
        return false;
    }
});

// 화면 하단 - 확인용 리포트 생성
$("#saveReport").on('click', function(){
    var elementTd = $("#apprTmpl .chk:checked").parent();
    var len = elementTd.length;
    var msg = "";

    if(!(len > 0)){
        alert("리포트 대상을 선택해주세요.");
        return false;
    }

    msg += len + "건의";
    msg += " 검사 결과 리포트를 생성하시겠습니까?";

    if(confirm(msg)){
        return true;
    } else {
        return false;
    }
});

// 화면 하단 - 검사 결과 전송
$("#saveInsResult").on('click', function(){
    $("#cidListAll").empty();
    $("#cidList").empty();

    var elementTd = $("#apprTmpl .chk:checked").parent();
    var resultList = elementTd.siblings(".result");
    var cidList = elementTd.siblings(".dataCid");
    var pass = 0;
    var again = 0;
    var len = elementTd.length;
    var msg = ""
    var isTrue = false;

    if(!(len > 0)){
        alert("전송할 대상을 선택해주세요.");
        return false;
    }

    // 검사 결과 확인
    $.each(resultList, function(i, v){
        var val = $(v).data("code");
        
        // 전체 cid 기록
        var all_cid = $(cidList[i]).text();
        var all_len = $("#cidListAll div").length;
        var all_divTag = "<div data-num='" + (all_len+1) + "'>" + all_cid + "</div>";
        $("#cidListAll").append(all_divTag);

        if(val=='IVS002'){
            pass++;
        } else {
            again++;

            // 재검사가 필요한 cid 기록
            var cid = $(cidList[i]).text();
            var len = $("#cidList div").length;
            var divTag = "<div data-num='" + (len+1) + "'>" + cid + "</div>";
            $("#cidList").append(divTag);
        }
    });

    // 부적합, 주의가 있는 경우
    if(again > 0){
        msg += "선택한 " + len + "건의 검사 객체 중";
        msg += "\n\n적합 : " + pass;
        msg += "\n부적합 또는 주의 : " + again;
        msg += "\n\n부적합 또는 주의인 객체의";
        msg += "\n검사 결과를 다시 확인하시겠습니까?";
        
        // 판정 변경 화면으로 이동
        if(confirm(msg)){
            // 페이지 넘버
            $("#currNum").text("1");
            $("#allNum").text($("#cidList div").length);

            // ajax product detail 조회
            var cid = $("#cidList").find("div[data-num=1]").text(); // 첫번째를 조회
            viewDetail(cid);
        
        // 검사 결과 전송
        } else {
            if(confirm((pass + again) + "건의 검사 결과를 전송하시겠습니까?")){
                updateManageSystem();
                isTrue = true;
            } else {
                isTrue = false;
            }
        }
    // 모두 적합한 경우 검사 결과 전송
    } else {
        msg = pass + "건의 검사 결과를 전송하시겠습니까?";

        if(confirm(msg)){
            updateManageSystem();
            isTrue = true;
        } else {
            isTrue = false;
        }
    }

    return isTrue;
});

// 셀렉트박스 변경 이벤트
$(".searchWrap select").on('change', function(){
    var target = $(".nav li.on").data('target');
    var id = $(this).attr("id");

    // 사업년도를 바꾸면 > 사업명 조회 > 업체명 조회 > 검색
    if(id == target + "SelBsnsYy"){
        bsnsNameList(target, function(){
            bzCompList(target, function(){
                if(target == 'stats'){
                    getStats();
                } else {
                    searchList();
                }
            });
        });
    }

    // 사업명을 바꾸면 > 업체명 조회 > 검색
    if(id == target + "SelBsnsNm"){
        bzCompList(target, function(){
            if(target == 'stats'){
                getStats();
            } else {
                searchList();
            }
        });
    }

    // 업체명 바꾸면 > 검색
    if(id == target + "SelBzComp"){
        if(target == 'stats'){
            getStats();
        } else {
            searchList();
        }
    }
});

// 페이지 이동
$(".pagingList").on('click', 'li', function(){
    var $item = $(this);
    var $id = $item.attr("id");
    currentPage = $item.text() *1;

    if($id == "next")    currentPage = nextPage;
    if($id == "prev")    currentPage = prevPage;

    searchList("keep");
});

// 페이징 조회 수 변경
$(".pageNum").on('change', function(){
    searchList();
});

// 사업년도 목록 조회
function bsnsYearList(target, callback){
    $.ajax({
        url: serviceUrl + '/product/bsnsYearList.do'
        , data: JSON.stringify({aaa:"bbb"})
        , dataType: 'json'
        , type: 'post'
        , contentType: 'application/json'
        , success: function(res){
            var list = res.message;
            var h = "";
            
            if(list.length>0){
                for(var i=0, l=list.length; i<l; i++){
                    if(list[i] == '2017'){
                        h += '<option value="' + list[i] + '" selected>' + list[i] + '</option>';
                    } else {
                        h += '<option value="' + list[i] + '">' + list[i] + '</option>';
                    }
                }
            } else {
                h = "<option value=''>전체</option>";
            }
            
            // add list data
            $('#' + target + 'SelBsnsYy').html(h);

            callback();
        }
        , error: function(a,b,msg){
            debugger
        }
    });
}

// 사업명 목록 조회
function bsnsNameList(target, callback){
    var data = {};
    data.updtBsnsYy = $("#"+target+"SelBsnsYy option:selected").val();

    $.ajax({
        url: serviceUrl + '/product/bsnsNameList.do'
        , data: JSON.stringify(data)
        , dataType: 'json'
        , type: 'post'
        , contentType: 'application/json'
        , success: function(res){
            var list = res.message;
            var h = "";
            
            if(list.length>0){
                for(var i=0, l=list.length; i<l; i++){
                    h += '<option value="' + list[i] + '">' + list[i] + '</option>';
                }
            } else {
                h = "<option value=''>전체</option>";
            }
            
            // add list data
            $('#' + target + 'SelBsnsNm').html(h);

            callback();
        }
        , error: function(a,b,msg){
            debugger
        }
    });
}

// 업체명 목록 조회
function bzCompList(target, callback){
    var data = {};
    data.updtBsnsYy = $("#"+target+"SelBsnsYy option:selected").val();
    data.updtBsnsNm = $("#"+target+"SelBsnsNm option:selected").val();

    $.ajax({
        url: serviceUrl + '/product/compList.do'
        , data: JSON.stringify(data)
        , dataType: 'json'
        , type: 'post'
        , contentType: 'application/json'
        , success: function(res){
            var list = res.message;
            var h = "";

            if(target == 'stats'){
                h = "<option value=''>전체</option>";
            }

            if(list.length>0){
                for(var i=0, l=list.length; i<l; i++){
                    h += '<option value="' + list[i] + '">' + list[i] + '</option>';
                }
            } else {
                h = "<option value=''>전체</option>";
            }
            
            // add list data
            $('#' + target + 'SelBzComp').html(h);

            callback();
        }
        , error: function(a,b,msg){
            debugger
        }
    });
}

// 검색 목록 초기화
function searchInit(target){
    // 테이블 초기화
    $(".chkAll").prop("checked", false);
    $(".chkCnt").text("0");
    $('#' + target + 'Tmpl').empty();

    if(target == 'insp'){
        // 검사 실행 버튼 초기화
        $(".executeIns").removeClass("done");
        $.each($("[data-ins-cate]"), function(i, v){
            $(v).text($(v).data('title'));
        });
    }
}

// 검색 파라미터 정의
function searchParams(target){
    var params = {};
    
    // 불러올 페이지 수
    dataPerPage = $("#" + target + "PageNum").val();
    params.limit = dataPerPage;
    params.offset = dataPerPage*(currentPage-1);
    
    // 수행업체
    params.mnentNm = $('#' + target + 'SelBzComp option:selected').val();

    // 사업년도
    params.updtBsnsYy = $('#' + target + 'SelBsnsYy option:selected').val();

    // 사업명
    params.updtBsnsNm = $('#' + target + 'SelBsnsNm option:selected').val();

    // 사업명
    params.updtBsnsNmSub = $('#' + target + 'BsnsNmSub').val();

    // 수정방법
    //params.updtBsnsSe = $('#' + target + 'SelChMode option:selected').val();

    // 납품일자 str
    params.rsregStrDt = $('#' + target + 'StrDate').val();
    
    // 납품일자 end
    params.rsregEndDt = $('#' + target + 'EndDate').val();

    // 활성메뉴(insp or appr)
    params.target = target;

    // 정렬 컬럼
    params.order = qi.search_order ? qi.search_order : "updt_bsns_nm_sub";

    // 정렬 순서
    params.sort = qi.search_sort ? qi.search_sort : "asc";
    
    if(target == 'insp'){
        // 조회모드(검사대기 or 나의검사)
        var readSe = $("#inspReadSe > button.on").val();
        params.judgeSe = readSe;
        params.insUserId = qi.userId;
        
        // 검사 종류
        var insCate = $("#inspSelCate > button.on").val();
        params.colName = insCate;

        // 진행 상태
        var insProc = $("#inspSelProc > button.on").val();
        params.colValue = insProc;
    }

    if(target == 'appr'){
        params.insUserId = qi.userId;

        // 검사결과(적합 or 부적합 or 주의)
        params.resultSe = $('#apprSelRes > button.on').val();
    }

    if(target == 'stats'){
        var tab = $(".snb li.on").data("stats-target");
        
        // 검사결과(적합 or 부적합 or 주의)
        params.bCode = $('.statsCateErr.' + tab + ' option:selected').val();
        params.insUserId = qi.userId;
    }

    return params;
}

// 검색 실행
function searchList(keep){
    var target = $(".nav li.on").data('target');

    // 검색 내역 초기화
    searchInit(target);
    if(!keep){
        currentPage = 1;
    }

    // 검색 파라미터 정의
    var params = {};
    params = searchParams(target);

    if(xhr){    // ajax 요청 중단
        xhr.abort();
    }
    
    // 검색 실행
    xhr = $.ajax({
        url: serviceUrl + '/product/list.do'
        , data: JSON.stringify(params)
        , dataType: 'json'
        , type: 'post'
        , contentType: 'application/json'
        , success: function(res){
            var list = res.message.resultList;
            var totCnt = res.message.totCnt;

            if(totCnt <= 0){
                $("#"+target+"DataCnt").text(totCnt);
                $("#"+target+"ListSummary").hide();
                var wi = $('#' + target + 'TmplList').width();
                $("#" + target + "Tmpl").html("<tr><td style='width:"+wi+"px; height:50px; vertical-align: middle;'>검색된 데이터가 없습니다.</td></tr>")
            } else {
                // 전체 카운트
                $("#"+target+"DataCnt").text(addCommas(totCnt));

                // 사업명
                $("#"+target+"ListSummary").show();
                $("#"+target+"DataBsnsNm").text(list[0].updtBsnsNm);

                // add list data
                $('#' + target + 'TmplList').tmpl(list).appendTo('#' + target + 'Tmpl');

                //$(window).resize();   // @@
            }

            paging(totCnt, dataPerPage, pageCount, currentPage);
        }
        , error: function(a,b,msg){
            debugger
        }
        , complete: function(){
            $(window).resize();
        }
    });
}

// 검사 결과에 따라 검사 실행 버튼을 동적으로 변경
function changeInsBtnColor(e){
    var elementTd = $("#inspTmpl td .chk:checked").parent();
    var insCate = $(".executeIns");             // log, the, inf, loc

    $.each(insCate, function(i, v){
        var insKind = $(v).data("ins-cate");    // log or the or inf or loc

        var insResultArr = [];
        var insReultList = elementTd.siblings("." + insKind);
        var insBtnName = $(".executeIns." + insKind).data("title");

        // 검사 결과를 배열에 넣음(중복 제거)
        $.each(insReultList, function(i, v){
            var val = $(v).data("code");
            if($.inArray(val, insResultArr) === -1){
                insResultArr.push(val);
            }
        });

        // 검사 결과에 따라 검사 실행 버튼 색상 변경
        if(insResultArr.length != 0 && $.inArray("IVS003", insResultArr) === -1){
            $(".executeIns." + insKind).addClass("done");
            $(".executeIns." + insKind).text(insBtnName + "(완료)");
        } else {
            $(".executeIns." + insKind).removeClass("done");
            $(".executeIns." + insKind).text(insBtnName);
        }

    });
}

// 검사 대상 목록(파이썬에서 호출)
function getInsTargetList(){
    var target = $(".nav li.on").data('target');

    var checkedCids = $("#" + target + "Tmpl").find(".chk:checked").parent().siblings('.dataCid');
    var checkedLayers = $("#" + target + "Tmpl").find(".chk:checked").parent().siblings('.dataLayer');

    var cidList = [];
    var res = {};

    checkedCids.each(function(i){
        cidList.push({"cid" : $(checkedCids[i]).text(), "layer": $(checkedLayers[i]).data("layer-id").toLowerCase()});
    });
    
    res.features = cidList;

    return res;
}

// 검사 정보 업데이트(검사자, 검사그룹, 검사시작일자)
function updateinsInfo(cid){
    $.ajax({});

    
}

// 선택된 체크박스 수 카운트
function checkedObjCnt(){
    var target = $(".nav li.on").data('target');

    var cnt = $("#" + target + "Tmpl .chk:checked").length;
    $("#" + target + "ChkCnt").text(cnt);
}

// 리포트 요청 파라미터(파이썬에서 호출)
function saveReportList(sessId){
    var res = {};
    var cidList = [];
    var std = false;
    var userNm = "";

    // 검사 기준 출력 질문
    if(confirm("검사 기준을 함께 출력하시겠습니까?")){
        std = true;
    } else {
        std = false;
    }

    // 검사자 명 조회
    getUserInfo(sessId, function(userInfo){
        userNm = userInfo.userNm;
    });

    // cid 읽기
    var checkedCids = $("#apprTmpl").find(".chk:checked").parent().siblings('.dataCid');
    checkedCids.each(function(i){
        cidList.push($(checkedCids[i]).text());
    });

    res.cid = cidList;
    res.std = std;
    res.insUserNm = userNm;

    return res;
}

function aa(){
    $("#progressBar").show();
}
function bb(){
    $("#progressBar").hide();
}
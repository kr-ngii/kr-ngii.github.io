$(document).ready(function(){
    // 초기 설정은 성과품검사 메뉴 클릭
    $(".nav li.exam").click();
	
    // resize
	$(window).resize(function(){
        var target = $(".nav li.on").data('target');
        
        // table resize
        if(target == 'insp' || target == 'appr'){
            searchListResize();
            
            if($(".layerWrap").is(":visible")){
                searchDetailResize();
            }
        }
    });
});

// 사용자 비밀번호 변경
$("#changePw").on('click', function(){
    $("#changePwLayer").show();
});

$("#changePwClose").on('click', function(){
    clearChangePw();
    $("#changePwLayer").hide();
});

$("#btnChangePw").on('click', function(){
    if($("#curPw").val()==""){
        alert("현재 비밀번호를 입력해주세요.");
        return false;
    } else if($("#newPw1").val()==""){
        alert("신규 비밀번호를 입력해주세요.");
        return false;
    } else if($("#newPw2").val()==""){
        alert("신규 비밀번호를 입력해주세요.");
        return false;
    } else if($("#newPw1").val()!=$("#newPw2").val()){
        alert("신규 비밀번호를 다시 입력해주세요.");
        return false;
    }

    var curPw = $("#curPw").val();
    var newPw = $("#newPw1").val();
    userChangePw(curPw, newPw);
});

// 비밀번호 변경 요청 (for 관리시스템)
function userChangePw(curPw, newPw){
    var params = {};
    params.userId = qi.userId;
    params.userPW = curPw;
    params.newPW = newPw;
    
    $.ajax({
        url: serviceUrl + '/user/changePw.do'
        , data: JSON.stringify(params)
        , type : 'post'
        , dataType : 'json'
        , contentType: 'application/json'
        , async: false
        , success: function(res){
            if(res.state == '200' && res.result == "true"){
                alert(res.message);
                clearChangePw();
                $("#changePwLayer").hide();
            } else {
                alert(res.message);
            }
        }
        , error: function(a,b,m){
            alert("비밀번호 변경 중 오류가 발생하였습니다.\n관리자에게 문의해주세요.");
        }
    });
}

// 비밀번호 변경 텍스트 초기화
function clearChangePw(){
    $("#curPw").val("");
    $("#newPw1").val("");
    $("#newPw2").val("");
}

// 테이블 리사이즈
function searchListResize(){
    // table resize
    $("table.scroll").css("width", $(window).width()-120);
    $("table.scroll thead").css("width", $(window).width()-135);
    $("table.scroll tbody").css("width", $(window).width()-120);

    var target = $(".nav li.on").data('target');
    var $table = $('table.scroll.' + target);
    var $bodyCells = $table.find('tbody tr:first').children(":visible");
    var colWidth;
    
    var wi = $table.parent().css("width");
    wi = wi.replace("px","")*1;
    
    var wiFirst;
    var wiSecond;
    var wiOthers;

    if(target == 'insp'){
        wiFirst = Math.round(wi * 20/100);
        wiSecond = Math.round(wi * 15/100);
        wiOthers = Math.round(wi * 65/8/100);
    } else if(target == 'appr'){
        wiFirst = Math.round(wi * 20/100);
        wiSecond = Math.round(wi * 15/100);
        wiOthers = Math.round(wi * 65/10/100);
    }

    // Get the tbody columns width array
    colWidth = $bodyCells.map(function(i) {
        if(i == 0){
        } else if (i == 1) {
            $(this).width(wiFirst);
        } else if (i == 2 ){
            $(this).width(wiSecond);
        } else {
            $(this).width(wiOthers);
        }
        return $(this).width();
    }).get();
    
    // Set the width of thead columns
    $table.find('thead tr').children(":visible").each(function(i, v) {
        $(v).width(colWidth[i]);
    });

    $("table.scroll tbody").css("height", $(window).height()-($(".searchWrap."+target).height()+410));
    $(".contents").css("min-height", $(window).height()-240);
}

// 결과 변경 화면 리사이즈
function searchDetailResize(){
    // table resize
    var $table = $('table.plain.detailTable');
    var $bodyCells = $table.find('tbody tr:first').children(":visible");
    var colWidth;
    
    var wi = $table.css("width");
    wi = wi.replace("px","")*1;
    var wiFirst = (wi - 500) /2;

    // Get the tbody columns width array
    colWidth = $bodyCells.map(function(i) {
        if(i == 2){
            $(this).width("110");
        }
        if(i == 5 || i == 6){
            $(this).width(wiFirst);
        }
        return $(this).width();
    }).get();
    
    // Set the width of thead columns
    $table.find('thead tr').children(":visible").each(function(i, v) {
        if(i == 2 || i == 5 || i == 6){
            $(v).width(colWidth[i]);
        }
    });

    // $("table.plain tbody").css("height", $(window).height() - 600);
    // $(".layerWrap div.dcontents").css("height", $(window).height() - 200);
    // $(".layerWrap div.dcontents").css("margin-top", $(window).height() - 800);
}

// 테이블 틀 고정
$('tbody').scroll(function(e) {
    var target = $(".nav li.on").data('target');
    var $tbody = $("tbody#" + target + "Tmpl")
    
    $('thead').css("left", - $tbody.scrollLeft()); //fix the thead relative to the body scrolling
});

// 셀병합 rowspan 2depth
function applyRowspan(selector) {
    selector.each(function() {
        var values = $(this).find("tr>td:first-of-type");
        var kustomNext = $(values).next();
        
        var run = 1;
        for (var i=values.length-1; i>-1; i--){
            if(values.eq(i).text() === values.eq(i-1).text()) {
                values.eq(i).remove();
                kustomNext.eq(i).remove();
                run++;
            } else {
                values.eq(i).attr("rowspan", run);
                kustomNext.eq(i).attr("rowspan", run);
                run = 1;
            }
        }
    })
}

// 셀병합 rowspan 3depth
function applyRowspanSub(selector) {
    selector.each(function() {
        var values = $(this).find("tr>td.errCode");

        var run = 1;
        for (var i=values.length-1; i>-1; i--){
            if(values.eq(i).text() !== "" && values.eq(i).text() === values.eq(i-1).text()) {
                values.eq(i).remove();
                run++;
            } else {
                values.eq(i).attr("rowspan", run);
                run = 1;
            }
        }
    })
}

// 천단위 콤마
function addCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

// 달력 생성
function createDatepickerLinked(start_id, end_id){
	$( "#"+start_id ).datepicker({
		dateFormat: 'yy-mm-dd'
		, changeMonth: true
		, changeYear: true
		, numberOfMonths: 1
		, showOn: "both"
		, maxDate : "+0d"
		, yearRange: "-100:+0"
		, onClose: function( selectedDate ) {
			$( "#"+end_id ).datepicker( "option", "minDate", selectedDate );
            calendarChange();
		}
    });
	
	$( "#"+end_id ).datepicker({
		dateFormat: 'yy-mm-dd'
		, changeMonth: true
		, changeYear: true
		, numberOfMonths: 1
		, showOn: "both"
		, maxDate : "+0d"
		, yearRange: "-100:+0"
		, onClose: function( selectedDate ) {
			var date = "";
			if(selectedDate){
				date = selectedDate;
			} else {
				var dt = new Date();
				var month = dt.getMonth()+1;
				var day = dt.getDate();
				var year = dt.getFullYear();
				date = year +"-"+ month +"-"+ day;
			}
            $( "#"+start_id ).datepicker( "option", "maxDate", date );
            calendarChange();
		}
    });
	
	$( "#"+start_id ).mask("0000-00-00");
    $( "#"+end_id ).mask("0000-00-00");
}

// 데이터 재 검색
function calendarChange(){
    var target = $(".nav li.on").data('target');
    $(".calPeriod."+target+" button").removeClass("on");
    $(".calPeriod."+target+" button[value='etc']").addClass("on");

    searchList();
}

// 날짜 유효성 체크
function isValidDate(d) {
	var month_day = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
	var isValid = false;
	
	var inputDate = d.replace(/-/g,"");
	var dateToken = d.split('-');
	var year = Number(dateToken[0]);
	var month = Number(dateToken[1]);
	var day = Number(dateToken[2]);
    
    var today = getToday("");
    
	if(inputDate <= today){
		// 윤년일때
		if(isLeaf(year)) {
			if(month == 2) {
				if(day <= month_day[month-1] + 1) {
					isValid = true;
				}
			} else {
				if(day <= month_day[month-1]) {
					isValid = true;
				}
			}
		// 윤년이 아닐 때
		} else {
			if(day <= month_day[month-1]) {
				isValid = true;
			}
		}
    }
    
	return isValid;
}

// 윤년 체크
function isLeaf(year) {
	var leaf = false;
	if(year % 4 == 0) {
		leaf = true;
		if(year % 100 == 0) {
			leaf = false;
		}
		if(year % 400 == 0) {
			leaf = true;
		}
	}
	return leaf;
}

// 달력 input에 기본 검색 날짜 세팅
function initPeriodFromToday(str, end, target_str_id, target_end_id){
	var today = new Date();
	var sumStr = new Date(today-(3600000*24*str*-1));
	var sumEnd = new Date(today-(3600000*24*end*-1));
	
	var strDate = sumStr.getFullYear() + '-' + pad(sumStr.getMonth()+1) + '-' + pad(sumStr.getDate());
	var endDate = sumEnd.getFullYear() + '-' + pad(sumEnd.getMonth()+1) + '-' + pad(sumEnd.getDate());
	
	$("#"+target_str_id).val(strDate);
    $("#"+target_end_id).val(endDate);
}

// 달력 input에 날짜 변경
function changeCalendarDate(obj){
	var target = $(".nav li.on").data('target');

	var p = $(obj).val();
    initPeriodFromToday(p * -1, 0, target+"StrDate", target+"EndDate");
}

// 날짜에 0 붙이기
function pad(num) {
    num = num + '';
    return num.length < 2 ? '0' + num : num;
}

// 오늘 날짜 조회
function getToday(separator){
	var currDt = new Date();
	var currYear = currDt.getFullYear();
	var currMonth = currDt.getMonth()+1;
	var currDay = currDt.getDate();
    var today = "" + currYear + separator + pad(currMonth) + separator + pad(currDay);
    
    return today;
}

// 사용자 정보 조회
function getUserInfo(sessId, callback){
    var params = {sessId : sessId};
    
    $.ajax({
        url: serviceUrl + '/user/selectUserInfo.do'
        , data: JSON.stringify(params)
        , type : 'post'
        , dataType : 'json'
        , contentType: 'application/json'
        , async: false
        , success: function(res){
            var userInfo = res.message;

            callback(userInfo);
        }
        , error: function(a,b,m){
            debugger;
        }
    });
}

// 페이징
function paging(totalData, dataPerPage, pageCount, currentPage){
    var totalPage = Math.ceil(totalData/dataPerPage);    // 총 페이지 수
    var pageGroup = Math.ceil(currentPage/pageCount);    // 페이지 그룹

    var html = "";

    if(totalData > 0){
        
        var last = pageGroup * pageCount;           // 화면에 보여질 마지막 페이지 번호
        var first = pageCount * (pageGroup-1) +1;   // 화면에 보여질 첫번째 페이지 번호

        if(last > totalPage){
            last = totalPage;
        }

        nextPage = last+1;
        prevPage = first-1;
        
        if(prevPage > 0)
            html += "<li class='ico forward' id='prev' title='앞으로'>앞으로</li>";
    
        for(var i=first; i<=last; i++){
            html += "<li data-page=" + i + " id=" + i + ">" + i + "</li>";
        }
        
        if(last < totalPage)
            html += "<li class='ico back' id='next' title='뒤로'>뒤로</li>";
            
        $(".pageArea").show();
    } else {
        $(".pageArea").hide();
    }

    $(".pagingList").html(html);    // 페이지 목록 생성
    $(".pagingList li").removeClass("on")
    $(".pagingList li[data-page='" + currentPage + "']").addClass("on");    // 현재 페이지 표시
}

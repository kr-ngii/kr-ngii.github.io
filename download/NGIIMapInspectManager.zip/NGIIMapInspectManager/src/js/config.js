serviceUrl = 'http://localhost:8080/kqiweb';
//serviceUrl = 'http://seoul.gaia3d.com:8989/kqiweb';

// properties - connection.ini 파일에 정의
// 파이썬에서 호출 HtmlMenuDialog.py
function setServiceUrl(__serviceUrl){
    serviceUrl = __serviceUrl;
}

// ajax 변수
var xhr;    // 요청 중단을 위해 사용

// 페이징관련 변수
var dataPerPage = 100;   // 한 페이지에 나타낼 데이터 수
var pageCount = 10;      // 한 화면에 나타낼 페이지 수
var currentPage = 1;
var nextPage = 0;
var prevPage = 0;

// 통계 관련 변수
var myChart;

// global
var qi = {};


# -*- coding: utf-8 -*-
import os

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4 import uic

from ui.SelectInspectData import Ui_SelectInspectData

from LogicalTemporalInspect import LogicalTemporalInspect
from ThematicInspect import ThematicInspect
from InspectProgress import InspectProgress

import logging.handlers
logger = logging.getLogger('ngiiPlugin')

OPEN_MODE = "shp"


# class SelectInspectData(QDialog, Ui_SelectInspectData):
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ui/SelectInspectData.ui'))
class SelectInspectData(QDialog, FORM_CLASS):

    inspectWidget = None
    __oldDataDir = None

    def __init__(self, iface, parent=None):
        super(SelectInspectData, self).__init__(parent)
        self.setupUi(self)

        self.logger = logger

        self.iface = iface
        self.parent = parent

        self.__connectFn()

        self.txtInspectorNm.setText(u"홍길동")
        if OPEN_MODE != "gpkg":
            self.label_3.setText(u"[안내] 검사 대상이 있는 폴더를 선택하시고 수행할 검사를 선택해 주세요.")

        self.btnThematicInspect.setEnabled(False)

    def __connectFn(self):
        self.btnInspectData.clicked.connect(self.findInspectData)
        self.btnLogicalInspect.clicked.connect(self.showLogicalTemporalInspect)
        self.btnThematicInspect.clicked.connect(self.showThematicInspect)
        # self.btnClose.clicked.connect(self.close)

    def findInspectData(self):
        if OPEN_MODE != "gpkg":
            dataPath = QFileDialog.getExistingDirectory(self.iface.mainWindow(), u'검사 대상 폴더 선택',
                                                        self.__oldDataDir)
            self.__oldDataDir = os.path.dirname(dataPath)

            # self.logger.info("Set inspect data : {path}".format(path=dataPath))
            self.txtInspectData.setText(dataPath)
        else:
            fileFilter = "GeoPackage (*.gpkg)"

            dataPath = QFileDialog.getOpenFileName(self.iface.mainWindow(), u'검사 대상 GeoPackage 선택',
                                                   self.__oldDataDir, filter=fileFilter)
            self.__oldDataDir = os.path.dirname(dataPath)

            self.logger.info("Set inspect data : {path}".format(path=dataPath))
            self.txtInspectData.setText(dataPath)

    def showLogicalTemporalInspect(self):
        inspectorNm = self.txtInspectorNm.text()
        inspectData = self.txtInspectData.text()

        if inspectorNm == "":
            QMessageBox.warning(self.parent, u'입력값 오류', u'검사자 정보를 입력하셔야 검사가 가능합니다.')
            return

        elif inspectData == "":
            QMessageBox.warning(self.parent, u'입력값 오류', u'검사 대상을 먼저 선택하시고 실행할 검사종류를 선택해 주십시오.')
            return

        if self.inspectWidget:
            self.inspectWidget.hide()
            self.iface.removeDockWidget(self.inspectWidget)
            del self.inspectWidget
            self.inspectWidget = None

        self.inspectWidget = LogicalTemporalInspect(self, inspectorNm)

        inspectProgress = InspectProgress(self.iface, u"검사 대상 확인 중", 2, self.iface.mainWindow())
        inspectProgress.show()

        # checkResult, msg = self.inspectWidget.logicalInspector.dbUtil.checkInspectData(inspectData, inspectProgress)
        # if not checkResult:
        #     QMessageBox.warning(self.parent, u"데이터 오류", msg)
        # else:
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.inspectWidget)
        self.close()

        inspectProgress.close()
        del inspectProgress

        self.inspectWidget.startInspect()

    def showThematicInspect(self):
        inspectorNm = self.txtInspectorNm.text()
        inspectData = self.txtInspectData.text()

        if inspectorNm == "":
            QMessageBox.warning(self.parent, u'입력값 오류', u'검사자는 필수 입력값입니다.')
            return

        elif inspectData == "":
            QMessageBox.warning(self.parent, u'입력값 오류', u'검사 대상은 필수 입력값입니다.')
            return

        if self.inspectWidget:
            self.inspectWidget.hide()
            self.iface.removeDockWidget(self.inspectWidget)
            del self.inspectWidget
            self.inspectWidget = None

        self.inspectWidget = ThematicInspect(self.iface, inspectorNm, self.parent)

        inspectProgress = InspectProgress(self.iface, u"검사 대상 확인 중 ...", 2, self.iface.mainWindow())
        inspectProgress.show()

        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.inspectWidget)
        self.inspectWidget.show()

        checkResult, msg = self.inspectWidget.thematicInspect.dbUtil.checkInspectData(inspectData, inspectProgress)
        if not checkResult:
            QMessageBox.warning(self.parent, u"데이터 오류", msg)
            self.inspectWidget.close()
        else:
            self.inspectWidget.inspectSchema = msg
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.inspectWidget)
            self.inspectWidget.show()

            inspectProgress.setInfo(u"검사 대상 불러오는 중 ...")
            self.inspectWidget.loadData()

            self.close()

        inspectProgress.close()
        del inspectProgress

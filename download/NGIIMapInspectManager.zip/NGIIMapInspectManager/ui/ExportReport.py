# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ExportReport.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ExportReport(object):
    def setupUi(self, ExportReport):
        ExportReport.setObjectName(_fromUtf8("ExportReport"))
        ExportReport.resize(270, 120)
        ExportReport.setMinimumSize(QtCore.QSize(270, 120))
        ExportReport.setMaximumSize(QtCore.QSize(270, 120))
        self.verticalLayout = QtGui.QVBoxLayout(ExportReport)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.cmbInspectorNm = QtGui.QComboBox(ExportReport)
        self.cmbInspectorNm.setMinimumSize(QtCore.QSize(150, 20))
        self.cmbInspectorNm.setMaximumSize(QtCore.QSize(180, 20))
        self.cmbInspectorNm.setObjectName(_fromUtf8("cmbInspectorNm"))
        self.gridLayout.addWidget(self.cmbInspectorNm, 0, 1, 1, 1)
        self.cmbInspectData = QtGui.QComboBox(ExportReport)
        self.cmbInspectData.setObjectName(_fromUtf8("cmbInspectData"))
        self.gridLayout.addWidget(self.cmbInspectData, 1, 1, 1, 1)
        self.label_3 = QtGui.QLabel(ExportReport)
        self.label_3.setMinimumSize(QtCore.QSize(60, 25))
        self.label_3.setMaximumSize(QtCore.QSize(60, 25))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 0, 0, 1, 1)
        self.label = QtGui.QLabel(ExportReport)
        self.label.setMinimumSize(QtCore.QSize(60, 25))
        self.label.setMaximumSize(QtCore.QSize(60, 25))
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.btnExportReport = QtGui.QPushButton(ExportReport)
        self.btnExportReport.setMinimumSize(QtCore.QSize(75, 25))
        self.btnExportReport.setMaximumSize(QtCore.QSize(75, 25))
        self.btnExportReport.setObjectName(_fromUtf8("btnExportReport"))
        self.horizontalLayout.addWidget(self.btnExportReport)
        self.btnClose = QtGui.QPushButton(ExportReport)
        self.btnClose.setMinimumSize(QtCore.QSize(75, 25))
        self.btnClose.setMaximumSize(QtCore.QSize(75, 25))
        self.btnClose.setObjectName(_fromUtf8("btnClose"))
        self.horizontalLayout.addWidget(self.btnClose)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(ExportReport)
        QtCore.QMetaObject.connectSlotsByName(ExportReport)

    def retranslateUi(self, ExportReport):
        ExportReport.setWindowTitle(_translate("ExportReport", "레포트 출력", None))
        self.label_3.setText(_translate("ExportReport", "검사자", None))
        self.label.setText(_translate("ExportReport", "검사 대상", None))
        self.btnExportReport.setText(_translate("ExportReport", "레포트 출력", None))
        self.btnClose.setText(_translate("ExportReport", "닫 기", None))


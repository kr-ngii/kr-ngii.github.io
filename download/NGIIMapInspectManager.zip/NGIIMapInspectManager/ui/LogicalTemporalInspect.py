# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'LogicalTemporalInspect.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_LogicalTemporalInspect(object):
    def setupUi(self, LogicalTemporalInspect):
        LogicalTemporalInspect.setObjectName(_fromUtf8("LogicalTemporalInspect"))
        LogicalTemporalInspect.resize(300, 600)
        LogicalTemporalInspect.setMinimumSize(QtCore.QSize(300, 600))
        LogicalTemporalInspect.setMaximumSize(QtCore.QSize(300, 1024))
        LogicalTemporalInspect.setAutoFillBackground(True)
        LogicalTemporalInspect.setFeatures(QtGui.QDockWidget.DockWidgetClosable|QtGui.QDockWidget.DockWidgetMovable)
        LogicalTemporalInspect.setAllowedAreas(QtCore.Qt.RightDockWidgetArea)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.verticalLayout = QtGui.QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btnStartInspect = QtGui.QPushButton(self.dockWidgetContents)
        self.btnStartInspect.setMinimumSize(QtCore.QSize(280, 30))
        self.btnStartInspect.setMaximumSize(QtCore.QSize(300, 30))
        self.btnStartInspect.setObjectName(_fromUtf8("btnStartInspect"))
        self.verticalLayout.addWidget(self.btnStartInspect)
        self.label_5 = QtGui.QLabel(self.dockWidgetContents)
        self.label_5.setMinimumSize(QtCore.QSize(120, 25))
        self.label_5.setMaximumSize(QtCore.QSize(120, 25))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.verticalLayout.addWidget(self.label_5)
        self.treeResult = QtGui.QTreeView(self.dockWidgetContents)
        self.treeResult.setEnabled(True)
        self.treeResult.setMinimumSize(QtCore.QSize(270, 200))
        self.treeResult.setMaximumSize(QtCore.QSize(280, 16777215))
        self.treeResult.setObjectName(_fromUtf8("treeResult"))
        self.treeResult.header().setVisible(True)
        self.verticalLayout.addWidget(self.treeResult)
        self.label_4 = QtGui.QLabel(self.dockWidgetContents)
        self.label_4.setMinimumSize(QtCore.QSize(120, 25))
        self.label_4.setMaximumSize(QtCore.QSize(120, 25))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.verticalLayout.addWidget(self.label_4)
        self.frame = QtGui.QFrame(self.dockWidgetContents)
        self.frame.setMinimumSize(QtCore.QSize(270, 190))
        self.frame.setMaximumSize(QtCore.QSize(280, 190))
        self.frame.setFrameShape(QtGui.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtGui.QFrame.Sunken)
        self.frame.setObjectName(_fromUtf8("frame"))
        self.layoutWidget = QtGui.QWidget(self.frame)
        self.layoutWidget.setGeometry(QtCore.QRect(10, 10, 261, 171))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.gridLayout = QtGui.QGridLayout(self.layoutWidget)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_2 = QtGui.QLabel(self.layoutWidget)
        self.label_2.setMinimumSize(QtCore.QSize(70, 25))
        self.label_2.setMaximumSize(QtCore.QSize(70, 25))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.label_6 = QtGui.QLabel(self.layoutWidget)
        self.label_6.setMinimumSize(QtCore.QSize(70, 25))
        self.label_6.setMaximumSize(QtCore.QSize(70, 25))
        self.label_6.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_6, 2, 0, 1, 1)
        self.label = QtGui.QLabel(self.layoutWidget)
        self.label.setMinimumSize(QtCore.QSize(70, 25))
        self.label.setMaximumSize(QtCore.QSize(70, 25))
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_3 = QtGui.QLabel(self.layoutWidget)
        self.label_3.setMinimumSize(QtCore.QSize(70, 25))
        self.label_3.setMaximumSize(QtCore.QSize(70, 25))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)
       
        self.txtFeatureId = QtGui.QLineEdit(self.layoutWidget)
        self.txtFeatureId.setMinimumSize(QtCore.QSize(150, 25))
        self.txtFeatureId.setMaximumSize(QtCore.QSize(200, 25))
        self.txtFeatureId.setReadOnly(True)
        self.txtFeatureId.setObjectName(_fromUtf8("txtFeatureId"))
        self.gridLayout.addWidget(self.txtFeatureId, 0, 1, 1, 1)
        self.txtErrContent = QtGui.QLineEdit(self.layoutWidget)
        self.txtErrContent.setMinimumSize(QtCore.QSize(150, 25))
        self.txtErrContent.setMaximumSize(QtCore.QSize(200, 25))
        self.txtErrContent.setReadOnly(True)
        self.txtErrContent.setObjectName(_fromUtf8("txtErrContent"))
        self.gridLayout.addWidget(self.txtErrContent, 1, 1, 1, 1)
        self.txtPassGb = QtGui.QLineEdit(self.layoutWidget)
        self.txtPassGb.setMinimumSize(QtCore.QSize(50, 25))
        self.txtPassGb.setMaximumSize(QtCore.QSize(70, 25))
        self.txtPassGb.setReadOnly(True)
        self.txtPassGb.setObjectName(_fromUtf8("txtPassGb"))
        self.gridLayout.addWidget(self.txtPassGb, 2, 1, 1, 1)
        self.btnPassGb = QtGui.QPushButton(self.dockWidgetContents)
        self.btnPassGb.setMinimumSize(QtCore.QSize(50, 25))
        self.btnPassGb.setMaximumSize(QtCore.QSize(70, 25))
        self.btnPassGb.setObjectName(_fromUtf8("btnPassGb"))
        self.gridLayout.addWidget(self.btnPassGb, 2, 2, 1, 16)
        self.labelErrImg = QtGui.QLabel(self.layoutWidget)
        self.labelErrImg.setMinimumSize(QtCore.QSize(150, 80))
        self.labelErrImg.setMaximumSize(QtCore.QSize(200, 100))
        self.labelErrImg.setText(_fromUtf8(""))
        self.labelErrImg.setObjectName(_fromUtf8("labelErrImg"))
        self.gridLayout.addWidget(self.labelErrImg, 3, 1, 1, 1)
        self.verticalLayout.addWidget(self.frame)
        self.btnThematicInspect = QtGui.QPushButton(self.dockWidgetContents)
        self.btnThematicInspect.setMinimumSize(QtCore.QSize(280, 35))
        self.btnThematicInspect.setMaximumSize(QtCore.QSize(300, 35))
        self.btnThematicInspect.setObjectName(_fromUtf8("btnThematicInspect"))
        self.verticalLayout.addWidget(self.btnThematicInspect)
        LogicalTemporalInspect.setWidget(self.dockWidgetContents)

        self.retranslateUi(LogicalTemporalInspect)
        QtCore.QMetaObject.connectSlotsByName(LogicalTemporalInspect)

    def retranslateUi(self, LogicalTemporalInspect):
        LogicalTemporalInspect.setWindowTitle(_translate("LogicalTemporalInspect", "국토기본정보 검사", None))
        self.btnStartInspect.setText(_translate("LogicalTemporalInspect", "논리일관성/시간정확도 검사 시작", None))
        self.label_5.setText(_translate("LogicalTemporalInspect", "오류 리스트", None))
        self.label_4.setText(_translate("LogicalTemporalInspect", "오류 요약 정보", None))
        self.label_2.setText(_translate("LogicalTemporalInspect", "오류 내용", None))
        self.label.setText(_translate("LogicalTemporalInspect", "객체 ID", None))
        self.label_3.setText(_translate("LogicalTemporalInspect", "썸네일", None))
        self.label_6.setText(_translate("LogicalTemporalInspect", "검사결과", None))
        self.btnThematicInspect.setText(_translate("LogicalTemporalInspect", "주제정확도 검사 실행", None))
        self.btnPassGb.setText(_translate("LogicalTemporalInspect", "변경", None))


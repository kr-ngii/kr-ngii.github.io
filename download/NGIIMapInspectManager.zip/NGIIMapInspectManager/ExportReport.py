# -*- coding: utf-8 -*-

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from ui.ExportReport import Ui_ExportReport

import logging.handlers
logger = logging.getLogger('ngiiPlugin')


class ExportReport(QDialog, Ui_ExportReport):

    def __init__(self, iface, parent=None):
        super(ExportReport, self).__init__(parent)
        self.setupUi(self)

        self.logger = logger

        self.iface = iface
        self.parent = parent

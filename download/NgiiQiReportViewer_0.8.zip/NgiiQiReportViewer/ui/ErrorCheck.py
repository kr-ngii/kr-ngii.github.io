# -*- coding: utf-8 -*-

#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_ErrorCheck(object):
    def setupUi(self, panel):
        panel.setObjectName(_fromUtf8("ErrorCheck"))
        panel.resize(300, 600)
        panel.setMinimumSize(QtCore.QSize(300, 600))
        panel.setMaximumSize(QtCore.QSize(300, 1024))
        panel.setAutoFillBackground(True)
        panel.setFeatures(QtGui.QDockWidget.DockWidgetClosable|QtGui.QDockWidget.DockWidgetMovable)
        panel.setAllowedAreas(QtCore.Qt.RightDockWidgetArea)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))
        self.verticalLayout = QtGui.QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.gridLayout2 = QtGui.QGridLayout()
        self.gridLayout2.setObjectName(_fromUtf8("gridLayout2"))
        self.btnPath = QtGui.QPushButton(panel)
        self.btnPath.setMinimumSize(QtCore.QSize(20, 20))
        self.btnPath.setMaximumSize(QtCore.QSize(20, 20))
        self.btnPath.setObjectName(_fromUtf8("btnPath"))
        self.gridLayout2.addWidget(self.btnPath, 0, 2, 1, 1)
        self.txtPath = QtGui.QLineEdit(panel)
        self.txtPath.setMinimumSize(QtCore.QSize(100, 20))
        self.txtPath.setMaximumSize(QtCore.QSize(150, 20))
        self.txtPath.setObjectName(_fromUtf8("txtPath"))
        self.gridLayout2.addWidget(self.txtPath, 0, 1, 1, 1)
        self.label6 = QtGui.QLabel(panel)
        self.label6.setMinimumSize(QtCore.QSize(80, 25))
        self.label6.setMaximumSize(QtCore.QSize(80, 25))
        self.label6.setObjectName(_fromUtf8("label6"))
        self.gridLayout2.addWidget(self.label6, 0, 0, 1, 1)
        self.progressbar = QtGui.QProgressBar(self.dockWidgetContents)
        self.progressbar.setMinimumSize(QtCore.QSize(277, 20))
        self.progressbar.setMaximumSize(QtCore.QSize(277, 20))
        self.progressbar.setMaximum(0)
        self.progressbar.setMinimum(0)
        self.progressbar.hide()
        self.progressbar.setObjectName(_fromUtf8("progressbar"))
        self.verticalLayout.addLayout(self.gridLayout2)
        self.verticalLayout.addWidget(self.progressbar)

        self.label_5 = QtGui.QLabel(self.dockWidgetContents)
        self.label_5.setMinimumSize(QtCore.QSize(120, 25))
        self.label_5.setMaximumSize(QtCore.QSize(120, 25))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.verticalLayout.addWidget(self.label_5)
        self.treeResult = QtGui.QTreeView(self.dockWidgetContents)
        self.treeResult.setEnabled(True)
        self.treeResult.setMinimumSize(QtCore.QSize(270, 200))
        self.treeResult.setMaximumSize(QtCore.QSize(280, 16777215))
        self.treeResult.setObjectName(_fromUtf8("treeResult"))
        self.treeResult.header().setVisible(True)
        self.verticalLayout.addWidget(self.treeResult)
        self.label_4 = QtGui.QLabel(self.dockWidgetContents)
        self.label_4.setMinimumSize(QtCore.QSize(120, 25))
        self.label_4.setMaximumSize(QtCore.QSize(120, 25))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.verticalLayout.addWidget(self.label_4)
        self.frame = QtGui.QFrame(self.dockWidgetContents)
        self.frame.setMinimumSize(QtCore.QSize(270, 190))
        self.frame.setMaximumSize(QtCore.QSize(280, 190))
        self.frame.setFrameShape(QtGui.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtGui.QFrame.Sunken)
        self.frame.setObjectName(_fromUtf8("frame"))
        self.layoutWidget = QtGui.QWidget(self.frame)
        self.layoutWidget.setGeometry(QtCore.QRect(10, 10, 261, 171))
        self.layoutWidget.setObjectName(_fromUtf8("layoutWidget"))
        self.gridLayout = QtGui.QGridLayout(self.layoutWidget)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.label_2 = QtGui.QLabel(self.layoutWidget)
        self.label_2.setMinimumSize(QtCore.QSize(70, 25))
        self.label_2.setMaximumSize(QtCore.QSize(70, 25))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.label = QtGui.QLabel(self.layoutWidget)
        self.label.setMinimumSize(QtCore.QSize(70, 25))
        self.label.setMaximumSize(QtCore.QSize(70, 25))
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.label_3 = QtGui.QLabel(self.layoutWidget)
        self.label_3.setMinimumSize(QtCore.QSize(70, 25))
        self.label_3.setMaximumSize(QtCore.QSize(70, 25))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)
       
        self.txtFeatureId = QtGui.QLineEdit(self.layoutWidget)
        self.txtFeatureId.setMinimumSize(QtCore.QSize(150, 25))
        self.txtFeatureId.setMaximumSize(QtCore.QSize(200, 25))
        self.txtFeatureId.setReadOnly(True)
        self.txtFeatureId.setObjectName(_fromUtf8("txtFeatureId"))
        self.gridLayout.addWidget(self.txtFeatureId, 0, 1, 1, 1)
        self.txtErrContent = QtGui.QLineEdit(self.layoutWidget)
        self.txtErrContent.setMinimumSize(QtCore.QSize(150, 25))
        self.txtErrContent.setMaximumSize(QtCore.QSize(200, 25))
        self.txtErrContent.setReadOnly(True)
        self.txtErrContent.setObjectName(_fromUtf8("txtErrContent"))
        self.gridLayout.addWidget(self.txtErrContent, 1, 1, 1, 1)
        self.labelErrImg = QtGui.QLabel(self.layoutWidget)
        self.labelErrImg.setMinimumSize(QtCore.QSize(150, 80))
        self.labelErrImg.setMaximumSize(QtCore.QSize(200, 100))
        self.labelErrImg.setText(_fromUtf8(""))
        self.labelErrImg.setObjectName(_fromUtf8("labelErrImg"))
        self.gridLayout.addWidget(self.labelErrImg, 3, 1, 1, 1)
        self.verticalLayout.addWidget(self.frame)
        panel.setWidget(self.dockWidgetContents)

        self.retranslateUi(panel)
        QtCore.QMetaObject.connectSlotsByName(panel)

    def retranslateUi(self, panel):
        panel.setWindowTitle(_translate("ErrorCheck", "국토기본정보 검사", None))
        self.label_5.setText(_translate("ErrorCheck", "오류 리스트", None))
        self.label_4.setText(_translate("ErrorCheck", "오류 요약 정보", None))
        self.label_2.setText(_translate("ErrorCheck", "오류 내용", None))
        self.label.setText(_translate("ErrorCheck", "객체 ID", None))
        self.label_3.setText(_translate("ErrorCheck", "썸네일", None))
        self.label6.setText(_translate("ErrorCheck", "확인대상 폴더", None))
        self.btnPath.setText(_translate("ErrorCheck", "...", None))

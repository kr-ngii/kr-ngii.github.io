# -*- coding: utf-8 -*-
import os, glob

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from ui.ErrorCheck import Ui_ErrorCheck
import ConfigParser, codecs


class ErrorCheck(QDockWidget, Ui_ErrorCheck):
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),  "properties", "property.ini")
    __oldImgDir = None
    __oldShpDir = None
    errImgLayer = None
    crrLayer = None
    shpName = None
    shpLayer = None
    refLayerList = list()

    def __init__(self, dock):
        super(ErrorCheck, self).__init__(dock.parent)
        self.properties = ConfigParser.SafeConfigParser()
        with codecs.open(self.PROPERTIES_FILE, 'r', encoding='utf-8') as f:
            self.properties.readfp(f)
        self.setupUi(self)
        self.__initTree()
        self.iface = dock.iface
        self.parent = dock.parent
        self.crrWidget = dock
        self.__connectFn()
        self.setDefaultProject()

    def closeEvent(self, event):
        self.iface.removeDockWidget(self.crrWidget.errWidget)

    def __connectFn(self):
        self.btnPath.clicked.connect(self.findPath)
        self.treeResult.doubleClicked.connect(self.loadImg)
        self.treeResult.clicked.connect(self.setFeatureInfo)

    def findPath(self):
        # dataPath = QFileDialog.getExistingDirectory(self.iface.mainWindow(), u'이미지 파일 폴더를 선택해 주십시오.', self.__oldImgDir)
        dataPath = QFileDialog.getExistingDirectory(self.iface.mainWindow(), u'이미지 파일 폴더를 선택해 주십시오.')
        self.__oldImgDir = dataPath
        self.txtPath.setText(dataPath)
        if not dataPath:
            return
        file_list = os.listdir(dataPath)
        for file_name in file_list:
            shpPath = os.path.join(dataPath, file_name)
            ext = os.path.splitext(shpPath)[-1]
            if ext == '.shp':
                self.__oldShpDir = shpPath
                self.shpName = file_name.replace('.shp', '')

        self.loadShp()

    def __initTree(self):
        self.treeResult.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeResult.setHeaderHidden(True)
        self.treeModel = QStandardItemModel()
        self.treeModel.setColumnCount(1)
        self.treeResult.setModel(self.treeModel)

        self.txtFeatureId.setText("")
        self.txtErrContent.setText("")
        self.labelErrImg.setText("")

    def loadShp(self):
        if self.__oldImgDir is not NULL and self.__oldShpDir is not NULL:
            # self.progressbar.show()
            QApplication.setOverrideCursor(Qt.WaitCursor)
            rootDir = self.__oldImgDir
            shpFile = self.__oldShpDir
            if self.shpLayer:
                QgsMapLayerRegistry.instance().removeAllMapLayers()
                self.errImgLayer = None
                self.treeResult.setModel(self.treeModel.clear())
                self.__initTree()
                self.setDefaultProject()

            self.shpLayer = QgsVectorLayer(shpFile, self.shpName, "ogr")
            OrgCodePage = "UTF8"
            self.shpLayer.setProviderEncoding(OrgCodePage)
            self.shpLayer.dataProvider().setEncoding(OrgCodePage)
            QgsMapLayerRegistry.instance().addMapLayer(self.shpLayer)

            featureList = self.shpLayer.getFeatures()
            for feature in featureList:
                attrs = feature.attributes()
                layerNm = attrs[0]
                insCode = attrs[2]
                imgNm = attrs[3]

                imgRootDir = os.path.join(rootDir, layerNm, insCode)
                imgPath = os.path.join(imgRootDir, imgNm)
                if not os.path.exists(imgPath):
                    subDirList = glob.glob(os.path.join(imgRootDir, "tn_*"))
                    for subDir in subDirList:
                        imgPath = os.path.join(subDir, imgNm)

                        if os.path.exists(imgPath):
                            refLayer = os.path.basename(subDir)
                            layerKname = self.properties.get('layer', layerNm.upper())
                            codezip = self.properties.get('code', insCode.upper())
                            refLayerKname = self.properties.get('layer', refLayer.upper())
                            self.addTree(layerKname, codezip, imgNm[4:-4], imgPath, refLayerKname)

                else:
                    layerKname = self.properties.get('layer', layerNm.upper())
                    codezip = self.properties.get('code', insCode.upper())
                    self.addTree(layerKname, codezip, imgNm[4:-4], imgPath)
                QApplication.restoreOverrideCursor()
                # self.progressbar.hide()

    def setDefaultProject(self):
        self.iface.newProject()
        self.iface.mapCanvas().setCanvasColor(Qt.black)

    # 결과 tree 생성
    def addTree(self, layerNm, errNm, cid, imgPath, refLayer=None):
        inspectionNm = u'논리일관성'
        rootNodeRes = self.treeModel.findItems(inspectionNm)
        if len(rootNodeRes) > 0:
            rootNode = rootNodeRes[0]
        else:
            rootNode = QStandardItem(inspectionNm)
            rootNode.setEditable(False)
            rootNode.setSelectable(False)
            self.treeModel.appendRow([rootNode])

        rootIdx = self.treeModel.indexFromItem(rootNode)
        self.treeResult.expand(rootIdx)
        rootNodeRows = rootNode.rowCount()
        layerNode = None

        layerNmKo = layerNm

        for idx in range(0, rootNodeRows):
            tmpNode = rootNode.child(idx)
            if tmpNode.text() == layerNmKo:
                layerNode = tmpNode
                break

        if not layerNode:
            layerNode = QStandardItem(layerNmKo)
            layerNode.setEditable(False)
            layerNode.setSelectable(False)

            rootNode.appendRow([layerNode])

        layerIdx = self.treeModel.indexFromItem(layerNode)
        self.treeResult.expand(layerIdx)
        layerNodeRows = layerNode.rowCount()
        inspectCodeNode = None

        for idx in range(0, layerNodeRows):
            tmpNode = layerNode.child(idx)
            if tmpNode.text() == errNm:
                inspectCodeNode = tmpNode
                break

        if not inspectCodeNode:
            inspectCodeNode = QStandardItem(errNm)
            inspectCodeNode.setEditable(False)
            inspectCodeNode.setSelectable(False)

            layerNode.appendRow([inspectCodeNode])

        inspectCodeNodeRows = inspectCodeNode.rowCount()
        refLayerNode = None

        for idx in range(0, inspectCodeNodeRows):
            tmpNode = inspectCodeNode.child(idx)
            if tmpNode.text() == refLayer:
                refLayerNode = tmpNode
                break

        if not refLayerNode and refLayer is not None:
            refLayerNode = QStandardItem(refLayer)
            refLayerNode.setEnabled(False)
            refLayerNode.setSelectable(False)

            inspectCodeNode.appendRow([refLayerNode])

        if refLayer is not None:
            refLayerNodeRows = refLayerNode.rowCount()
        else:
            refLayerNodeRows = inspectCodeNode.rowCount()
            refLayerNode = inspectCodeNode
        cidNodeList = list()
        for idx in range(0, refLayerNodeRows):
            tmpNode = refLayerNode.child(idx)
            if tmpNode.text() == cid or tmpNode.text().startswith(u"{}_".format(cid)):
                cidNodeList.append(tmpNode)

        if len(cidNodeList) > 0:
            cid = u"{cid}_{idx}".format(cid=cid, idx=len(cidNodeList))

        cidNode = QStandardItem(cid)
        cidNode.setEditable(False)

        rasterInfo = {
            "layer": layerNm,
            "refLayer": refLayer,
            "feature_id": cid,
            "image_path": imgPath,
            "inspect_code": errNm
        }
        cidNode.setData(rasterInfo)
        refLayerNode.appendRow([cidNode])

        self.__writeXml(imgPath)
        self.treeResult.scrollToBottom()

    def loadImg(self, index):

        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        if self.errImgLayer:
            QgsMapLayerRegistry.instance().removeMapLayer(self.errImgLayer)

        rasterInfo = selData.data()
        imgPath = rasterInfo["image_path"]
        # self.__writeXml(imgPath)

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()
        self.errImgLayer = QgsRasterLayer(imgPath, os.path.splitext(os.path.basename(imgPath))[0])
        self.errImgLayer.renderer().setOpacity(0.5)

        QgsMapLayerRegistry.instance().addMapLayer(self.errImgLayer, False)

        groupRoot = QgsProject.instance().layerTreeRoot()
        groupRoot.insertLayer(0, self.errImgLayer)

        layerOrder.insert(0, self.errImgLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        legend = self.iface.legendInterface()
        layer = QgsMapLayerRegistry.instance().mapLayersByName(rasterInfo["layer"])

        if not self.crrLayer:
            self.crrLayer = layer
            # legend.setLayerVisible(layer, True)

        else:
            if self.crrLayer.name() != layer.name():
                # legend.setLayerVisible(self.crrLayer, False)
                # legend.setLayerVisible(layer, True)
                self.crrLayer = layer

        while len(self.refLayerList) != 0:
            refLayer = self.refLayerList.pop()
            if refLayer == self.crrLayer:
                continue

            # legend.setLayerVisible(refLayer, False)

        refLayerStr = rasterInfo["refLayer"]
        if refLayerStr:
            refLayerList = refLayerStr.split(",")

            for refLayerNm in refLayerList:
                if refLayerNm == self.crrLayer:
                    continue

                refLayer = QgsMapLayerRegistry.instance().mapLayersByName(refLayerNm)
                # legend.setLayerVisible(refLayer, True)
                self.refLayerList.append(refLayer)

        self.iface.mapCanvas().setExtent(self.errImgLayer.extent())
        self.iface.mapCanvas().refresh()

    def __writeXml(self, imgPath):
        baseNm = os.path.splitext(imgPath)[0]
        worldFile = u"{}.pgw".format(baseNm)
        xmlFile = u"{}.png.aux.xml".format(baseNm)

        if os.path.exists(xmlFile):
            return

        xmlTemplate = """
            <PAMDataset>
              <SRS>PROJCS["Korea 2000 / Unified CS",GEOGCS["Korea 2000",DATUM["Geocentric_datum_of_Korea",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],TOWGS84[0,0,0,0,0,0,0],AUTHORITY["EPSG","6737"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4737"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",38],PARAMETER["central_meridian",127.5],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",1000000],PARAMETER["false_northing",2000000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AUTHORITY["EPSG","5179"]]</SRS>
              <GeoTransform> {}, {}, {}, {}, {}, {} </GeoTransform>
              <Metadata domain="IMAGE_STRUCTURE">
                <MDI key="INTERLEAVE">PIXEL</MDI>
              </Metadata>
              <Metadata>
                <MDI key="AREA_OR_POINT">Area</MDI>
              </Metadata>
            </PAMDataset>
        """
        with open(worldFile, 'rb') as f:
            data = f.readlines()

        with open(xmlFile, 'wb') as f:
            f.write(xmlTemplate.format(data[4], data[0], data[1], data[5], data[2], data[3]))

    def setFeatureInfo(self, index):
        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        rasterInfo = selData.data()

        self.txtFeatureId.setText(selData.text())
        self.txtErrContent.setText(rasterInfo["inspect_code"])

        errImg = QPixmap(rasterInfo["image_path"])
        errImgWidth = errImg.width()
        errImgHeight = errImg.height()

        labelWidth = self.labelErrImg.width()
        labelHeight = self.labelErrImg.height()

        if errImgWidth >= errImgHeight:
            resizeImg = errImg.scaledToWidth(labelWidth)
            if resizeImg.height() > labelHeight:
                resizeImg = resizeImg.scaledToHeight(labelHeight)
        else:
            resizeImg = errImg.scaledToHeight(labelHeight)
            if resizeImg.width() > labelWidth:
                resizeImg = resizeImg.scaledToWidth(labelWidth)

        self.labelErrImg.setPixmap(resizeImg)

# -*- coding: utf-8 -*-
"""
/***************************************************************************
 NgiiQiReportViewer
                                 A QGIS plugin
 This NgiiQiReportViewer
                              -------------------
        begin                : 2018-03-29
        git sha              : $Format:%H$
        copyright            : (C) 2018 by NGII
        email                : shpark@gaia3d.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.core import *
from ErrorCheck import ErrorCheck

class NGIIErrorCheck:

    pluginName = u'NGIIErrorCheck'
    mainMenu = None
    menuBar = None
    crrWidget = None
    menuIcons = None
    menuTexts = None
    menuActions = None

    def __init__(self, iface, parent=None):
        # Save reference to the QGIS interface
        self.iface = iface  # type: QgsInterface
        self.parent = parent
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'NGIIErrorCheck_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []

        self.toolbar = self.iface.addToolBar(u'NGIIErrorCheck')
        self.toolbar.setObjectName(u'NGIIErrorCheck')

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('NGIIErrorCheck', message)

    def initGui(self):
        # 메뉴 객체 생성
        self.mainMenu = QMenu(self.iface.mainWindow())
        # 메뉴 등록하기
        menuBar = self.iface.mainWindow().menuBar()
        menuBar.insertMenu(self.iface.firstRightStandardMenu().menuAction(), self.mainMenu)

        # 하위 메뉴 생성
        self.menuIcons = 'icon_report.png'
        self.menuTexts = u'확인 대상 선택'
        self.menuActions = self.showErrorCheckPanel

        icon = QIcon(os.path.join(os.path.dirname(__file__), 'icons', self.menuIcons))
        text = self.menuTexts
        action = QAction(icon, text, self.iface.mainWindow())
        self.mainMenu.addAction(action)
        action.triggered.connect(self.menuActions)
        self.toolbar.addAction(icon, text, self.menuActions)

    def showErrorCheckPanel(self):
        self.errWidget = ErrorCheck(self)
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.errWidget)
        self.errWidget.show()

    def unload(self):
        self.mainMenu.deleteLater()
        self.toolbar.deleteLater()
        if self.crrWidget is not None:
            self.crrWidget.hide()
            if self.crrWidget is not None:
                self.iface.removeDockWidget(self.crrWidget.errWidget)
            del self.crrWidget
            self.crrWidget = None

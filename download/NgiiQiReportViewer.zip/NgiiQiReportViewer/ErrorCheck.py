# -*- coding: utf-8 -*-
import os, glob

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from ui.ErrorCheck import Ui_ErrorCheck
import ConfigParser, codecs
import threading, time


# CLASS for multitasking
class ProgressThread(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        return


def threadExecuteProgress():
    trd = ProgressThread()
    trd.start()
    while threading.activeCount() > 1:
        QgsApplication.processEvents(QEventLoop.ExcludeUserInputEvents)
        time.sleep(0.1)


class ErrorCheck(QDockWidget, Ui_ErrorCheck):
    PROPERTIES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),  "properties", "property.ini")
    __oldImgDir = None
    __oldShpDir = None
    errImgLayer = None
    crrLayer = None
    shpName = None
    shpLayer = None
    refLayerList = list()

    def __init__(self, dock):
        super(ErrorCheck, self).__init__(dock.parent)
        self.properties = ConfigParser.SafeConfigParser()
        with codecs.open(self.PROPERTIES_FILE, 'r', encoding='utf-8') as f:
            self.properties.readfp(f)
        self.setupUi(self)
        self.__initTree()
        self.iface = dock.iface
        self.parent = dock.parent
        self.crrWidget = dock
        self.__connectFn()
        self.setDefaultProject()
        self.msg = QMessageBox()
        self.msg.setIcon(QMessageBox.Warning)

    def closeEvent(self, event):
        self.iface.removeDockWidget(self.crrWidget.errWidget)

    def __connectFn(self):
        self.btnPath.clicked.connect(self.findPath)
        self.treeResult.doubleClicked.connect(self.loadImg)
        self.treeResult.clicked.connect(self.setFeatureInfo)

    def findPath(self):
        # dataPath = QFileDialog.getExistingDirectory(self.iface.mainWindow(), u'이미지 파일 폴더를 선택해 주십시오.', self.__oldImgDir)
        # dataPath = QFileDialog.getExistingDirectory(self.iface.mainWindow(), u'이미지 파일 폴더를 선택해 주십시오.')
        fileFilter = "*.shp"
        dataPath = QFileDialog.getOpenFileName(self.iface.mainWindow(), u'검사 대상 Shape 파일 선택', filter=fileFilter)
        self.__oldImgDir = os.path.dirname(dataPath)
        self.__oldShpDir = dataPath
        self.shpName = dataPath.split("/")[-1].replace('.shp', '')
        self.txtPath.setText(dataPath)
        if not dataPath:
            return
        else:
            self.loadShp()
        # file_list = os.listdir(self.__oldImgDir)
        # for file_name in file_list:
            # print file_name
        #     shpPath = os.path.join(dataPath, file_name)
        #     ext = os.path.splitext(shpPath)[-1]
        #     if ext == '.shp':
        #         self.__oldShpDir = shpPath
        #         self.shpName = file_name.replace('.shp', '')
        # if self.shpName is None:
        #     self.errorMsg(u'확인 대상 파일이 없습니다.')
        # else:
        #     self.loadShp()

    def __initTree(self):
        self.treeResult.setContextMenuPolicy(Qt.CustomContextMenu)
        self.treeResult.setHeaderHidden(True)
        self.treeModel = QStandardItemModel()
        self.treeModel.setColumnCount(1)
        self.treeResult.setModel(self.treeModel)

        self.txtFeatureId.setText("")
        self.txtErrContent.setText("")
        self.txtExceptContent.setText("")
        self.labelErrImg.setPixmap(QPixmap())

    def loadShp(self):
        if self.__oldImgDir is not NULL and self.__oldShpDir is not NULL:
            self.progressbar.setMaximum(0)
            self.progressbar.setMinimum(0)
            # QApplication.setOverrideCursor(Qt.WaitCursor)
            rootDir = self.__oldImgDir
            shpFile = self.__oldShpDir
            if self.shpLayer:
                QgsMapLayerRegistry.instance().removeAllMapLayers()
                self.errImgLayer = None
                self.treeResult.setModel(self.treeModel.clear())
                self.__initTree()
                self.setDefaultProject()

            self.shpLayer = QgsVectorLayer(shpFile, self.shpName, "ogr")
            # self.shpName = None
            OrgCodePage = "UTF8"
            self.shpLayer.setProviderEncoding(OrgCodePage)
            self.shpLayer.dataProvider().setEncoding(OrgCodePage)
            colList = list()
            for column in self.shpLayer.pendingFields():
                colList.append(column.name())
            columnList = (filter(lambda x: x != 'layer_nm' and x != 'err_nm' and x != 'err_cd' and x != 'img_nm' and x != 'er_reason', colList))
            if len(columnList) > 0:
                self.errorMsg(u'품질검사결과 Shape 파일을 선택해주세요')
                self.progressbar.setMaximum(1)
                return
            # QgsMapLayerRegistry.instance().addMapLayer(self.shpLayer)
            featureList = self.shpLayer.getFeatures()
            start_time = time.time()
            # for i in range(0, 13000):
            #     self.addTree(u'테스트', 'LCTCBV02', '1212121', '1212121', 'test', 'test')
            for feature in featureList:
                attrs = feature.attributes()
                try:
                    layerNm = attrs[0]
                    insCode = attrs[2]
                    imgNm = attrs[3]
                    exCode = attrs[4]
                except:
                    exCode = ''
                imgRootDir = os.path.join(rootDir, layerNm, insCode)
                imgPath = os.path.join(imgRootDir, imgNm)
                if not os.path.exists(imgPath):
                    subDirList = glob.glob(os.path.join(imgRootDir, "tn_*"))
                    for subDir in subDirList:
                        imgPath = os.path.join(subDir, imgNm)

                        if os.path.exists(imgPath):
                            refLayer = os.path.basename(subDir)
                            layerKname = self.properties.get('layer', layerNm.upper())
                            codezip = self.properties.get('code', insCode.upper())
                            refLayerKname = self.properties.get('layer', refLayer.upper())
                            self.addTree(layerKname, codezip, imgNm[4:-4], imgPath, exCode, refLayerKname)

                else:
                    layerKname = self.properties.get('layer', layerNm.upper())
                    codezip = self.properties.get('code', insCode.upper())
                    self.addTree(layerKname, codezip, imgNm[4:-4], imgPath, exCode)
            self.progressbar.setMaximum(1)
            self.errorMsg(u'Shape 파일 로드가 완료되었습니다.')
            print("--- %s seconds ---" % (time.time() - start_time))

    def setDefaultProject(self):
        self.iface.newProject()
        self.iface.mapCanvas().setCanvasColor(Qt.black)

    def addTree(self, layerNm, errNm, cid, imgPath, excode, refLayer=None):
        threadExecuteProgress()
        inspectionNm = u'논리일관성'
        rootNodeRes = self.treeModel.findItems(inspectionNm)
        if len(rootNodeRes) > 0:
            rootNode = rootNodeRes[0]
        else:
            rootNode = QStandardItem(inspectionNm)
            rootNode.setEditable(False)
            rootNode.setSelectable(False)
            self.treeModel.appendRow([rootNode])

        rootIdx = self.treeModel.indexFromItem(rootNode)
        self.treeResult.expand(rootIdx)
        rootNodeRows = rootNode.rowCount()
        layerNode = None

        layerNmKo = layerNm

        for idx in range(0, rootNodeRows):
            tmpNode = rootNode.child(idx)
            if tmpNode.text() == layerNmKo:
                layerNode = tmpNode
                break

        # if not layerNode:
        if layerNode is None:
            layerNode = QStandardItem(layerNmKo)
            layerNode.setEditable(False)
            layerNode.setSelectable(False)

            rootNode.appendRow([layerNode])

        layerIdx = self.treeModel.indexFromItem(layerNode)
        self.treeResult.expand(layerIdx)
        layerNodeRows = layerNode.rowCount()
        inspectCodeNode = None

        for idx in range(0, layerNodeRows):
            tmpNode = layerNode.child(idx)
            if tmpNode.text() == errNm:
                inspectCodeNode = tmpNode
                break

        # if not inspectCodeNode:
        if inspectCodeNode is None:
            inspectCodeNode = QStandardItem(errNm)
            inspectCodeNode.setEditable(False)
            inspectCodeNode.setSelectable(False)

            layerNode.appendRow([inspectCodeNode])

        inspectCodeNodeRows = inspectCodeNode.rowCount()
        refLayerNode = None

        for idx in range(0, inspectCodeNodeRows):
            tmpNode = inspectCodeNode.child(idx)
            if tmpNode.text() == refLayer:
                refLayerNode = tmpNode
                break

        # if not refLayerNode and refLayer is not None:
        if refLayerNode is None and refLayer is not None:
            refLayerNode = QStandardItem(refLayer)
            refLayerNode.setEnabled(False)
            refLayerNode.setSelectable(False)

            inspectCodeNode.appendRow([refLayerNode])

        if refLayer is not None:
            refLayerNodeRows = refLayerNode.rowCount()
        else:
            refLayerNodeRows = inspectCodeNode.rowCount()
            refLayerNode = inspectCodeNode
        cidNodeList = list()
        for idx in range(0, refLayerNodeRows):
            tmpNode = refLayerNode.child(idx)
            if tmpNode.text() == cid or tmpNode.text().startswith(u"{}_".format(cid)):
                cidNodeList.append(tmpNode)

        if len(cidNodeList) > 0:
            cid = u"{cid}_{idx}".format(cid=cid, idx=len(cidNodeList))

        cidNode = QStandardItem(cid)
        cidNode.setEditable(False)

        rasterInfo = {
            "layer": layerNm,
            "refLayer": refLayer,
            "feature_id": cid,
            "image_path": imgPath,
            "inspect_code": errNm,
            "except_code": excode
        }
        cidNode.setData(rasterInfo)
        refLayerNode.appendRow([cidNode])

        # self.__writeXml(imgPath)
        self.treeResult.scrollToBottom()

    def loadImg(self, index):

        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        if self.errImgLayer:
            QgsMapLayerRegistry.instance().removeMapLayer(self.errImgLayer)

        rasterInfo = selData.data()
        imgPath = rasterInfo["image_path"]
        # self.__writeXml(imgPath)

        layerOrder = self.iface.layerTreeCanvasBridge().customLayerOrder()
        self.errImgLayer = QgsRasterLayer(imgPath, os.path.splitext(os.path.basename(imgPath))[0])
        self.errImgLayer.renderer().setOpacity(0.5)

        QgsMapLayerRegistry.instance().addMapLayer(self.errImgLayer, False)

        groupRoot = QgsProject.instance().layerTreeRoot()
        groupRoot.insertLayer(0, self.errImgLayer)

        layerOrder.insert(0, self.errImgLayer.id())
        self.iface.layerTreeCanvasBridge().setCustomLayerOrder(layerOrder)

        legend = self.iface.legendInterface()
        layer = QgsMapLayerRegistry.instance().mapLayersByName(rasterInfo["layer"])

        if not self.crrLayer:
            self.crrLayer = layer
            # legend.setLayerVisible(layer, True)

        else:
            if self.crrLayer.name() != layer.name():
                # legend.setLayerVisible(self.crrLayer, False)
                # legend.setLayerVisible(layer, True)
                self.crrLayer = layer

        while len(self.refLayerList) != 0:
            refLayer = self.refLayerList.pop()
            if refLayer == self.crrLayer:
                continue

            # legend.setLayerVisible(refLayer, False)

        refLayerStr = rasterInfo["refLayer"]
        if refLayerStr:
            refLayerList = refLayerStr.split(",")

            for refLayerNm in refLayerList:
                if refLayerNm == self.crrLayer:
                    continue

                refLayer = QgsMapLayerRegistry.instance().mapLayersByName(refLayerNm)
                # legend.setLayerVisible(refLayer, True)
                self.refLayerList.append(refLayer)

        imgExtent = self.errImgLayer.extent()

        crrCrs = self.iface.mapCanvas().mapRenderer().destinationCrs().authid()

        if crrCrs != 'EPSG:5179':
            extentGeom = QgsGeometry.fromRect(imgExtent)
            sourceCrs = QgsCoordinateReferenceSystem("EPSG:5179")
            destCrs = QgsCoordinateReferenceSystem(crrCrs)
            tr = QgsCoordinateTransform(sourceCrs, destCrs)
            extentGeom.transform(tr)
            imgExtent = extentGeom.boundingBox()

        self.iface.mapCanvas().setExtent(imgExtent)

        # if self.iface.mapCanvas().scale() < 750:
        #     self.iface.mapCanvas().zoomScale(750.0)

        self.iface.mapCanvas().refresh()

    def __writeXml(self, imgPath):
        baseNm = os.path.splitext(imgPath)[0]
        worldFile = u"{}.pgw".format(baseNm)
        xmlFile = u"{}.png.aux.xml".format(baseNm)

        if os.path.exists(xmlFile):
            return

        xmlTemplate = """
            <PAMDataset>
              <SRS>PROJCS["Korea 2000 / Unified CS",GEOGCS["Korea 2000",DATUM["Geocentric_datum_of_Korea",SPHEROID["GRS 1980",6378137,298.257222101,AUTHORITY["EPSG","7019"]],TOWGS84[0,0,0,0,0,0,0],AUTHORITY["EPSG","6737"]],PRIMEM["Greenwich",0,AUTHORITY["EPSG","8901"]],UNIT["degree",0.0174532925199433,AUTHORITY["EPSG","9122"]],AUTHORITY["EPSG","4737"]],PROJECTION["Transverse_Mercator"],PARAMETER["latitude_of_origin",38],PARAMETER["central_meridian",127.5],PARAMETER["scale_factor",0.9996],PARAMETER["false_easting",1000000],PARAMETER["false_northing",2000000],UNIT["metre",1,AUTHORITY["EPSG","9001"]],AUTHORITY["EPSG","5179"]]</SRS>
              <GeoTransform> {}, {}, {}, {}, {}, {} </GeoTransform>
              <Metadata domain="IMAGE_STRUCTURE">
                <MDI key="INTERLEAVE">PIXEL</MDI>
              </Metadata>
              <Metadata>
                <MDI key="AREA_OR_POINT">Area</MDI>
              </Metadata>
            </PAMDataset>
        """
        with open(worldFile, 'rb') as f:
            data = f.readlines()

        with open(xmlFile, 'wb') as f:
            f.write(xmlTemplate.format(data[4], data[0], data[1], data[5], data[2], data[3]))

    def setFeatureInfo(self, index):
        selData = self.treeModel.itemFromIndex(index)  # type: QStandardItem

        if not selData.isSelectable():
            return

        rasterInfo = selData.data()

        self.txtFeatureId.setText(selData.text())
        self.txtErrContent.setText(rasterInfo["inspect_code"])
        if rasterInfo["except_code"] != NULL or '' or None:
            self.txtExceptContent.setText(rasterInfo["except_code"])
        else:
            self.txtExceptContent.setText('')

        errImg = QPixmap(rasterInfo["image_path"])
        errImgWidth = errImg.width()
        errImgHeight = errImg.height()

        labelWidth = self.labelErrImg.width()
        labelHeight = self.labelErrImg.height()

        if errImgWidth >= errImgHeight:
            resizeImg = errImg.scaledToWidth(labelWidth)
            if resizeImg.height() > labelHeight:
                resizeImg = resizeImg.scaledToHeight(labelHeight)
        else:
            resizeImg = errImg.scaledToHeight(labelHeight)
            if resizeImg.width() > labelWidth:
                resizeImg = resizeImg.scaledToWidth(labelWidth)

        self.labelErrImg.setPixmap(resizeImg)

    def errorMsg(self, err):
        self.msg.setText(err)
        self.msg.exec_()

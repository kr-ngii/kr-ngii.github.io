from AutoDetect import AutoDetect

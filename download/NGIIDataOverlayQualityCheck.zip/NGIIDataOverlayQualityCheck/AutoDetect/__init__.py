from AutoDetect import AutoDetect, ResSaveDialog

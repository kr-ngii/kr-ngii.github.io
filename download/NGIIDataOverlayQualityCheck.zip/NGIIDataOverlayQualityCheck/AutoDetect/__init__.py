from AutoDetect import AutoDetect

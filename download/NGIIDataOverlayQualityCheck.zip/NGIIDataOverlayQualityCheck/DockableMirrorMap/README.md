dockablemirrormap
=================

QGIS plugin that adds dockable map canvas synchronized with the main one.
